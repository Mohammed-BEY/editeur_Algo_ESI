/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

/**
 * Copyright (c) 2008, 2012 Oracle and/or its affiliates. All rights reserved.
 * Use is subject to license terms.
 */
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.*;

/**
 *
 * @author mohammed_bey
 */
public class IconeMiseAjourCorps extends MenuBar {

    public MenuItem menuIEcrire, menuILire, menuIAffecter, menuIConditionnelle,
            menuIAlternative, menuIBclPour, menuIBclTQ, menuIBclRepeter, menuIAppelProc;
    public MenuItem menuSupprimer, menuCopier, menuCouper, menuColler, menuComent;
    public Menu menuAjouter;
    public Menu menuMiseAjour;

    public IconeMiseAjourCorps() {
        menuIEcrire = MenuItemBuilder.create().text("ecriture").build();
        menuILire = MenuItemBuilder.create().text("lecture").build();
        menuIAffecter = MenuItemBuilder.create().text("affectation").build();
        menuIConditionnelle = MenuItemBuilder.create().text("conditionnelle").build();
        menuIAlternative = MenuItemBuilder.create().text("alternative").build();
        menuIBclPour = MenuItemBuilder.create().text("bouclePour").build();
        menuIBclTQ = MenuItemBuilder.create().text("boucleTantQue").build();
        menuIBclRepeter = MenuItemBuilder.create().text("boucleRepeter").build();
        menuIAppelProc = MenuItemBuilder.create().text("appelProcedure").build();

        menuComent = MenuItemBuilder.create().text("ajouter un commentaire").build();

        menuSupprimer = MenuItemBuilder.create().text("supprimer").build();
        menuCopier = MenuItemBuilder.create().text("copier").build();
        menuCouper = MenuItemBuilder.create().text("couper").build();
        menuColler = MenuItemBuilder.create().text("coller").build();

        Image image = new Image(EditeurAlgoESI.class.getResourceAsStream("images/add(7).png"));
        ImageView picture = new ImageView(image);
        picture.setFitHeight(15);
        picture.setFitWidth(15);
        menuAjouter = MenuBuilder.create()
                .text("ajouter")
                .items(menuIEcrire, menuILire, menuIAffecter, menuIConditionnelle, menuIAlternative, menuIBclPour, menuIBclTQ, menuIBclRepeter, menuIAppelProc)
                .build();
        menuMiseAjour = MenuBuilder.create()
                .graphic(picture)
                .items(menuAjouter, menuSupprimer, menuCopier, menuCouper, menuColler, menuComent).build();
        getMenus().addAll(menuMiseAjour);
        menuMiseAjour.setStyle("-fx-background-color:white;");
        getStyleClass().add("icMAJ");
    }
}
