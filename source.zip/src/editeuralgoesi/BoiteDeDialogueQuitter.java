/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import java.util.Locale;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.StageStyle;

/**
 *
 * @author mohammed_bey
 */
public class BoiteDeDialogueQuitter {

//    private final Action response;
    private final Alert response;

    public Alert getResponse() {
        return response;
    }

    public BoiteDeDialogueQuitter() {
        Locale language = new Locale("fr", "FR");
        Locale.setDefault(language);
//        response = Dialogs.create()
//                .title("Quitter")
//                .masthead(null)
//                //.graphic(new ImageView(new Image(getClass().getResource("images/info.png").toExternalForm())))
//                .actions(Dialog.ACTION_YES, Dialog.ACTION_NO, Dialog.ACTION_CANCEL)
//                .styleClass(Dialog.STYLE_CLASS_NATIVE)
//                .message("Voulez-vous sauvegarder ?")
//                .showConfirm();

        response = new Alert(Alert.AlertType.CONFIRMATION, "", ButtonType.YES, ButtonType.NO, ButtonType.CANCEL);
        response.setTitle("Fermeture du programme");
        response.getDialogPane().setContentText("Voulez-vous sauvegarder ?");
        response.getDialogPane().getStylesheets().add(EditeurAlgoESI.class.getResource("AlertStyleModified.css").toExternalForm());
        response.getDialogPane().getStyleClass().add("AlertStyleModified");
        response.initStyle(StageStyle.UTILITY);
        response.showAndWait();
    }
}
