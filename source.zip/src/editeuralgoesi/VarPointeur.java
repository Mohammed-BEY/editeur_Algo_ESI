/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.contPrinc;
import javafx.event.Event;

/**
 *
 * @author Mohammed_BEY
 */
public class VarPointeur extends Variable {

    public VarPointeur(char c) {
        super();
        tField1.setPromptText("nom_de_la_variable");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        label1.setText(" pointeur vers ");
        label1.setStyle("-fx-text-fill:rgb(30,21,134);");
        switch (c) {
            case 'v'://la rubrique des variables
                icMajEnv.menuAjouter.setText("ajouter une variable");
                break;
            case 'e'://dans l'enregistrement
                icMajEnv.menuAjouter.setText("ajouter un champ");
                icMajEnv.menuAjouter.getItems().add(icMajEnv.menuITypeEnreg);
                icMajEnv.menuSimple.setText("variable simple");
                icMajEnv.menuChaine.setText("variable chaine");
                icMajEnv.menuTableau.setText("variable tableau");
                break;
            default:
                throw new AssertionError();
        }
        //*** *****************************Liste des types Enregistrement*****************************/
        typesElements.setId("typesVarList");
        typesElements.setItems(typesElementsList);
        getChildren().addAll(tField1, label1, typesElements, icMajEnv);
        //redéfinir la méthode qui met à jour les types Enregistrement
        typesElements.setOnMouseClicked((Event t) -> {
            typesElementsList.clear();
            indice = contPrinc.getChildren().indexOf(typesElements.getParent());
            declarerTypes(indice);
        });
    }

    @Override
    public String toString() {
        String resultat = "";
        resultat += tField1.getText() + " : " /*+ typesElements.getEditor().getText()*/;
        return resultat;
    }

    @Override
    public void setContenu(String str) {
        String[] tab = str.split("#");
        int i = 1;
        if (i < tab.length) {
            tField1.setText(tab[i]);
            i++;
        }
        if (i < tab.length) {
//            typesElements.setValue(tab[i]);
        }
    }

    @Override
    protected String coColler() {
        return "<varS>" + "#" + tField1.getText() + "#" + typesElements.getEditor().getText();
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return tField1.getText() + " : " + typePascal(typesElements.getEditor().getText()) + ";";
    }

    //cette methode permet de mettre tous les types declrés dans la liste des types jusqu'à l'indeice : index
    private void declarerTypes(int index) {
        int i = 3;
        if (index > 0) {
            while (i < index && !(contPrinc.getChildren().get(i) instanceof VariableEntete)) {
                if (contPrinc.getChildren().get(i) instanceof TypeEnregistrementEntete) {
                    ((TypeEnregistrementEntete) contPrinc.getChildren().get(i)).declarer();
                }
                i++;
            }
        }
    }
}
