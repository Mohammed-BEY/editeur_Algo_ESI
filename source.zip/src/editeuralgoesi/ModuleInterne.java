/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.contPrinc;
import static editeuralgoesi.FXMLDocumentController.undo;
import javafx.event.ActionEvent;
import javafx.scene.control.ButtonType;
import javafx.scene.control.MenuItem;

/**
 *
 * @author mohammed_bey
 */
public abstract class ModuleInterne extends Modules {

    private BoiteDeDialogueModule root = null;
    private final MenuItem menuReduire;

    public ModuleInterne() {
        super();
        menuReduire = new MenuItem("reduire");
        icMajEnv.menuMAJ.getItems().add(menuReduire);
        //*** ***************Desactiver les oprions inutiles du menu de mise à* jour**********************/
        icMajEnv.menuMAJ.getItems().removeAll(icMajEnv.menuAjouter, icMajEnv.menuComent, icMajEnv.menuPtr);
        /**
         * ****************Gestion des Evenements*****************************
         */
        //*** *********************Supprimer un module*****************************/
        icMajEnv.menuSupprimer.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent());
            supprimerEl(indice);
        });
        menuReduire.setOnAction((ActionEvent ae) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent());
            reduire(indice);
        });
    }

    @Override
    protected void supprimerEl(int index) {
        Information info = new Information();//renvoie le contenu de panelAnchor
        pile.empiler(info.algoAsauvegarder());
        undo.setDisable(pile.estVide());

        root = new BoiteDeDialogueModule();
        if (root.getResponse().getResult() == ButtonType.OK) {
            int cpt = 1;//compter le nombre de lignes dans le module à supprimer
            while (!(cpt == 0)) {
                supprimer(index);
                if (contPrinc.getChildren().get(index) instanceof ModuleFonctionIntEntete || contPrinc.getChildren().get(index) instanceof ModuleProcedureIntEntete) {
                    cpt++;
                } else if (contPrinc.getChildren().get(index) instanceof FinModule) {
                    cpt--;
                }
            }
            supprimer(index);//supprimer la fin du Module
            if ((contPrinc.getChildren().get(index - 1) instanceof VariableEntete || contPrinc.getChildren().get(index - 1) instanceof VariableSimple || contPrinc.getChildren().get(index - 1) instanceof VarChaineDeCar || contPrinc.getChildren().get(index - 1) instanceof VarStructureTab) && (contPrinc.getChildren().get(index) instanceof DEBUT)) {
                ajouterEL(new ModuleEntete(), index);
            }
        }
    }

    //redefinir la methode de telle sorte qu'elle n'emplie pas
    private void supprimer(int index) {
        contPrinc.getChildren().remove(index);
        int j = contPrinc.getChildren().size();
        for (int i = index; i < j; i++) {
            if (contPrinc.getChildren().get(index) instanceof DebutModule || contPrinc.getChildren().get(index) instanceof FinModule) {
                contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i).getLayoutY() - 21 * 2);
            } else {
                contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i).getLayoutY() - 21);
            }
        }
    }

    //La methode qui permet de reduire la partie Environnement et ne garder que la partie Corps
    private void reduire(int index) {
        int j = contPrinc.getChildren().size(),
                cptMod = 0/*compte le nombre de modules se trouvant dans l'Algo*/, cpt = 0;
        int indInitial = index;
        index++;
        if (menuReduire.getText().equals("reduire")) {//on veut reduire la partie Environnement
            while (!(contPrinc.getChildren().get(index) instanceof FinModule) || (cpt != 0)) {
                if (contPrinc.getChildren().get(index) instanceof ModuleFonctionIntEntete || contPrinc.getChildren().get(index) instanceof ModuleProcedureIntEntete) {
                    cptMod++;
                    cpt++;
                } else if (contPrinc.getChildren().get(index) instanceof FinModule) {
                    cpt--;
                }
                contPrinc.getChildren().get(index).setVisible(false);
                index++;
            }
            for (int i = index; i < j; i++) {
                contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i).getLayoutY() - 21 * (index - indInitial - 1 + cptMod));
            }
            menuReduire.setText("agrandir");
        } else {
            while (!(contPrinc.getChildren().get(index) instanceof FinModule) || (cpt != 0)) {
                if (contPrinc.getChildren().get(index) instanceof ModuleFonctionIntEntete || contPrinc.getChildren().get(index) instanceof ModuleProcedureIntEntete) {
                    cptMod++;
                    cpt++;
                } else if (contPrinc.getChildren().get(index) instanceof FinModule) {
                    cpt--;
                }
                contPrinc.getChildren().get(index).setVisible(true);
                index++;
            }
            for (int i = index; i < j; i++) {
                contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i).getLayoutY() + 21 * (index - indInitial - 1 + cptMod));
            }
            menuReduire.setText("reduire");
        }
    }
}
