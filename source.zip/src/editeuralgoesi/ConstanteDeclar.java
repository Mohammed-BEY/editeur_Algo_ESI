/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

/**
 *
 * @author mohammed_bey
 */
//la constante de declaration
public class ConstanteDeclar extends Constante {

    public ConstanteDeclar() {
        super();
        label1.setText(" = ");
        label1.setStyle("-fx-text-fill:rgb(30,21,134);");
        tField1.setPromptText("Identificateur_constante");
        tField2.setPromptText("Valeur");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        tField2.setPrefWidth(longChar(tField2.getPromptText()));
        getChildren().addAll(tField1, label1, tField2, icMajEnv);
    }

    @Override
    public String toString() {
        String resultat = "";
        resultat += tField1.getText() + " = " + tField2.getText();
        return resultat;
    }

    @Override
    public void setContenu(String str) {
        String[] tab = str.split("#");
        int i = 1;
        if (i < tab.length) {
            tField1.setText(tab[i]);
            i++;
        }
        if (i < tab.length) {
            tField2.setText(tab[i]);
        }
    }

    @Override
    protected String coColler() {
        return "<cteD>" + "#" + tField1.getText() + "#" + tField2.getText();
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return tField1.getText() + " = " + tField2.getText() + ";";
    }
}
