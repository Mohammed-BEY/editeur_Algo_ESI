/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

/**
 *
 * @author mohammed_bey
 */
public class BouclePourDebut extends LesDebuts {

    public BouclePourDebut() {
        super();
        label1.setText("DPOUR");
        this.getChildren().addAll(label1, icMajCorps);
    }

    @Override
    public String toString() {
        String resultat = "";
        resultat += "DPOUR";
        return resultat;
    }

    @Override
    protected String coColler() {
        return "<bcpD>";
    }
}
