/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

//La classe de la fin d'une alternative
public class AlternativeFSI extends LesFins {

    public AlternativeFSI() {
        label1.setText("FSI");
        label1.getStyleClass().add("labDebFinBoucle");
        getChildren().addAll(label1);
    }

    @Override
    public String toString() {
        String resultat = "";
        resultat += "FSI";
        return resultat;
    }

    @Override
    protected String coColler() {
        return "<altC>";
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return "End";
    }
}
