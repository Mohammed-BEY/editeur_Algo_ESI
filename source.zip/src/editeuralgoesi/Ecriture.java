/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.undo;
import java.util.ArrayList;

/**
 *
 * @author mohammed_bey
 */
public class Ecriture extends Corps {

    public Ecriture() {
        super();
        label1.setText("Ecrire ( ");
        label2.setText(" )");
        tField1.setPromptText("f,p1, ..., pn");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        getChildren().addAll(label1, tField1, label2, icMajCorps);

    }

    //La methode de suppression
    @Override
    protected void supprimerEl(int index) {
        Information info = new Information();//renvoie le contenu de panelAnchor
        pile.empiler(info.algoAsauvegarder());
        undo.setDisable(pile.estVide());
        super.supprimerEl(index);
    }

    @Override
    public String toString() {
        return "Ecrire (" + tField1.getText() + ")";
    }

    @Override
    protected String coColler() {
        return "<ecrA>" + "#" + tField1.getText();
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return "writeln (" + tField1.getText() + ");";
    }

    @Override
    protected void setContenu(String str) {
        String[] tab = str.split("#");
        int i = 1;
        if (i < tab.length) {
            tField1.setText(tab[i]);
        }
    }

    @Override
    protected String traiter(Object[] listListesDecl) {
        String result = "";
        ArrayList<String> messEcrit = aTraiter(tField1.getText());
        for (String string : messEcrit) {
            String tabSpace[] = string.split(" ");
            for (String string2 : tabSpace) {
                if (!string2.equals("ET") && !string2.equals("eT") && !string2.equals("Et") && !string2.equals("et")
                        && !string2.equals("OU") && !string2.equals("oU") && !string2.equals("Ou") && !string2.equals("ou")
                        && !string2.equals("DIV") && !string2.equals("div")
                        && !string2.equals("MOD") && !string2.equals("mod")
                        && !string2.equals("\\+") && !string2.equals("-") && !string2.equals("\\*") && !string2.equals("/")
                        && !string2.equals("VRAI") && !string2.equals("vrai")
                        && !string2.equals("FAUX") && !string2.equals("faux")) {//c'est une variable
                    String[] tokens = string2.split("['\\(' '\\)' '\\[' '\\]' ',' '+' '\\-' '/' '*']");
                    for (String string3 : tokens) {
                        if (!string3.equals("")) {
                            result += messVerification(string3, listListesDecl);
                        }
                    }
                }
            }
        }
        indice = result.lastIndexOf("\n");
        try {
            result = result.substring(0, indice);
        } catch (StringIndexOutOfBoundsException ex) {
        }
        return result;
    }

    private ArrayList<String> aTraiter(String chaine) {
        ArrayList<String> result = new ArrayList<>();
        String tmp = "";
        int i = 0, longueur = chaine.length();
        chaine = chaine.replaceFirst("\t", "");
        while (i < chaine.length()) {
            while ((i < longueur) && (chaine.charAt(i) == ' ')) {//avancer le curseur tant qu'il y a d'espaces
                i++;
            }//Espaces enlevés
            //tester le 1er caractère 
            if (chaine.charAt(i) == '\'') {//c'est un message                
                i++;
                while ((i < longueur) && (chaine.charAt(i) != '\'')) {//déterminer tout le message
                    i++;
                }
                i++;
                while ((i < longueur) && (chaine.charAt(i) == ' ')) {//avancer le curseur tant qu'il y a d'espaces
                    i++;
                }//Espaces enlevés après le message et on est à la virgule 
                i++;//on est après la virgule s'il y en a
            } else {//c'est une variable ==> chercher la virgule correspondante ou fin de chaine
                tmp = "";
                while ((i < chaine.length()) && (chaine.charAt(i) != ',')) {
                    tmp += chaine.charAt(i);
                    i++;
                }
                result.add(tmp);
                i++;//on est après la virgule
            }
        }
        return result;
    }

    @Override
    protected String designation() {
        return "une action de 'Ecriture'";
    }

    //Mettre les chmps de saisie en couleur rouge quand il y a une erreur détectée
    @Override
    protected void colorerChampSaisie() {
        tField1.getStyleClass().add("error");
    }

    //Enlever la couleur rouge des champs de saisie
    @Override
    protected void enleverCouleurChampSaisie() {
        tField1.getStyleClass().remove("error");
    }
}
