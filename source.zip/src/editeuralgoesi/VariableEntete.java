/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.contPrinc;

/**
 *
 * @author mohammed_bey
 */
public class VariableEntete extends Variable {

    public VariableEntete() {
        super();
        label1.setText("Variables");
        label1.getStyleClass().add("labMotSys");
        getChildren().addAll(label1, icMajEnv);
        icMajEnv.menuSupprimer.setDisable(true);
        icMajEnv.menuAjouter.setText("ajouter une variable");
    }

    @Override
    public String toString() {
        String resultat = "";
        if (varExist(contPrinc.getChildren().indexOf(this))) {
            resultat = "Variables";
        }
        return resultat;
    }

    @Override
    protected String coColler() {
        return "<varE>";
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        String result = "";
        if (varExist(contPrinc.getChildren().indexOf(this))) {
            result = "var";
        }
        return result;
    }

    //redefinir la methode de telle sorte qu'elle ne fait rien
    @Override
    protected void supprimerEl(int index) {
    }
}
