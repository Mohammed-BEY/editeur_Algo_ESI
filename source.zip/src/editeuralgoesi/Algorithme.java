/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.contPrinc;
import java.util.HashMap;
import java.util.Map;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;

/**
 *
 * @author mohammed_bey
 */
public class Algorithme extends HBox {

    protected TextField tField1, tField2, tField3;
    protected Label label1, label2, label3, label4;

    protected int indice;
    protected PILE pile = new PILE();//la pile de l'operation undo-redo

    //tableau asociatif contenant la longueur de chaque caractère en dans le TextField
    private final Map<Character, Double> tab = new HashMap<>();

    //Table qui contient lesm ots clès qui ne doivent pas être utilisés
    //String1: le mot clé
    //String2: sa traduction en Pascal
    protected final ObservableList<String> tabMotsCles = FXCollections.observableArrayList();

    public Algorithme() {
        remplirMapLengthCahr();//remplir le tableau associatif
        tField1 = new TextField();
        tField2 = new TextField();
        tField3 = new TextField();
        label1 = new Label();
        label2 = new Label();
        label3 = new Label();
        label4 = new Label();
        //remplir la liste des mots clés
        this.remplirMotsCles();
        //mettre les champs de saisie en taille dynamique
        tField1.textProperty().addListener((ObservableValue<? extends String> ov, String t, String t1) -> {
            if (tField1.getText().length() == 0) {
                tField1.setPrefWidth(longChar(tField1.getPromptText()));
            } else {
                tField1.setPrefWidth(tField1.getLength() * 6.5 + 12);
            }
        });

        tField2.textProperty().addListener((ObservableValue<? extends String> ov, String t, String t1) -> {
            if (tField2.getText().length() == 0) {
                tField2.setPrefWidth(longChar(tField2.getPromptText()));
            } else {
                tField2.setPrefWidth(tField2.getLength() * 6.5 + 12);
            }
        });
        tField3.textProperty().addListener((ObservableValue<? extends String> ov, String t, String t1) -> {
            if (tField3.getText().length() == 0) {
                tField3.setPrefWidth(longChar(tField3.getPromptText()));
            } else {
                tField3.setPrefWidth(tField3.getLength() * 6.5 + 12);
            }
        });
        //Gestion des evenements
        //lister les variables existantes à l'utilisateur
        ControlesSyntaxiques ctrl = new ControlesSyntaxiques();
        ContextMenu cm1 = new ContextMenu(), cm2 = new ContextMenu(), cm3 = new ContextMenu();
        //ajouter la variable choisie dans le champ de saisie
        cm1.setOnAction((ActionEvent event) -> {
            String str = ((MenuItem) event.getTarget()).getText();
            tField1.setText(tField1.getText(0, tField1.getCaretPosition()) + str
                    + tField1.getText(tField1.getCaretPosition(), tField1.getText().length()));
        });
        cm2.setOnAction((ActionEvent event) -> {
            String str = ((MenuItem) event.getTarget()).getText();
            tField2.setText(tField2.getText(0, tField2.getCaretPosition()) + str
                    + tField2.getText(tField2.getCaretPosition(), tField2.getText().length()));
        });
        cm3.setOnAction((ActionEvent event) -> {
            String str = ((MenuItem) event.getTarget()).getText();
            tField3.setText(tField3.getText(0, tField3.getCaretPosition()) + str
                    + tField3.getText(tField3.getCaretPosition(), tField3.getText().length()));
        });
        //déplacer la souris vers la prochaine ligne quand on clique sur Entrer
        KeyCodeCombination combo = new KeyCodeCombination(KeyCode.L, KeyCodeCombination.CONTROL_DOWN);
        tField1.setOnKeyPressed((KeyEvent e) -> {
            if (combo.match(e)) {
                indice = contPrinc.getChildren().indexOf(tField1.getParent());
                ctrl.remplirListVar(position(indice));
                ctrl.remplirConst(position(indice));
                ctrl.getVariablesListe().remove(ctrl.getVariablesListe().size() - 1);
                //créer un menu des variables
                cm1.getItems().clear();
                MenuItem[] menuItem = new MenuItem[ctrl.getVariablesListe().size()];
                for (int i = 0; i < ctrl.getVariablesListe().size(); i++) {
                    menuItem[i] = new MenuItem((String) ctrl.getVariablesListe().get(i));
                    cm1.getItems().add(menuItem[i]);
                }
                cm1.show(tField1, Side.BOTTOM, 0, -10);
            } else if (e.getCode().equals(KeyCode.ENTER)) {
                com.sun.glass.ui.Robot robot = com.sun.glass.ui.Application.GetApplication().createRobot();
                robot.mouseMove(21, (int) tField1.getParent().getLayoutY() + 141 + 15);//141:espace entre le debut de l'editeur et la position 0 de l'ecran
            }
        });
        tField2.setOnKeyPressed((KeyEvent e) -> {
            if (combo.match(e)) {
                indice = contPrinc.getChildren().indexOf(tField2.getParent());
                ctrl.remplirListVar(position(indice));
                ctrl.getVariablesListe().remove(ctrl.getVariablesListe().size() - 1);
                //créer un menu des variables
                cm2.getItems().clear();
                MenuItem[] menuItem = new MenuItem[ctrl.getVariablesListe().size()];
                for (int i = 0; i < ctrl.getVariablesListe().size(); i++) {
                    menuItem[i] = new MenuItem((String) ctrl.getVariablesListe().get(i));
                    cm2.getItems().add(menuItem[i]);
                }
                cm2.show(tField2, Side.BOTTOM, 0, -10);
            } else if (e.getCode().equals(KeyCode.ENTER)) {
                com.sun.glass.ui.Robot robot = com.sun.glass.ui.Application.GetApplication().createRobot();
                robot.mouseMove(21, (int) tField2.getParent().getLayoutY() + 141 + 15);//141:espace entre le debut de l'editeur et la position 0 de l'ecran
            }
        });
        tField3.setOnKeyPressed((KeyEvent e) -> {
            if (combo.match(e)) {
                indice = contPrinc.getChildren().indexOf(tField3.getParent());
                ctrl.remplirListVar(position(indice));
                ctrl.getVariablesListe().remove(ctrl.getVariablesListe().size() - 1);
                //créer un menu des variables
                cm3.getItems().clear();
                MenuItem[] menuItem = new MenuItem[ctrl.getVariablesListe().size()];
                for (int i = 0; i < ctrl.getVariablesListe().size(); i++) {
                    menuItem[i] = new MenuItem((String) ctrl.getVariablesListe().get(i));
                    cm3.getItems().add(menuItem[i]);
                }
                cm3.show(tField3, Side.BOTTOM, 0, -10);
            } else if (e.getCode().equals(KeyCode.ENTER)) {
                com.sun.glass.ui.Robot robot = com.sun.glass.ui.Application.GetApplication().createRobot();
                robot.mouseMove(21, (int) tField3.getParent().getLayoutY() + 141 + 15);//141:espace entre le debut de l'editeur et la position 0 de l'ecran
            }
        });
        //mise en forme
        tField1.getStyleClass().add("textfield");
        tField2.getStyleClass().add("textfield");
        tField3.getStyleClass().add("textfield");
        tField1.setPrefHeight(21);
        tField1.setAlignment(Pos.TOP_LEFT);
        tField2.setPrefHeight(21);
        tField2.setAlignment(Pos.TOP_LEFT);
        tField3.setPrefHeight(21);
        tField3.setAlignment(Pos.TOP_LEFT);
        label1.setPrefHeight(21);
        label1.setAlignment(Pos.TOP_LEFT);
        label2.setPrefHeight(21);
        label2.setAlignment(Pos.TOP_LEFT);
        label3.setPrefHeight(21);
        label3.setAlignment(Pos.TOP_LEFT);
        label4.setPrefHeight(21);
        label4.setAlignment(Pos.TOP_LEFT);
        Label labIndice = new Label();
        labIndice.setPrefHeight(21);
        labIndice.setAlignment(Pos.TOP_LEFT);
        getChildren().add(0, labIndice);
        //centrer les elements de HBox
        setAlignment(Pos.TOP_LEFT);
    }

    //La methode d'ajout d'un element
    protected void ajouterEl(HBox el, int index) {
    }

    //La methode qui permet de remplir les champs de l'objet à partie de la liste de coColler
    protected void setContenu(String str) {
    }

    //La methode qui permet de copier un element
    protected void copier(int index) {
    }

    //La methode de couper
    protected void couper(int index) {
    }

    protected void coller(int index) {
    }

    //supprimer un element
    protected void supprimerEl(int index) {
    }

    //La methode qui permet de recuperer le contenu textuel de l'objet pour le mettre dans la liste de copier-couper/coller
    protected String coColler() {
        return "";
    }

    //La methode de traduction en Pascal
    protected String tradPascal() {
        return "";
    }

    //La methode de contrôle sysntaxique
    protected String traiter(Object[] listListesDecl) {
        return "";
    }

    //retourne la longueur du caractére
    protected double longChar(String str) {
        double result = 0;
        for (int i = 0; i < str.length(); i++) {
            if (tab.containsKey(str.charAt(i))) {
                result += tab.get(str.charAt(i));
            } else {
                result += 7.0;
            }
        }
        return result;
    }

    private void remplirMapLengthCahr() {
        tab.put('a', 6.3);
        tab.put('b', 7.0);
        tab.put('c', 6.3);
        tab.put('d', 7.0);
        tab.put('e', 6.3);
        tab.put('f', 4.7);
        tab.put('g', 7.0);
        tab.put('h', 7.0);
        tab.put('i', 4.0);
        tab.put('j', 4.0);
        tab.put('k', 7.0);
        tab.put('l', 4.0);
        tab.put('m', 11.3);
        tab.put('n', 7.0);
        tab.put('o', 7.0);
        tab.put('p', 7.0);
        tab.put('q', 7.0);
        tab.put('r', 4.7);
        tab.put('s', 5.5);
        tab.put('t', 4.0);
        tab.put('u', 7.0);
        tab.put('v', 7.0);
        tab.put('w', 10.4);
        tab.put('x', 7.0);
        tab.put('y', 7.0);
        tab.put('z', 6.3);
        //pour les lettres majuscules
        tab.put('A', 10.3);
        tab.put('B', 9.7);
        tab.put('C', 9.7);
        tab.put('D', 10.5);
        tab.put('E', 8.9);
        tab.put('F', 8.0);
        tab.put('G', 10.7);
        tab.put('H', 10.2);
        tab.put('I', 4.8);
        tab.put('J', 5.5);
        tab.put('K', 10.7);
        tab.put('L', 9.0);
        tab.put('M', 12.3);
        tab.put('N', 10.5);
        tab.put('O', 10.7);
        tab.put('P', 7.8);
        tab.put('Q', 10.5);
        tab.put('R', 9.5);
        tab.put('S', 7.8);
        tab.put('T', 8.8);
        tab.put('U', 10.5);
        tab.put('V', 10.5);
        tab.put('W', 14.0);
        tab.put('X', 10.7);
        tab.put('Y', 10.3);
        tab.put('Z', 8.8);
        //pour les caractéres speciaux
        tab.put('à', 6.3);
        tab.put('é', 6.3);
        tab.put('è', 6.3);
        tab.put('ù', 7.0);
        tab.put('ô', 7.0);
        tab.put('â', 6.3);
        tab.put('î', 4.0);
        tab.put('û', 7.0);
        tab.put('ê', 6.3);
        tab.put('ĵ', 4.0);
        tab.put('ŷ', 7.0);
        tab.put('^', 7.0);
        tab.put('È', 8.9);
        tab.put('À', 10.3);
        tab.put('É', 8.9);
        tab.put('[', 4.85);
        tab.put(']', 4.85);
        tab.put('{', 6.7);
        tab.put('}', 6.7);
        tab.put(' ', 3.5);
        tab.put('.', 3.5);
        tab.put(',', 3.5);
        tab.put(';', 4.0);
        tab.put(':', 4.0);
        tab.put('=', 8.0);
        tab.put('\'', 2.7);
        tab.put('"', 6.0);
        tab.put('\\', 4.3);
        tab.put('*', 7.0);
        tab.put('+', 8.0);
        tab.put('-', 5.0);
        tab.put('!', 4.8);
        tab.put('@', 13.8);
        tab.put('#', 7.2);
        tab.put('$', 7.4);
        tab.put('%', 12.4);
        tab.put('?', 6.5);
        tab.put('&', 11.5);
        tab.put(')', 4.8);
        tab.put('(', 4.8);
        tab.put('_', 7.0);
        tab.put('|', 3.0);
        tab.put('<', 8.0);
        tab.put('>', 8.0);
        //les chiffres
        tab.put('0', 7.0);
        tab.put('1', 7.0);
        tab.put('2', 7.0);
        tab.put('3', 7.0);
        tab.put('4', 7.0);
        tab.put('5', 7.0);
        tab.put('6', 7.0);
        tab.put('7', 7.0);
        tab.put('8', 7.0);
        tab.put('9', 7.0);
    }

    //retourner l'indice de la liste des variables qu'il faut r.cupérer ses elements
    private int position(int i) {
        boolean bool = false;
        while (!bool) {
            if (contPrinc.getChildren().get(i) instanceof DEBUT) {//on est dans le corps de l'Algorithme
                //chercher l'entête des variables globales
                i = 0;
                while (!(contPrinc.getChildren().get(i) instanceof VariableEntete)) {
                    i++;
                }
                i++;
                bool = true;
            } else if ((contPrinc.getChildren().get(i) instanceof DebutModule)) {//on est dans un module
                int cpt = 0;
                while ((cpt != 0) || (!(contPrinc.getChildren().get(i) instanceof VariableEnteteModule))) {
                    if ((contPrinc.getChildren().get(i) instanceof FinModule)) {
                        cpt++;
                    } else if ((contPrinc.getChildren().get(i) instanceof ModuleFonctionIntEntete)
                            || (contPrinc.getChildren().get(i) instanceof ModuleProcedureIntEntete)) {
                        cpt--;
                    }
                    i--;
                }
                i++;
                bool = true;
            }
            i--;
        }
        return i;
    }

    //remplir la liste des mots clés
    private void remplirMotsCles() {
        tabMotsCles.add("cos");
        tabMotsCles.add("sin");
        tabMotsCles.add("tan");
        tabMotsCles.add("cotan");
        tabMotsCles.add("allouer");
        tabMotsCles.add("suivant");
        tabMotsCles.add("var");
        tabMotsCles.add("nil");
        tabMotsCles.add("begin");
        tabMotsCles.add("sqrt");
        tabMotsCles.add("sqr");
    }

    //Mettre les chmps de saisie en couleur rouge quand il y a une erreur détectée
    protected void colorerChampSaisie() {
    }

    //Enlever la couleur rouge des champs de saisie
    protected void enleverCouleurChampSaisie() {
    }
}
