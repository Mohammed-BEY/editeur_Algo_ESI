/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import javafx.collections.ObservableList;
import javafx.scene.control.TextField;

/**
 *
 * @author mohammed_bey
 */
public class BouclePourEntete extends LesEntetes {

    public BouclePourEntete() {
        label1.setText("Pour ");
        label2.setText(" Allant De ");
        label3.setText(" A ");
        label4.setText(" Faire");

        label3.setStyle("-fx-text-fill:rgb(30,21,134);");
        label4.setStyle("-fx-text-fill:rgb(30,21,134);");

        tField1.setPromptText("variable_de_contrôle");
        tField2.setPromptText("valeur_initiale");
        tField3.setPromptText("valeur_finale");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        tField2.setPrefWidth(longChar(tField2.getPromptText()));
        tField3.setPrefWidth(longChar(tField3.getPromptText()));
        getChildren().addAll(label1, tField1, label2, tField2, label3, tField3, label4, icMajCorps);
        menuTransBcl.getItems().remove(menuEnBclP);
        icMajCorps.menuMiseAjour.getItems().add(menuTransBcl);
    }

    @Override
    public String toString() {
        String result = "";
        result += "Pour " + tField1.getText() + " Allant De " + tField2.getText()
                + " A " + tField3.getText() + "Faire";
        return result;
    }

    @Override
    public void setContenu(String str) {
        String[] tab = str.split("#");
        int i = 1;
        if (i < tab.length) {
            tField1.setText(tab[i]);
            i++;
        }
        if (i < tab.length) {
            tField2.setText(tab[i]);
            i++;
        }

        if (i < tab.length) {
            tField3.setText(tab[i]);
        }
    }

    @Override
    protected String traiter(Object[] listListesDecl) {
        String result = "", tmp = "";
        //Traitement du deuxieme champ
        String premierChamp = tField1.getText();
        tmp = traiterPrChamp(premierChamp, (ObservableList) listListesDecl[0]);
        if (tmp.equals("")) {
            enleverCouleurChampSaisie(tField1);
        } else {
            colorerChampSaisie(tField1);
        }
        result += tmp;
        //traiter la valeur initiale si c'est une variable
        String deuxiemeChamp = tField2.getText();
        tmp = traiterDeEtTroisiemeChamp(deuxiemeChamp, listListesDecl);
        if (tmp.equals("")) {
            enleverCouleurChampSaisie(tField2);
        } else {
            colorerChampSaisie(tField2);
        }
        result += tmp;
        //traiter la valeur finale si c'est une variable
        String troisiemeChamp = tField3.getText();
        tmp = traiterDeEtTroisiemeChamp(troisiemeChamp, listListesDecl);
        if (tmp.equals("")) {
            enleverCouleurChampSaisie(tField3);
        } else {
            colorerChampSaisie(tField3);
        }
        result += tmp;
        indice = result.lastIndexOf("\n");
        try {
            result = result.substring(0, indice);
        } catch (StringIndexOutOfBoundsException ex) {
        }
        return result;
    }

    //traitement du premier champ
    private String traiterPrChamp(String str, ObservableList listV) {
        String result = "";
        str = str.replaceAll(" ", "");//enlever les blencs
        str = str.replaceAll("\t", "");//enlever les tabulations
        //traiter la variable de contrôle
        if (!str.equals("") && !listV.contains(str)) {
            result += "Attention ! La variable de controle '" + str + " ',utilisée dans une boucle 'Pour',  n'a pas été delarée" + "\n";
        }
        return result;
    }

    //traitement du deuxième champ
    private String traiterDeEtTroisiemeChamp(String str, Object[] listListesDecl) {
        String result = "";
        String tabSpace[] = str.split(" ");
        for (String string2 : tabSpace) {
            if (!string2.equals("ET") && !string2.equals("eT") && !string2.equals("Et") && !string2.equals("et")
                    && !string2.equals("OU") && !string2.equals("oU") && !string2.equals("Ou") && !string2.equals("ou")
                    && !string2.equals("DIV") && !string2.equals("div")
                    && !string2.equals("MOD") && !string2.equals("mod")
                    && !string2.equals("\\+") && !string2.equals("-") && !string2.equals("\\*") && !string2.equals("/")
                    && !string2.equals("VRAI") && !string2.equals("vrai")
                    && !string2.equals("FAUX") && !string2.equals("faux")) {//c'est une variable
                String[] tokens = string2.split("['\\(' '\\)' '\\[' '\\]' ',' '+' '\\-' '/' '*']");
                for (String string3 : tokens) {
                    if (!string3.equals("")) {
                        result += messVerification(string3, listListesDecl);
                    }
                }
            }
        }
        return result;
    }

    @Override
    protected String coColler() {
        return "<bcpE>" + "#" + tField1.getText() + "#" + tField2.getText() + "#" + tField3.getText();
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return "for " + tField1.getText() + " := " + tField2.getText() + " to " + tField3.getText() + " do";
    }

    @Override
    protected String designation() {
        return "une boucle 'Pour'";
    }

    //Mettre les chmps de saisie en couleur rouge quand il y a une erreur détectée
    protected void colorerChampSaisie(TextField tField) {
        tField.getStyleClass().add("error");
    }

    //Enlever la couleur rouge des champs de saisie
    protected void enleverCouleurChampSaisie(TextField tField) {
        tField.getStyleClass().remove("error");
    }
}
