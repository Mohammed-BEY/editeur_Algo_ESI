/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

/**
 *
 * @author mohammed_bey
 */
public class VariableSimple extends Variable {

    public VariableSimple(char c) {
        super();
        tField1.setPromptText("nom_de_la_variable");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        label1.setText(" : ");
        label1.setStyle("-fx-text-fill:rgb(30,21,134);");
        switch (c) {
            case 'v'://la rubrique des variables
                icMajEnv.menuAjouter.setText("ajouter une variable");
                break;
            case 'e'://dans l'enregistrement
                icMajEnv.menuAjouter.setText("ajouter un champ");
                icMajEnv.menuAjouter.getItems().add(icMajEnv.menuITypeEnreg);
                icMajEnv.menuSimple.setText("variable simple");
                icMajEnv.menuChaine.setText("variable chaine");
                icMajEnv.menuTableau.setText("variable tableau");
                break;
            default:
                throw new AssertionError();
        }
        //*** *****************************Liste des types des variables*****************************/
        typesElements.setId("typesVarList");
        typesElements.setItems(typesElementsList);
        getChildren().addAll(tField1, label1, typesElements, icMajEnv);
    }

    @Override
    public String toString() {
        String resultat = "";
        resultat += tField1.getText() + " : " + typesElements.getEditor().getText();
        return resultat;
    }

    @Override
    public void setContenu(String str) {
        String[] tab = str.split("#");
        int i = 1;
        if (i < tab.length) {
            tField1.setText(tab[i]);
            i++;
        }
        if (i < tab.length) {
            typesElements.setValue(tab[i]);
        }
    }

    @Override
    protected String coColler() {
        return "<varS>" + "#" + tField1.getText() + "#" + typesElements.getEditor().getText();
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return tField1.getText() + " : " + typePascal(typesElements.getEditor().getText()) + ";";
    }
}
