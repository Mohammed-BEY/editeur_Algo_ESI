/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.contPrinc;
import static editeuralgoesi.FXMLDocumentController.undo;
import javafx.event.ActionEvent;
import javafx.scene.layout.HBox;

/**
 *
 * @author mohammed_bey
 */
public class Modules extends Environnement {

    public Modules() {
        icMajEnv.menuAjouter.setText("ajouter un module");
        //*****************Gestion des evenements*******************************/
        //****************Ajout d'un module interne : Fonction******************/
        icMajEnv.menuFonInterne.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            ajouterMod("modO", indice);
        });
        //****************Ajout d'un module interne : Procedure*****************/
        icMajEnv.menuProInterne.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            ajouterMod("modP", indice);
        });
        //****************Ajout d'un module externe : Fonction******************/
        icMajEnv.menuFonExterne.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            ajouterMod("modX", indice);
        });
        //****************Ajout d'un module externe : Procedure*****************/
        icMajEnv.menuProExterne.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            ajouterMod("modY", indice);
        });
    }

    //La methode d'ajout d'un element
    protected void ajouterEL(HBox el, int index) {
        contPrinc.getChildren().add(index, el);
        int j = contPrinc.getChildren().size();
        for (int i = index; i < j; i++) {
            if (contPrinc.getChildren().get(i) instanceof DEBUT || contPrinc.getChildren().get(i) instanceof DebutModule || contPrinc.getChildren().get(i) instanceof FinAlgo) {
                contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i - 1).getLayoutY() + 21 * 2);
            } else {
                contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i - 1).getLayoutY() + 21);
            }
        }
    }

    //La methode de suppression
    private void supprimer(int index) {
        contPrinc.getChildren().remove(index);
        int j = contPrinc.getChildren().size();
        for (int i = index; i < j; i++) {
            contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i).getLayoutY() - 21);
        }
    }

    //La methode d'ajout d'un element
    protected void ajouterMod(String str, int index) {
        Information info = new Information();//renvoie le contenu de panelAnchor
        pile.empiler(info.algoAsauvegarder());
        undo.setDisable(pile.estVide());

        if (contPrinc.getChildren().get(index - 1) instanceof ModuleEntete) {//supprimer l'entête de Modules
            supprimer(index - 1);
            index--;
        }
        switch (str) {
            case "modO"://Module interne : Fonction
                ajouterEL(new ModuleFonctionIntEntete(), index);
                ajouterEL(new ConstanteEntete(), index + 1);
                ajouterEL(new TypeEntete(), index + 2);
                ajouterEL(new VariableEnteteModule(), index + 3);
                ajouterEL(new ModuleEntete(), index + 4);
                ajouterEL(new DebutModule(), index + 5);
                ajouterEL(new ModuleFonctionIntRetour(), index + 6);
                ajouterEL(new FinModule(), index + 7);
                break;
            case "modP"://Module interne : Procedure
                ajouterEL(new ModuleProcedureIntEntete(), index);
                ajouterEL(new ConstanteEntete(), index + 1);
                ajouterEL(new TypeEntete(), index + 2);
                ajouterEL(new VariableEnteteModule(), index + 3);
                ajouterEL(new ModuleEntete(), index + 4);
                ajouterEL(new DebutModule(), index + 5);
                ajouterEL(new FinModule(), index + 6);
                break;
            case "modX"://Module externe : Fonction
                ajouterEL(new ModuleExterneFon(), index);
                break;
            case "modY"://Module externe : Procedure
                ajouterEL(new ModuleExternePro(), index);
                break;
            default:
                throw new AssertionError();
        }
    }

}
