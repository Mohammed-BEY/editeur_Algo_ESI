/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import impl.org.controlsfx.i18n.Localization;
import java.util.Locale;
import javafx.scene.control.ChoiceDialog;
import javafx.stage.StageStyle;

/**
 *
 * @author lilia
 */
//La classe Boite de dialogue de la confirmation de la suppression d'un bloc d'instructions et les modules internes
public class BoiteDeDialogueBloc {

    private final ChoiceDialog<String> response;
    static final String choice1 = "supprimer et garder les instructions",
            choice2 = "supprimer tout le bloc";

    public ChoiceDialog<String> getResponse() {
        return response;
    }

    public BoiteDeDialogueBloc() {
        /**
         * ***************************************************************************
         */
        Locale lang = new Locale("fr", "FR");
        Localization.setLocale(lang);

        response = new ChoiceDialog<>(choice1, choice1, choice2);
        response.setContentText("Veuillez choisir une opération.");
        response.setTitle("Suppression d'un bloc");
        response.getDialogPane().getStylesheets().add(EditeurAlgoESI.class.getResource("AlertStyleModified.css").toExternalForm());
        response.getDialogPane().getStyleClass().add("AlertStyleModified");
        response.initStyle(StageStyle.UTILITY);
        response.showAndWait();
    }
}
