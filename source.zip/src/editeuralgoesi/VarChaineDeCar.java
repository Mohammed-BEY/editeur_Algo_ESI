/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

/**
 *
 * @author mohammed_bey
 */
public class VarChaineDeCar extends Variable {

    public VarChaineDeCar(char c) {
        super();
        tField1.setPromptText("phrase");
        tField2.setPromptText("taille_ch");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        tField2.setPrefWidth(longChar(tField2.getPromptText()));
        label1.setText(" : chaîne[");
        label2.setText("]");
        switch (c) {
            case 'v'://la rubrique des variables
                icMajEnv.menuAjouter.setText("ajouter une variable");
                break;
            case 'e'://dans l'enregistrement
                icMajEnv.menuAjouter.setText("ajouter un champ");
                icMajEnv.menuAjouter.getItems().add(icMajEnv.menuITypeEnreg);
                icMajEnv.menuSimple.setText("variable simple");
                icMajEnv.menuChaine.setText("variable chaine");
                icMajEnv.menuTableau.setText("variable tableau");
                break;
            default:
                throw new AssertionError();
        }
        label1.setStyle("-fx-text-fill:rgb(30,21,134);");
        label2.setStyle("-fx-text-fill:rgb(30,21,134);");
        getChildren().addAll(tField1, label1, tField2, label2, icMajEnv);
    }

    @Override
    public String toString() {
        String resultat = "";
        resultat += tField1.getText() + " : chaine [ " + tField2.getText() + " ]";
        return resultat;
    }

    @Override
    public void setContenu(String str) {
        String[] tab = str.split("#");
        int i = 1;
        if (i < tab.length) {
            tField1.setText(tab[i]);
            i++;
        }
        if (i < tab.length) {
            tField2.setText(tab[i]);
        }
    }

    @Override
    protected String coColler() {
        return "<varC>" + "#" + tField1.getText() + "#" + tField2.getText();
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return tField1.getText() + " : String[" + tField2.getText() + "]" + ";";
    }
}
