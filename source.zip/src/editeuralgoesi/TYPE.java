/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.contPrinc;
import javafx.event.ActionEvent;

/**
 *
 * @author mohammed_bey
 */
//Cette classe permet de manipuler les types
public abstract class TYPE extends Environnement {

    public TYPE() {
        super();
        icMajEnv.menuAjouter.setText("ajouter un type");
        icMajEnv.menuAjouter.getItems().removeAll(icMajEnv.menuConst, icMajEnv.menuFonction, icMajEnv.menuProcedure, icMajEnv.menuPtr);
        //**** *************************Gestion des evenements**************************/
        //*** ***************Ajout du type : ENUMERE***************************
        icMajEnv.menuITypeEnumere.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            ajouterEl(new TypeEnumere(), indice);
        });
        //****** ***************Ajout du type : INTERVALLE******************************/
        icMajEnv.menuITypeIntervalle.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            ajouterEl(new TypeIntervalle(), indice);
        });
        //****** ****Ajout du type : Chaine de caracteres******************************/
        icMajEnv.menuITypeChaineDeCar.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            ajouterEl(new TypeChaineDeCar(), indice);
        });
        //******* *******Ajout du type : Tableau 1Dim***********************************/
        icMajEnv.menuITypeTableau.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            ajouterEl(new TypeTableau(), indice);
        });
        //***************** *********Ajout du type : Tableau 2Dim***********************/
        icMajEnv.menuITypeTableau2.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            ajouterEl(new TypeTableauDeuxDim(), indice);
        });
        //******* **** *******Ajout du type* :Enregistrement******************************************/
        icMajEnv.menuITypeEnreg.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            ajouterEl(new TypeEnregistrementEntete(), indice);
            if (contPrinc.getChildren().get(indice - 1).getLayoutX() > 70) {//on est à l'interieur de l'enregistrement
                ajouterEl(new TypeEnregistrementFin('i'), indice + 1);
            } else {
                ajouterEl(new TypeEnregistrementFin('e'), indice + 1);
            }

        });
        //***** ***************Ajout du type : Ensemble*****************************/
        icMajEnv.menuITypeEnsemble.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            ajouterEl(new TypeEnsemble(), indice);
        });
        //*************** *****Ajout d'un commentaire*******************************/
        icMajEnv.menuComent.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            if (contPrinc.getChildren().get(indice - 1).getLayoutX() > 70) {//on est à l'interieur de l'enregistrement
                ajouterEl(new CommentaireEnvType('i'), indice);
            } else {
                ajouterEl(new CommentaireEnvType('e'), indice);
            }
        });
        //***************Pour l'Enregistrement
        //*** ***************Ajout D'UNE VARIABLE * SIMPLE***************************/
        icMajEnv.menuSimple.setOnAction((ActionEvent event) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            if (rubriqueVar(indice)) {
                ajouterEl(new VariableSimple('v'), indice);
            } else {
                ajouterEl(new VariableSimple('e'), indice);
            }
        });
        //**** ***************AJOUT D'UNE VARIABLE TABLEAU********************************/
        icMajEnv.menuTableau.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            if (rubriqueVar(indice)) {
                ajouterEl(new VarStructureTab('v'), indice);
            } else {
                ajouterEl(new VarStructureTab('e'), indice);
            }
        });
        //*** ***************AJOUT D'UNE VARIABLE CHAINE DE* CARACTERES*******************/
        icMajEnv.menuChaine.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            if (rubriqueVar(indice)) {
                ajouterEl(new VarChaineDeCar('v'), indice);
            } else {
                ajouterEl(new VarChaineDeCar('e'), indice);
            }
        });
        //****** **************************Supprimer ce type************************/
        icMajEnv.menuSupprimer.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent());
            supprimerEl(indice);
        });
    }

    //Ajouter ce type à la liste des types
    @Override
    protected void declarer() {
        if (!"".equals(tField1.getText()) && !(typesElementsList.contains(tField1.getText()))) {
            typesIndicesList.add(tField1.getText());
            typesElementsList.add(tField1.getText());
        }
    }
}
