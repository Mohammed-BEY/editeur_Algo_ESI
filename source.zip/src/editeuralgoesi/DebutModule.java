/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

/**
 *
 * @author mohammed_bey
 */
//Le début d'un module
public class DebutModule extends LesDebuts {

    public DebutModule() {
        super();
        label1.setText("DEBUT");
        label1.getStyleClass().remove("labDebFinBoucle");
        label1.getStyleClass().add("labDebutModule");
        this.getChildren().addAll(label1, icMajCorps);
    }

    @Override
    public String toString() {
        return "DEBUT";
    }

    @Override
    protected String coColler() {
        return "<modD>";
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return "Begin";
    }
}
