/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.contPrinc;
import javafx.event.ActionEvent;

/**
 *
 * @author mohammed_bey
 */
public class ModuleExterne extends Modules {

    public ModuleExterne() {
        super();
        icMajEnv.menuAjouter.setText("ajouter un module");
        icMajEnv.menuAjouter.getItems().removeAll(icMajEnv.menuPtr, icMajEnv.menuConst, icMajEnv.menuITypeChaineDeCar,
                icMajEnv.menuITypeEnreg, icMajEnv.menuITypeEnsemble, icMajEnv.menuITypeEnumere,
                icMajEnv.menuITypeIntervalle, icMajEnv.menuTab, icMajEnv.menuSimple, icMajEnv.menuTableau, icMajEnv.menuChaine);
        icMajEnv.menuMAJ.getItems().remove(icMajEnv.menuComent);

        //****** **************Supprimer une Fonction Externe***********************/
        icMajEnv.menuSupprimer.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent());
            supprimerEl(indice);
        });
    }

    //La methode de suppression
    @Override
    protected void supprimerEl(int index) {
        contPrinc.getChildren().remove(index);
        if ((contPrinc.getChildren().get(index - 1) instanceof VariableEntete || contPrinc.getChildren().get(index - 1) instanceof VariableSimple || contPrinc.getChildren().get(index - 1) instanceof VarChaineDeCar || contPrinc.getChildren().get(index - 1) instanceof VarStructureTab) && (contPrinc.getChildren().get(index) instanceof DEBUT)) {
            ajouterEL(new ModuleEntete(), index);
        } else {
            int j = contPrinc.getChildren().size();
            for (int i = index; i < j; i++) {
                contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i).getLayoutY() - 21);
            }
        }
    }
}
