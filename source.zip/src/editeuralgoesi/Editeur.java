/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.contPrinc;
import java.util.ArrayList;
import javafx.scene.layout.HBox;

/**
 *
 * @author mohammed_bey
 */
public class Editeur {

    private boolean rubV = false;//cette variable sert à indiquer si on est arrvé à la partie Variable
    private int cptTypeEnreg = 0;//cette variable sert à indiquer le nombre d'enregistrement qu'on a inséré
    private boolean boolCoEx = false;//indique s'il y a des constantes declarées dans le fichier restauré   
    private boolean boolTyEx = false;//indique s'il y a des types declarés dans le fichier restauré   

    public Editeur() {
        contPrinc.getChildren().add(new EnteteAlgo());
        contPrinc.getChildren().add(new ConstanteEntete());
        contPrinc.getChildren().add(new TypeEntete());
        contPrinc.getChildren().add(new VariableEntete());
        contPrinc.getChildren().add(new ModuleEntete());
        contPrinc.getChildren().add(new DEBUT());
        contPrinc.getChildren().add(new FinAlgo());
//        ajuster les positions x et y
        contPrinc.getChildren().get(1).setLayoutY(21 * 1);
        contPrinc.getChildren().get(2).setLayoutY(21 * 2);
        contPrinc.getChildren().get(3).setLayoutY(21 * 3);
        contPrinc.getChildren().get(4).setLayoutY(21 * 4);
        contPrinc.getChildren().get(5).setLayoutY(21 * 5 + 21);
        contPrinc.getChildren().get(6).setLayoutY(21 * 6 + 21 * 2);
    }

    public String algoEdite() {
        String result = "",
                tabulation = "", tmp = "";
        int j = contPrinc.getChildren().size();
        double posX = 0;
        for (int i = 0; i < j; i++) {
            posX = contPrinc.getChildren().get(i).getLayoutX();
            tabulation = "";
            if (posX == 70) {
                tabulation = "      ";
            } else if (posX > 70) {
                for (int k = 0; k < posX / 70; k++) {//ajuster les tabulations
                    tabulation += "   ";
                }
            } else {
                for (int k = 0; k < posX / 21; k++) {//ajuster les tabulations
                    tabulation += "   ";
                }
            }
            tmp = tabulation + ((Algorithme) contPrinc.getChildren().get(i)).toString();
            if (!tmp.equals("")) {
                result += tmp + "\n";
            }
        }
        return result;
    }

    //La methode qui permet de traduire l'algorithme édité
    public String algoPascal() {
        String result = "",
                tabulation = "", tmp = "";
        int j = contPrinc.getChildren().size();
        double posX = 0;
        for (int i = 0; i < j; i++) {
            posX = contPrinc.getChildren().get(i).getLayoutX();
            tabulation = "";
            if (posX == 70) {
                tabulation = "      ";
            } else if (posX > 70) {
                for (int k = 0; k < posX / 70; k++) {//ajuster les tabulations
                    tabulation += "   ";
                }
            } else {
                for (int k = 0; k < posX / 21; k++) {//ajuster les tabulations
                    tabulation += "   ";
                }
            }
            tmp = tabulation + ((Algorithme) contPrinc.getChildren().get(i)).tradPascal();
            if (!tmp.equals("")) {
                result += tmp + "\n";
            }
        }
        return result;
    }

    //La methode qui permet de créer un objet à partir de la balise en paramètre
    private Algorithme creerObjet(String str) {
        String[] tab = str.split("#");
        String balise = tab[0];//extraire la balise
        Object o = null;//l'objet à retourner
        switch (balise) {
            case "<comV>":
                o = new CommentaireEnvVar();
                break;
            case "<comO>":
                o = new CommentaireEnvConst();
                break;
            case "<comT>":
                if (cptTypeEnreg == 0) {//à l'interieur de l'enregistrement
                    o = new CommentaireEnvType('e');
                } else {
                    o = new CommentaireEnvType('i');
                }
                break;
            case "<comC>":
                o = new CommentaireCorps();
                break;
            case "<algE>":
                o = new EnteteAlgo();
                break;
            case "<cteE>":
                o = new ConstanteEntete();
                if (boolCoEx) {
                    ((ConstanteEntete) o).label1.setStyle("-fx-text-fill:rgb(91,40,83);");
                }
                break;
            case "<cteD>":
                o = new ConstanteDeclar();
                break;
            case "<typE>":
                rubV = false;
                o = new TypeEntete();
                if (boolTyEx) {
                    ((TypeEntete) o).label1.setStyle("-fx-text-fill:rgb(91,40,83);");
                }
                break;
            case "<typN>":
                o = new TypeEnumere();
                break;
            case "<typI>":
                o = new TypeIntervalle();
                break;
            case "<typC>":
                o = new TypeChaineDeCar();
                break;
            case "<typD>":
                o = new TypeTableau();
                break;
            case "<typQ>":
                o = new TypeTableauDeuxDim();
                break;
            case "<typR>":
                o = new TypeEnregistrementEntete();
                cptTypeEnreg += 1;//incrémenter le nombre d'enregistrement inséré
                break;
            case "<typF>"://à revoir (selon la position X)                
                if (cptTypeEnreg == 1) {//c'est la fin du premier enregistrement inséré
                    o = new TypeEnregistrementFin('e');
                } else {//on est encore à l'inteieur de l'enregistrement
                    o = new TypeEnregistrementFin('i');
                }
                cptTypeEnreg -= 1;
                break;
            case "<typS>":
                o = new TypeEnsemble();
                break;
            case "<varE>":
                rubV = true;
                o = new VariableEntete();
                break;
            case "<varS>"://(selon si on a passé la variableEntête)
                if (rubV) {
                    o = new VariableSimple('v');
                } else {
                    o = new VariableSimple('e');
                }
                break;
            case "<varC>":
                if (rubV) {
                    o = new VarChaineDeCar('v');
                } else {
                    o = new VarChaineDeCar('e');
                }
                break;
            case "<varT>":
                if (rubV) {
                    o = new VarStructureTab('v');
                } else {
                    o = new VarStructureTab('e');
                }
                break;
            case "<modE>":
                o = new ModuleEntete();
                break;
            case "<modO>":
                o = new ModuleFonctionIntEntete();
                break;
            case "<modR>":
                o = new ModuleFonctionIntRetour();
                break;
            case "<modP>":
                o = new ModuleProcedureIntEntete();
                break;
            case "<modX>":
                o = new ModuleExterneFon();
                break;
            case "<modY>":
                o = new ModuleExternePro();
                break;
            case "<modD>":
                o = new DebutModule();
                break;
            case "<modV>":
                o = new VariableEnteteModule();
                break;
            case "<modF>":
                o = new FinModule();
                break;
            case "<algD>":
                o = new DEBUT();
                break;
            case "<affA>":
                o = new Affectation();
                break;
            case "<ecrA>":
                o = new Ecriture();
                break;
            case "<lecA>":
                o = new Lecture();
                break;
            case "<conE>":
                o = new CondAltEntete();
                break;
            case "<conD>":
                o = new CondAltDebut();
                break;
            case "<conF>":
                o = new ConditionnelleFin();
                break;
            case "<altC>":
                o = new AlternativeFSI();
                break;
            case "<altS>":
                o = new AlternativeSINON();
                break;
            case "<altN>":
                o = new AlternativeDSIN();
                break;
            case "<altF>":
                o = new AlternativeFSIN();
                break;
            case "<bcpE>":
                o = new BouclePourEntete();
                break;
            case "<bcpD>":
                o = new BouclePourDebut();
                break;
            case "<bcpF>":
                o = new BouclePourFin();
                break;
            case "<bctE>":
                o = new BoucleTantQueEntete();
                break;
            case "<bctD>":
                o = new BoucleTantQueDebut();
                break;
            case "<bctF>":
                o = new BoucleTantQueFin();
                break;
            case "<bcrE>":
                o = new BoucleRepeterEntete();
                break;
            case "<bcrJ>":
                o = new BoucleRepeterJusqua();
                break;
            case "<aplP>":
                o = new AppelProc();
                break;
            case "<algF>":
                o = new FinAlgo();
                break;
            default:
                throw new AssertionError();
        }
        ((Algorithme) o).setContenu(str);
        return (Algorithme) o;
    }

    //La methode d'ajout d'un element
    private void ajouterEl(HBox el, int index) {
        contPrinc.getChildren().add(index, el);
        double posX;
        if (index > 0) {
            posX = contPrinc.getChildren().get(index - 1).getLayoutX();
            //La partie Corps
            if (contPrinc.getChildren().get(index - 1) instanceof CondAltEntete || contPrinc.getChildren().get(index - 1) instanceof AlternativeSINON || contPrinc.getChildren().get(index - 1) instanceof BouclePourEntete || contPrinc.getChildren().get(index - 1) instanceof BoucleTantQueEntete) {
                posX += 21;
            }
            //La partie Environnement
            if (el instanceof ConstanteEntete || el instanceof TypeEntete || el instanceof VariableEntete || el instanceof ModuleEntete || el instanceof ModuleExterneFon
                    || el instanceof ModuleExternePro || el instanceof ModuleFonctionIntEntete || el instanceof ModuleProcedureIntEntete || el instanceof DEBUT || el instanceof DebutModule
                    || el instanceof ModuleFonctionIntRetour || el instanceof FinAlgo || el instanceof VariableEnteteModule) {
                el.setLayoutX(0);
            } else if (contPrinc.getChildren().get(index - 1) instanceof TypeEnregistrementEntete && !(el instanceof TypeEnregistrementFin)) {//on est dans l'entete de l'enregistrement
                el.setLayoutX(posX + 120);
            } else if (!(contPrinc.getChildren().get(index - 1) instanceof TypeEnregistrementEntete) && (el instanceof TypeEnregistrementFin)) {
                el.setLayoutX(posX - 120);
            } else if (contPrinc.getChildren().get(index - 1) instanceof TypeEntete
                    || contPrinc.getChildren().get(index - 1) instanceof VariableEntete
                    || contPrinc.getChildren().get(index - 1) instanceof VariableEnteteModule
                    || contPrinc.getChildren().get(index - 1) instanceof ConstanteEntete) {//on est dans l'entête
                el.setLayoutX(70);
            } else if (contPrinc.getChildren().get(index - 1) instanceof ConditionnelleFin || contPrinc.getChildren().get(index - 1) instanceof AlternativeFSI || contPrinc.getChildren().get(index - 1) instanceof AlternativeFSIN || contPrinc.getChildren().get(index - 1) instanceof BouclePourFin || contPrinc.getChildren().get(index - 1) instanceof BoucleTantQueFin) {
                el.setLayoutX(posX - 21);
            } else {
                el.setLayoutX(posX);
            }
            //Decalage
            int j = contPrinc.getChildren().size();
            for (int i = index; i < j; i++) {
                if (contPrinc.getChildren().get(i) instanceof DEBUT || contPrinc.getChildren().get(i) instanceof DebutModule || contPrinc.getChildren().get(i) instanceof FinAlgo) {
                    contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i - 1).getLayoutY() + 21 * 2);
                } else {
                    contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i - 1).getLayoutY() + 21);
                }
            }
        }
    }

    //recréer l'algorithme aprés avoir sauvegardé
    public void recreation(ArrayList<String> listinfo) {
        if (listinfo.get(0).contains("coEx")) {
            boolCoEx = true;
            String replaceFirst = listinfo.get(0).replaceFirst("coEx", "");
            listinfo.add(0, replaceFirst);
            listinfo.remove(1);
        }
        if (listinfo.get(0).contains("tyEx")) {
            boolTyEx = true;
            String replaceFirst = listinfo.get(0).replaceFirst("tyEx", "");
            listinfo.add(0, replaceFirst);
            listinfo.remove(1);
        }
        contPrinc.getChildren().clear();
        int index = 0;
        for (String string : listinfo) {
            if (string.contains("<algD>") || string.contains("<modD>")) {//on est arrivé au début du programme
                if (contPrinc.getChildren().get(index - 1) instanceof VariableEntete || contPrinc.getChildren().get(index - 1) instanceof VariableSimple
                        || contPrinc.getChildren().get(index - 1) instanceof VarStructureTab || contPrinc.getChildren().get(index - 1) instanceof VarChaineDeCar) {
                    //ajouter le module entete pourqu'on puisse rajouter de nouveaux modules
                    ajouterEl((Algorithme) creerObjet("<modE>"), index);
                    index++;
                }
            }
            ajouterEl((Algorithme) creerObjet(string), index);
            index++;
        }

        //Compléter l'algorithme avec les entêtes de l'environnement
        if (!(contPrinc.getChildren().get(1) instanceof ConstanteEntete)) {
            ajouterEl((Algorithme) creerObjet("<cteE>"), 1);
        }

        boolean typEntEx = false, varEntEx = false, fin = false;
        index = 2;
        while (!fin) {
            if ((contPrinc.getChildren().get(index) instanceof ModuleEntete)
                    || (contPrinc.getChildren().get(index) instanceof ModuleProcedureIntEntete)
                    || (contPrinc.getChildren().get(index) instanceof ModuleFonctionIntEntete
                    || (contPrinc.getChildren().get(index) instanceof ModuleExterneFon
                    || (contPrinc.getChildren().get(index) instanceof ModuleExternePro)))) {
                fin = true;
            }
            if ((contPrinc.getChildren().get(index) instanceof TypeEntete)) {
                typEntEx = true;
            }
            if ((contPrinc.getChildren().get(index) instanceof VariableEntete)) {
                varEntEx = true;
                fin = true;
            }
            index++;
        }
        if (!varEntEx || !typEntEx) {
            index = 2;
            while ((contPrinc.getChildren().get(index) instanceof ConstanteDeclar)) {
                index++;
            }
            if (!typEntEx) {
                ajouterEl((Algorithme) creerObjet("<typE>"), index);
            }
            while ((contPrinc.getChildren().get(index) instanceof TYPE)) {
                index++;
            }
            if (!varEntEx) {
                ajouterEl((Algorithme) creerObjet("<varE>"), index);
            }
        }
    }

    //faire les contrôles syntaxiques
    public String controlesSyn() {
        String result = "";
        ControlesSyntaxiques ctrl = new ControlesSyntaxiques();
        ArrayList<String> varDup = new ArrayList<>();
        int cpt = 0;
        int indiceModuleEntete = 0;//l'indice du module où se trouve l'objet actuel
        int j = contPrinc.getChildren().size();
        for (int i = 0; i < j; i++) {
            if ((contPrinc.getChildren().get(i) instanceof ModuleFonctionIntEntete)
                    || (contPrinc.getChildren().get(i) instanceof ModuleProcedureIntEntete)) {//pour modifier la liste des variables (dans le module)
                indiceModuleEntete = i;//indice du module où se trouve l'objet actuel
                cpt++;
            } else if (contPrinc.getChildren().get(i) instanceof FinModule) {
                cpt--;
            }
            //restreindre le traitement aux éléments qui utilisent les variables
            if (contPrinc.getChildren().get(i) instanceof EnteteAlgo
                    || contPrinc.getChildren().get(i) instanceof Ecriture || contPrinc.getChildren().get(i) instanceof Lecture || contPrinc.getChildren().get(i) instanceof Affectation
                    || contPrinc.getChildren().get(i) instanceof CondAltEntete || contPrinc.getChildren().get(i) instanceof BouclePourEntete
                    || contPrinc.getChildren().get(i) instanceof BoucleRepeterJusqua || contPrinc.getChildren().get(i) instanceof BoucleTantQueEntete
                    || contPrinc.getChildren().get(i) instanceof AppelProc
                    || contPrinc.getChildren().get(i) instanceof ModuleFonctionIntRetour) {
                if (!(contPrinc.getChildren().get(i) instanceof EnteteAlgo)) {
                    ctrl.remplirListeTypesEnreg(position(i));
                    ctrl.remplirListVar(position(i));
                    ctrl.remplirConst(position(i));
                    ctrl.remplirModules(i);
                    if (contPrinc.getChildren().get(i) instanceof Affectation || contPrinc.getChildren().get(i) instanceof ModuleFonctionIntRetour) {
                        ctrl.remplirMapVarTypes(position(i));
                        ctrl.remplirTypesModules(i);
                    }
                }
                if (cpt != 0) {//on est dans un module
                    //ajouter les variables locales dans l'entête du module
                    String vars = ((ModuleInterne) contPrinc.getChildren().get(indiceModuleEntete)).tField2.getText();
                    ctrl.remplirVarLocales(vars);//ajouter les variables locales
                    ctrl.remplirTypesVarLocales(vars);//ajouter les variables locales avec leurs types
                    if (!ctrl.getVariablesListe().isEmpty()) {
                        if (!varDup.contains((String) ctrl.getVariablesListe().get(ctrl.getVariablesListe().size() - 1))) {
                            varDup.add((String) ctrl.getVariablesListe().get(ctrl.getVariablesListe().size() - 1));//indique s'il y a une variable dupliquée
                        }
                    }
                }
                //créer un tableau des listes des déclarations
                Object[] listListesDecl = new Object[6];
                listListesDecl[0] = ctrl.getVariablesListe();
                listListesDecl[1] = ctrl.getConstantesListe();
                listListesDecl[2] = ctrl.getModulesListe();
                listListesDecl[3] = ctrl.getListeTypesEnreg();
                listListesDecl[4] = ctrl.getVariablesTypesListe();
                listListesDecl[5] = ctrl.getModulesTypesListe();

                String tmp = ((Algorithme) contPrinc.getChildren().get(i)).traiter(listListesDecl);
                if (!tmp.equals("")) {
                    result += tmp + "\n";
                    ((Algorithme) contPrinc.getChildren().get(i)).colorerChampSaisie();
                }else{
                    ((Algorithme) contPrinc.getChildren().get(i)).enleverCouleurChampSaisie();
                }
            }
        }
        if (!ctrl.getVariablesListe().isEmpty()) {
            result += ctrl.getVariablesListe().get(ctrl.getVariablesListe().size() - 1);//indique s'il y a une variable dupliquée
        }
        for (String string : varDup) {
            result += string;
        }
        if (result.equals("")) {
            result += "il n'y a aucune erreur détectée." + "\n";
        }
        return result + "\nLe traitement est terminé.";
    }

    //retourner l'indice de la liste des variables qu'il faut r.cupérer ses elements
    private int position(int i) {
        boolean bool = false;
        while (!bool) {
            if (contPrinc.getChildren().get(i) instanceof DEBUT) {//on est dans le corps de l'Algorithme
                //chercher l'entête des variables globales
                i = 0;
                while (!(contPrinc.getChildren().get(i) instanceof VariableEntete)) {
                    i++;
                }
                i++;
                bool = true;
            } else if ((contPrinc.getChildren().get(i) instanceof DebutModule)) {//on est dans un module
                int cpt = 0;
                while ((cpt != 0) || ((!(contPrinc.getChildren().get(i) instanceof VariableEntete) && (!(contPrinc.getChildren().get(i) instanceof VariableEnteteModule))))) {
                    if ((contPrinc.getChildren().get(i) instanceof FinModule)) {
                        cpt++;
                    } else if ((contPrinc.getChildren().get(i) instanceof ModuleFonctionIntEntete)
                            || (contPrinc.getChildren().get(i) instanceof ModuleProcedureIntEntete)) {
                        cpt--;
                    }
                    i--;
                }
                i++;
                bool = true;
            }
            i--;
        }
        return i;
    }
}
