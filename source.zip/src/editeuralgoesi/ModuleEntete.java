/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import javafx.event.Event;
import javafx.scene.input.MouseEvent;

/**
 *
 * @author mohammed_bey
 */
public class ModuleEntete extends Modules {

    public ModuleEntete() {
        super();
        label1.setText("Modules");
        label1.getStyleClass().add("labelCle");
        getChildren().addAll(label1, icMajEnv);
        icMajEnv.menuAjouter.getItems().removeAll(icMajEnv.menuConst, icMajEnv.menuSimple, icMajEnv.menuTableau, icMajEnv.menuChaine,
                icMajEnv.menuITypeChaineDeCar, icMajEnv.menuITypeEnreg, icMajEnv.menuITypeEnsemble,
                icMajEnv.menuITypeEnumere, icMajEnv.menuITypeIntervalle, icMajEnv.menuTab, icMajEnv.menuPtr);
        icMajEnv.menuMAJ.getItems().removeAll(icMajEnv.menuSupprimer, icMajEnv.menuComent);
        icMajEnv.setVisible(false);
        //****************Gérer les evenements**********************************************/        
        setOnMouseEntered((Event t) -> {
        });
        setOnMouseClicked((Event t) -> {
            if (((MouseEvent) t).getButton().equals(((MouseEvent) t).getButton().PRIMARY)) {
                if (((MouseEvent) t).getClickCount() == 1) {
                    unClic();
                }
                if (((MouseEvent) t).getClickCount() == 2) {
                    doubleClic();
                }
            }
        });
    }

    //modifier la couleur de label1 et faire apparaitre le menu de mise à jour
    private void unClic() {
        label1.setStyle("-fx-text-fill:rgb(91,40,83);");
        icMajEnv.setVisible(true);
        setOnMouseEntered((Event t1) -> {
            icMajEnv.setVisible(true);
        });
        //le menu de MiseAjour disparait quand la souris sort de la zone de HBox
        setOnMouseExited((Event t1) -> {
            icMajEnv.setVisible(false);
        });
    }

    //modifier la couleur de label1 et rendre le menu de mise à jour invisible
    private void doubleClic() {
        label1.setStyle("-fx-text-fill:rgb(188,188,188);");
        icMajEnv.setVisible(false);
        setOnMouseEntered((Event t1) -> {
        });
    }

    @Override
    public String toString() {
        return "";
    }

    @Override
    protected String coColler() {
        return "<modE>";
    }

    //redefinir la methode de telle sorte qu'elle ne fait rien
    @Override
    protected void supprimerEl(int index) {
    }
}
