/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.undo;
import java.util.Map;
import javafx.collections.ObservableList;
import javafx.scene.control.TextField;

/**
 *
 * @author mohammed_bey
 */
public class Affectation extends Corps {

    public Affectation() {
        super();
        tField1.setPromptText("variable");
        tField2.setPromptText("expression");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        tField2.setPrefWidth(longChar(tField2.getPromptText()));
        label1.setText(" <- ");
        getChildren().addAll(tField1, label1, tField2, icMajCorps);
    }

    //La methode de suppression
    @Override
    protected void supprimerEl(int index) {
        Information info = new Information();//renvoie le contenu de panelAnchor
        pile.empiler(info.algoAsauvegarder());
        undo.setDisable(pile.estVide());
        super.supprimerEl(index);
    }

    @Override
    public String toString() {
        return tField1.getText() + " <- " + tField2.getText();
    }

    @Override
    protected String coColler() {
        return "<affA>" + "#" + tField1.getText() + "#" + tField2.getText();
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        String replaceAll = tField2.getText().replaceAll("vrai", "true");
        String replaceAll1 = replaceAll.replaceAll("faux", "false");
        return tField1.getText() + " := " + replaceAll1 + ";";
    }

    @Override
    protected void setContenu(String str) {
        String[] tab = str.split("#");
        int i = 1;
        if (i < tab.length) {
            tField1.setText(tab[i]);
            i++;
        }
        if (i < tab.length) {
            tField2.setText(tab[i]);
        }
    }

    @Override
    protected String traiter(Object[] listListesDecl) {
        String result = "", tmp = "";

        //Traitement du premier champ
        String preChamp = tField1.getText();
        preChamp = preChamp.replaceAll(" ", "");
        preChamp = preChamp.replaceAll("\t", "");
        tmp = traiterPremierChamp(preChamp, listListesDecl);
        if (tmp.equals("")) {
            enleverCouleurChampSaisie(tField1);
        } else {
            colorerChampSaisie(tField1);
        }
        result += tmp;
        //Traitement du deuxieme champ
        String deuxiemeChamp = tField2.getText();
        deuxiemeChamp = deuxiemeChamp.replaceAll(" ", "");
        deuxiemeChamp = deuxiemeChamp.replaceAll("\t", "");
        tmp = traiterDeuxiemeChamp(deuxiemeChamp, listListesDecl);
        if (tmp.equals("")) {
            enleverCouleurChampSaisie(tField2);
        } else {
            colorerChampSaisie(tField2);
        }
        result += tmp;
        //Concordance des types
        result += concordancetypes(preChamp, deuxiemeChamp, listListesDecl);
        indice = result.lastIndexOf("\n");
        try {
            result = result.substring(0, indice);
        } catch (StringIndexOutOfBoundsException ex) {
        }
        return result;
    }

    //méthode quiq permet de traiter le premier champ
    private String traiterPremierChamp(String str, Object[] listListesDecl) {
        String result = "";
        result += messVerification(str, listListesDecl);
        return result;
    }

    //méthode quiq permet de traiter le 2 champ
    private String traiterDeuxiemeChamp(String str, Object[] listListesDecl) {
        String result = "";
        String tabSpace[] = str.split(" ");
        for (String string2 : tabSpace) {
            if (!string2.equals("ET") && !string2.equals("eT") && !string2.equals("Et") && !string2.equals("et")
                    && !string2.equals("OU") && !string2.equals("oU") && !string2.equals("Ou") && !string2.equals("ou")
                    && !string2.equals("DIV") && !string2.equals("div")
                    && !string2.equals("MOD") && !string2.equals("mod")
                    && !string2.equals("\\+") && !string2.equals("-") && !string2.equals("\\*") && !string2.equals("/")
                    && !string2.equals("VRAI") && !string2.equals("vrai")
                    && !string2.equals("FAUX") && !string2.equals("faux")) {//c'est une variable
                String[] tokens = string2.split("['\\(' '\\)' '\\[' '\\]' ',' '+' '\\-' '/' '*']");
                for (String string3 : tokens) {
                    if (!string3.equals("")) {
                        result += messVerification(string3, listListesDecl);
                    }
                }
            }
        }
        return result;
    }

    private String concordancetypes(String preChamp, String deuxiemeChamp, Object[] listListesDecl) {
        String result = "", tmpVT1 = null, tmpVT2 = null;
        //Le premier champ
        String[] tokens1 = preChamp.split("['\\('  '\\[']");
        String tmpPreChamp = tokens1[0].toLowerCase();
        tmpVT1 = ((Map<String, String>) listListesDecl[4]).get(tmpPreChamp);//retourner le type de la variable du premier champ
        //Le deuxième champ
        String tmpDeuxiemeChamp = deuxiemeChamp.toLowerCase();
        try {
            Double.parseDouble(tmpDeuxiemeChamp);
        } catch (NumberFormatException nfe) {
            String[] tokens2 = tmpDeuxiemeChamp.split("['\\('  '\\[']");
            if (!tokens2[0].equals("")) {
                if (tokens2[0].equals("vrai") || tokens2[0].equals("faux")) {
                    tmpVT2 = "booleen";
                } else if (((ObservableList) listListesDecl[0]).contains(tokens2[0])) {//variable
                    //retourner le type de la variable du deuxieme champ
                    tmpVT2 = ((Map<String, String>) listListesDecl[4]).get(tokens2[0]);
                } else if (((ObservableList) listListesDecl[2]).contains(tokens2[0])) {//module fonction
                    //retourner le type du module du deuxieme champ
                    tmpVT2 = ((Map<String, String>) listListesDecl[4]).get(tokens2[0]);
                }
                if ((tmpVT1 == null)) {
                    result += "Attention ! vous n'avez pas désigné un type pour  '" + preChamp + "' dans une action d'effectation.\n";
                }
                if (((((ObservableList) listListesDecl[0]).contains(tokens2[0])) || (((ObservableList) listListesDecl[2]).contains(tokens2[0]))) && (tmpVT2 == null)) {
                    result += "Attention ! vous n'avez pas désigné un type pour  '" + deuxiemeChamp + "' dans une action d'effectation.\n";
                }
                //Compraison
                if ((tmpVT1 != null) && (tmpVT2 != null)) {
                    if (!tmpVT1.equals(tmpVT2)) {
                        result += "Attention ! une variable de type '" + tmpVT1 + "' a été affectée à une variable de type '" + tmpVT2 + "'.\n";
                    }
                }
            }
        }
        return result;
    }

    @Override
    protected String designation() {
        return "une action de 'Affectation'";
    }

    //Mettre les chmps de saisie en couleur rouge quand il y a une erreur détectée
    protected void colorerChampSaisie(TextField tField) {
        tField.getStyleClass().add("error");
    }

    //Enlever la couleur rouge des champs de saisie
    protected void enleverCouleurChampSaisie(TextField tField) {
        tField.getStyleClass().remove("error");
    }
}
