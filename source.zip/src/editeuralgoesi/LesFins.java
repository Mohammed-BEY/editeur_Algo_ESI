/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

/**
 *
 * @author mohammed_bey
 */
//Cette classe désigne les fins des blocs d'instructions
public class LesFins extends Corps {

    public LesFins() {
        super();
        icMajCorps.menuAjouter.setText("ajouter une action");
        label1.getStyleClass().add("labDebFinBoucle");
        /**
         * *********************Gestion des evenements du menuIcone de
         * MiseAJour:*********************
         */
        icMajCorps.menuCopier.setDisable(true);
        icMajCorps.menuCouper.setDisable(true);
        icMajCorps.menuSupprimer.setDisable(true);
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return "End;";
    }

    //redefinir la methode copier de telle sorte qu'elle ne fait rien
    @Override
    protected void copier(int index) {
    }

    //redefinir la methode couper de telle sorte qu'elle ne fait rien
    @Override
    protected void couper(int index) {
    }

    //redefinir la methode de telle sorte qu'elle ne fait rien
    @Override
    protected void supprimerEl(int index) {
    }
}
