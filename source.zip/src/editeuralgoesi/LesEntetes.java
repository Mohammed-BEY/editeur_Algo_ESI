
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.contPrinc;
import static editeuralgoesi.FXMLDocumentController.undo;
import java.util.NoSuchElementException;
import javafx.event.ActionEvent;

/**
 *
 * @author mohammed_bey
 */
//Cette classe désigne les entêtes des blocs d'instructions
public abstract class LesEntetes extends Corps {

    private BoiteDeDialogueBloc root = null;

    public LesEntetes() {
        label1.setStyle("-fx-text-fill:rgb(30,21,134);");
        label2.setStyle("-fx-text-fill:rgb(30,21,134);");
        //***********************Gestion des evenements du menuIcone de MiseAJour********************/

        icMajCorps.menuColler.setDisable(true);
        icMajCorps.menuAjouter.setDisable(true);
        icMajCorps.menuMiseAjour.getItems().removeAll(icMajCorps.menuAjouter, icMajCorps.menuColler, icMajCorps.menuComent);
        //***************************La suppression d'un bloc d'instruction********************************/
        icMajCorps.menuSupprimer.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajCorps.getParent());
            supprimerEl(indice);
        });
        //*******************Copier l'element de la position courante*********************/
        icMajCorps.menuCopier.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajCorps.getParent());
            copier(indice);
        });
        //* ***************Couper le bloc de la position courante**********************/
        icMajCorps.menuCouper.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajCorps.getParent());
            couper(indice);
        });
    }

    //LA methode de copier
    @Override
    protected void copier(int index) {
        double posX = contPrinc.getChildren().get(index).getLayoutX();
        listeCoColler.clear();
        while (!((contPrinc.getChildren().get(index) instanceof ConditionnelleFin || contPrinc.getChildren().get(index) instanceof AlternativeFSIN || contPrinc.getChildren().get(index) instanceof BouclePourFin || contPrinc.getChildren().get(index) instanceof BoucleTantQueFin) && (contPrinc.getChildren().get(index).getLayoutX() == posX + 21))) {
            listeCoColler.add(((Corps) contPrinc.getChildren().get(index)).coColler());
            index++;
        }
        listeCoColler.add(((Corps) contPrinc.getChildren().get(index)).coColler());
    }

    //La methode de couper
    @Override
    protected void couper(int index) {
        Information info = new Information();//renvoie le contenu du conteneur principal
        pile.empiler(info.algoAsauvegarder());
        undo.setDisable(pile.estVide());

        double posX = contPrinc.getChildren().get(index).getLayoutX();
        listeCoColler.clear();
        while (!((contPrinc.getChildren().get(index) instanceof ConditionnelleFin || contPrinc.getChildren().get(index) instanceof AlternativeFSIN || contPrinc.getChildren().get(index) instanceof BouclePourFin || contPrinc.getChildren().get(index) instanceof BoucleTantQueFin) && (contPrinc.getChildren().get(index).getLayoutX() == posX + 21))) {
            listeCoColler.add(((Corps) contPrinc.getChildren().get(index)).coColler());
            super.supprimerEl(index);
        }
        listeCoColler.add(((Corps) contPrinc.getChildren().get(index)).coColler());
        super.supprimerEl(index);
    }

    //redefinir la methode coller de telle sorte qu'elle ne fait rien
    @Override
    protected void coller(int index) {
    }

    //supprimer et garder l'interieur du bloc
    private void suppIntBloc(int index, boolean supSINON, double posX) {
        Information info = new Information();//renvoie le contenu de panelAnchor
        pile.empiler(info.algoAsauvegarder());
        undo.setDisable(pile.estVide());
        super.supprimerEl(index);
        super.supprimerEl(index);
        while (!((contPrinc.getChildren().get(index) instanceof ConditionnelleFin || contPrinc.getChildren().get(index) instanceof AlternativeFSIN || contPrinc.getChildren().get(index) instanceof BouclePourFin || contPrinc.getChildren().get(index) instanceof BoucleTantQueFin) && (contPrinc.getChildren().get(index).getLayoutX() == posX + 21))) {
            if ((contPrinc.getChildren().get(index) instanceof AlternativeFSI) && (contPrinc.getChildren().get(index).getLayoutX() == posX + 21)) {
                super.supprimerEl(index);//supprimer AlterternativeFSI
                super.supprimerEl(index);//supprimer SinonEntete
                super.supprimerEl(index);//supprimer AlternativeDSIN
                index--;
            } else {
                contPrinc.getChildren().get(index).setLayoutX(contPrinc.getChildren().get(index).getLayoutX() - 21);
            }
            index++;
        }
        super.supprimerEl(index);
        if (supSINON) {//indique qu'on a supprimé le bloc SINON
            super.supprimerEl(index - 1);
            ajouterEl(new ConditionnelleFin(), index - 1);
        }
    }

    /**
     *
     * @param index
     */
    @Override
    protected void supprimerEl(int index) {
        root = new BoiteDeDialogueBloc();
        boolean supSINON = false;//indique si on veut supprimer la prtie Sinon pour transformer l'Alternative en Conditionnelle
        if (contPrinc.getChildren().get(index) instanceof AlternativeSINON) {
            supSINON = true;
        }
        double posX = contPrinc.getChildren().get(index).getLayoutX();
        try {
            switch (root.getResponse().getResult()) {
                case BoiteDeDialogueBloc.choice1:
                    //*******************Garder l'interieur du bloc**********************/
                    suppIntBloc(index, supSINON, posX);
                    break;
                case BoiteDeDialogueBloc.choice2:
                    Information info = new Information();//renvoie le contenu de panelAnchor
                    pile.empiler(info.algoAsauvegarder());
                    undo.setDisable(pile.estVide());
                    //* *************Suppression du bloc tout entier*****************/
                    while (!((contPrinc.getChildren().get(index) instanceof ConditionnelleFin || contPrinc.getChildren().get(index) instanceof AlternativeFSIN || contPrinc.getChildren().get(index) instanceof BouclePourFin || contPrinc.getChildren().get(index) instanceof BoucleTantQueFin) && (contPrinc.getChildren().get(index).getLayoutX() == posX + 21))) {
                        super.supprimerEl(index);
                    }
                    super.supprimerEl(index);//supprimer la fin du bloc
                    if (supSINON) {//indique qu'on a supprimé le bloc SINON
                        super.supprimerEl(index - 1);
                        ajouterEl(new ConditionnelleFin(), index - 1);
                    }
                    break;
                default:
                    throw new AssertionError();
            }
        } catch (NoSuchElementException nse) {
        }
    }

    @Override
    protected String traiter(Object[] listListesDecl) {
        return null;
    }
}
