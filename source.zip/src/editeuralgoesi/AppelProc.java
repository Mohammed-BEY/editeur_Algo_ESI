/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.undo;

/**
 *
 * @author mohammed_bey
 */
public class AppelProc extends Corps {

    public AppelProc() {
        super();
        tField1.setPromptText("appel_procédure");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        getChildren().addAll(tField1, icMajCorps);
    }

    //La methode de suppression
    @Override
    protected void supprimerEl(int index) {
        Information info = new Information();//renvoie le contenu de panelAnchor
        pile.empiler(info.algoAsauvegarder());
        undo.setDisable(pile.estVide());
        super.supprimerEl(index);
    }

    @Override
    public String toString() {
        return tField1.getText();
    }

    @Override
    protected String coColler() {
        return "<aplP>" + "#" + tField1.getText();
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return tField1.getText();
    }

    @Override
    protected void setContenu(String str) {
        String[] tab = str.split("#");
        int i = 1;
        if (i < tab.length) {
            tField1.setText(tab[i]);
            i++;
        }
    }

    @Override
    protected String traiter(Object[] listListesDecl) {
        String result = "";
        String tmp = tField1.getText();
        tmp = tmp.replaceAll(" ", "");
        if (!tmp.equals("")) {
            String[] tabMod = tmp.split("['\\(' '\\)']");
            result += messVerification(tabMod[0], listListesDecl);
            String[] tabSpace = tabMod[1].split(" ");
            for (String string2 : tabSpace) {
                if (!string2.equals("ET") && !string2.equals("eT") && !string2.equals("Et") && !string2.equals("et")
                        && !string2.equals("OU") && !string2.equals("oU") && !string2.equals("Ou") && !string2.equals("ou")
                        && !string2.equals("DIV") && !string2.equals("div")
                        && !string2.equals("MOD") && !string2.equals("mod")
                        && !string2.equals("\\+") && !string2.equals("-") && !string2.equals("\\*") && !string2.equals("/")
                        && !string2.equals("VRAI") && !string2.equals("vrai")
                        && !string2.equals("FAUX") && !string2.equals("faux")) {//c'est une variable
                    String[] tokens = string2.split("['\\(' '\\)' '\\[' '\\]' ',' '+' '\\-' '/' '*']");
                    for (String string3 : tokens) {
                        if (!string3.equals("")) {
                            result += messVerification(string3, listListesDecl);
                        }
                    }
                }
            }
        }
        return result;
    }

    @Override
    protected String designation() {
        return "une actione d'AppelProc";
    }

    //Mettre les chmps de saisie en couleur rouge quand il y a une erreur détectée
    @Override
    protected void colorerChampSaisie() {
        tField1.getStyleClass().add("error");
    }

    //Enlever la couleur rouge des champs de saisie
    @Override
    protected void enleverCouleurChampSaisie() {
        tField1.getStyleClass().remove("error");
    }
}
