/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.contPrinc;
import java.util.TreeMap;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author mohammed_bey
 */
public class ControlesSyntaxiques {

    //Liste des variables declarées
    private final ObservableList variablesListe = FXCollections.observableArrayList();
    //Liste des constantes déclarées
    private final ObservableList constantesListe = FXCollections.observableArrayList();
    //Liste des variables declarées avec leurs types
    private final TreeMap<String, String> variablesTypesListe = new TreeMap() {
    };//Keys : Variables   \*/   Values : Types
    //Liste des modules declarées avec leurs types
    private final TreeMap<String, String> modulesTypesListe = new TreeMap();//Keys : Variables   \*/   Values : Types
    //Liste des modules déclarés
    private final ObservableList modulesListe = FXCollections.observableArrayList();
    //liste des types des variables déclarées
    private final ObservableList listeTypesEnreg = FXCollections.observableArrayList();

    public ControlesSyntaxiques() {
    }

    //remplir la liste des variables
    public void remplirListVar(int i) {//i: indice du TYPEENTETE
        //vider la liste des variables
        variablesListe.clear();
        String messVarDupliquée = "", tmp = "";
        //ajouter les variables déclarées dans la rubrique des variables
        while (!(contPrinc.getChildren().get(i) instanceof ModuleEntete || contPrinc.getChildren().get(i) instanceof ModuleFonctionIntEntete || contPrinc.getChildren().get(i) instanceof ModuleProcedureIntEntete || contPrinc.getChildren().get(i) instanceof ModuleExterneFon || contPrinc.getChildren().get(i) instanceof ModuleExternePro
                || contPrinc.getChildren().get(i) instanceof ModuleFonctionIntEntete || contPrinc.getChildren().get(i) instanceof ModuleProcedureIntEntete)) {
            if (contPrinc.getChildren().get(i) instanceof VariableSimple || contPrinc.getChildren().get(i) instanceof VarStructureTab || contPrinc.getChildren().get(i) instanceof VarChaineDeCar) {
                tmp = ((Variable) contPrinc.getChildren().get(i)).tField1.getText().toLowerCase();
                if (!tmp.equals("")) {
                    tmp = tmp.replaceAll(" ", "");//enlever les blancs
                    String[] tabVar = tmp.split(",");//extraire toutes les variables declarées                    
                    for (String string : tabVar) {
                        if (!string.equals("")) {
                            String tmpType = ((Variable) contPrinc.getChildren().get(i)).typesElements.getEditor().getText().toLowerCase();
                            if (variablesListe.contains(string)) {
                                messVarDupliquée += "Attention ! La variable '" + string + "' a été dupliquée." + "\n";
                            } else {
                                try {
                                    Double.parseDouble(string);
                                    messVarDupliquée += "Attention ! vous avez une variable nommée avec un nombre.\n";
                                } catch (NumberFormatException ex) {//c'est une chaîne de caractéres
                                    try {//la variable commence par un chiffre
                                        Double.parseDouble(string.substring(0, 1));
                                        messVarDupliquée += "Attention ! vous avez une variable qui commence par un chiffre.\n";
                                    } catch (NumberFormatException ex2) {//variable correcte                                        
                                        variablesListe.add(string);
                                        if (listeTypesEnreg.contains(tmpType)) {//c'est une variable de type enregistrement
                                            messVarDupliquée += ajouterVarEnreg(string, tmpType);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            i++;
        }
        variablesListe.add(messVarDupliquée);
    }

    //complèter la liste des variables avec les variables locales des modules
    public void remplirVarLocales(String str) {
        String[] tabSpace = str.split(" ");
        for (String tabSpace1 : tabSpace) {
            String[] tab = tabSpace1.split(";");
            for (String string : tab) {
                string = string.replaceAll(" ", "");
                String[] tabVar = string.split(",");
                for (String string1 : tabVar) {
                    string1 = string1.toLowerCase();
                    if (string1.contains(":")) {
                        String[] tabDeuxPoint = string1.split(":");
                        if (!variablesListe.contains(tabDeuxPoint[0])) {
                            variablesListe.add(variablesListe.size() - 1, tabDeuxPoint[0]);
                        }
                    } else if (!variablesListe.contains(string1)) {
                        variablesListe.add(variablesListe.size() - 1, string1);
                    }
                }
            }
        }
    }

    //remplir la liste des modules avec les noms des modules déclarés
    public void remplirModules(int index) {
        int i = 0;
        while (i < index) {
            if ((contPrinc.getChildren().get(i) instanceof ModuleFonctionIntEntete)
                    || contPrinc.getChildren().get(i) instanceof ModuleProcedureIntEntete) {
                String tmpMod = ((ModuleInterne) contPrinc.getChildren().get(i)).tField1.getText().toLowerCase();
                if (!modulesListe.contains(tmpMod)) {
                    modulesListe.add(tmpMod);
                }
            } else if ((contPrinc.getChildren().get(i) instanceof ModuleExterneFon)
                    || contPrinc.getChildren().get(i) instanceof ModuleExternePro) {
                String listMod = ((ModuleExterne) contPrinc.getChildren().get(i)).tField1.getText();
                String[] tabModExt = listMod.split(",");
                for (String string : tabModExt) {
                    string = string.toLowerCase();
                    if (!modulesListe.contains(string)) {
                        modulesListe.add(string);
                    }
                }
            }
            i++;
        }
    }

    //ajouter les constantes dans la liste des variables
    public void remplirConst(int index) {
        while (!(contPrinc.getChildren().get(index) instanceof TypeEntete)) {
            index--;
        }
        index--;
        String tmp = "";
        while (!(contPrinc.getChildren().get(index) instanceof ConstanteEntete)) {
            tmp = ((ConstanteDeclar) contPrinc.getChildren().get(index)).tField1.getText().replaceAll(" ", "").toLowerCase();
            if (!constantesListe.contains(tmp)) {
                constantesListe.add(tmp);
            }
            index--;
        }
    }

    //remplir les types de retour des modules
    public void remplirTypesModules(int index) {//i: indice de l'objet où se ffait le traitement
        int i = 0;
        while (i < index) {
            //ajouter le type de retour de la fonction
            if (contPrinc.getChildren().get(i) instanceof ModuleFonctionIntEntete) {
                String tmpMod = ((ModuleInterne) contPrinc.getChildren().get(i)).tField1.getText().toLowerCase();
                String tmpType = ((ModuleInterne) contPrinc.getChildren().get(i)).typesElements.getEditor().getText().toLowerCase();
                if (!modulesTypesListe.containsKey(tmpMod)) {
                    modulesTypesListe.put(tmpMod, tmpType);
                }
            }
            i++;
        }
    }

    //remplir le map des variables avec leurs types
    public void remplirMapVarTypes(int i) {
        String tmpV = "", tmpT = "";
        while (!(contPrinc.getChildren().get(i) instanceof ModuleEntete
                || contPrinc.getChildren().get(i) instanceof ModuleFonctionIntEntete
                || contPrinc.getChildren().get(i) instanceof ModuleProcedureIntEntete
                || contPrinc.getChildren().get(i) instanceof ModuleExterneFon
                || contPrinc.getChildren().get(i) instanceof ModuleExternePro
                || contPrinc.getChildren().get(i) instanceof DEBUT)) {
            if (contPrinc.getChildren().get(i) instanceof VariableSimple || contPrinc.getChildren().get(i) instanceof VarStructureTab) {
                tmpV = ((Variable) contPrinc.getChildren().get(i)).tField1.getText().toLowerCase();
                tmpT = ((Variable) contPrinc.getChildren().get(i)).typesElements.getEditor().getText().toLowerCase();
                tmpV = tmpV.replaceAll(" ", "");
                tmpT = tmpT.replaceAll(" ", "");
                if (!tmpV.equals("") && !tmpT.equals("")) {
                    String[] tabVar = tmpV.split(",");
                    for (String string : tabVar) {
                        try {
                            Double.parseDouble(string);
                        } catch (NumberFormatException ex) {//c'est une chaîne de caractéres
                            variablesTypesListe.put(string, tmpT);
                            if (listeTypesEnreg.contains(tmpT)) {//c'est une variable de type enregistrement
                                ajouterTypeVarEnreg(string, tmpT);
                            }
                        }
                    }
                }
            }
            i++;
        }
    }

    //complèter avec les types des variables locales
    public void remplirTypesVarLocales(String str) {
        str = str.toLowerCase();
        String[] tab = str.split(";");
        for (String string : tab) {
            String[] tabTypeVar = string.split(":");
            String[] tabVar = tabTypeVar[0].split(",");
            for (String string1 : tabVar) {
                if (tabTypeVar.length > 1) {//vérifier s'il y a un type pour la variables locales
                    variablesTypesListe.put(string1, tabTypeVar[1]);
                }
            }
        }
    }

    //remplir les types Enregistrement
    public void remplirListeTypesEnreg(int index) {//i: indice de l'objet où se ffait le traitement
        while (!(contPrinc.getChildren().get(index) instanceof TypeEntete)) {
            if ((contPrinc.getChildren().get(index) instanceof TypeEnregistrementEntete) && (contPrinc.getChildren().get(index).getLayoutX() == 70)) {
                String tmp = ((TypeEnregistrementEntete) contPrinc.getChildren().get(index)).tField1.getText().toLowerCase();
                tmp = tmp.replaceAll(" ", "");
                if (!listeTypesEnreg.contains(tmp)) {
                    listeTypesEnreg.add(tmp);
                }
            }
            index--;
        }
    }

    //ajouter les vraiables de type Enregistrement
    private String ajouterVarEnreg(String nomVar, String nomType) {
        String result = "";
        int i = 0;
        boolean fin = false;
        while (!fin) {
            if ((contPrinc.getChildren().get(i) instanceof TypeEnregistrementEntete) && (((TypeEnregistrementEntete) contPrinc.getChildren().get(i)).tField1.getText().toLowerCase().equals(nomType))) {
                String tmpVar = nomVar + ".";
                double posX = contPrinc.getChildren().get(i).getLayoutX();
                i++;
                while (!(contPrinc.getChildren().get(i) instanceof TypeEnregistrementFin) || (contPrinc.getChildren().get(i).getLayoutX() != posX)) {
                    String varChamp = "";//la variable à ajouter desn la liste des variables
                    if (contPrinc.getChildren().get(i) instanceof TypeEnregistrementEntete) {
                        tmpVar += ((TypeEnregistrementEntete) contPrinc.getChildren().get(i)).tField1.getText().toLowerCase() + ".";
                    } else if (contPrinc.getChildren().get(i) instanceof TypeEnregistrementFin) {
                        tmpVar = tmpVar.substring(0, tmpVar.length() - 1);
                        tmpVar = tmpVar.substring(0, tmpVar.lastIndexOf('.') + 1);
                    } else {
                        //concaténer le nom de l'enregistrement avec le nom de la variable (champ dans l'enregistrement)
                        varChamp = tmpVar + ((Variable) contPrinc.getChildren().get(i)).tField1.getText().toLowerCase();
                        if (variablesListe.contains(varChamp)) {
                            result += "Attention ! La variable '" + varChamp + "' a été dupliquée." + "\n";
                        } else {
                            try {
                                Double.parseDouble(varChamp);
                            } catch (NumberFormatException nfe) {
                                variablesListe.add(varChamp);
                            }
                        }
                    }
                    i++;
                }
                fin = true;
            }
            i++;
        }
        return result;
    }

    //ajouter les types des variables de type Enregistrement
    private void ajouterTypeVarEnreg(String nomVar, String nomType) {
        int i = 0;
        boolean fin = false;
        while (!fin) {
            if ((contPrinc.getChildren().get(i) instanceof TypeEnregistrementEntete) && (((TypeEnregistrementEntete) contPrinc.getChildren().get(i)).tField1.getText().toLowerCase().equals(nomType))) {
                double posX = contPrinc.getChildren().get(i).getLayoutX();
                i++;
                while (!(contPrinc.getChildren().get(i) instanceof TypeEnregistrementFin) || (contPrinc.getChildren().get(i).getLayoutX() != posX)) {
                    String tmpVar = nomVar + ".", tmpT = "";
                    String varChamp = "";//la variable à ajouter dans la liste des variables
                    if (contPrinc.getChildren().get(i) instanceof TypeEnregistrementEntete) {
                        tmpVar += ((TypeEnregistrementEntete) contPrinc.getChildren().get(i)).tField1.getText().toLowerCase() + ".";
                    } else if (contPrinc.getChildren().get(i) instanceof TypeEnregistrementFin) {
                        tmpVar = tmpVar.substring(0, tmpVar.length() - 1);
                        tmpVar = tmpVar.substring(0, tmpVar.lastIndexOf('.') + 1);
                    } else {
                        //concaténer le nom de l'enregistrement avec le nom de la variable (champ dans l'enregistrement)
                        varChamp = tmpVar + ((Variable) contPrinc.getChildren().get(i)).tField1.getText().toLowerCase();
                        tmpT = ((Variable) contPrinc.getChildren().get(i)).typesElements.getEditor().getText().toLowerCase();
                        try {
                            Double.parseDouble(varChamp);
                        } catch (NumberFormatException nfe) {
                            variablesTypesListe.put(varChamp, tmpT);
                        }
                    }
                    i++;
                }
                fin = true;
            }
            i++;
        }
    }

    public ObservableList getVariablesListe() {
        return variablesListe;
    }

    public ObservableList getConstantesListe() {
        return constantesListe;
    }

    public ObservableList getModulesListe() {
        return modulesListe;
    }

    public ObservableList<String> getListeTypesEnreg() {
        return listeTypesEnreg;
    }

    public TreeMap<String, String> getVariablesTypesListe() {
        return variablesTypesListe;
    }

    public TreeMap<String, String> getModulesTypesListe() {
        return modulesTypesListe;
    }

}
