/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.contPrinc;
import static editeuralgoesi.FXMLDocumentController.undo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.scene.control.ComboBox;

/**
 *
 * @author mohammed_bey
 */
public abstract class Environnement extends Algorithme {

    //Liste des types des indices des tableaux
    protected static ObservableList typesIndicesList = FXCollections.observableArrayList("entier", "caractere", "booleen");
    //Liste des types des elements
    protected static ObservableList typesElementsList = FXCollections.observableArrayList("entier", "caractere", "booleen", "reel", "long-entier");

    protected ComboBox<String> typesIndices;//types des indices 
    protected ComboBox<String> typesElements;//types des elements 
    protected final IconeMiseAjourEnvironnement icMajEnv;

    public Environnement() {
        icMajEnv = new IconeMiseAjourEnvironnement();
        typesIndices = new ComboBox<>();
        typesIndices.setEditable(true);
        typesIndices.setPromptText("indMin..indMax");
        typesElements = new ComboBox<>();
        typesElements.setEditable(true);
        typesElements.setPromptText("type_élément");
        typesIndices.getEditor().getStyleClass().add("textfield");
        typesElements.getEditor().getStyleClass().add("textfield");
        typesIndices.getEditor().setPrefWidth(longChar(typesIndices.getEditor().getPromptText()));
        typesElements.getEditor().setPrefWidth(longChar(typesElements.getEditor().getPromptText()));

        //gérer les evenements sur les ComboBox
        typesIndices.setOnMouseClicked((Event t) -> {
            indice = contPrinc.getChildren().indexOf(typesIndices.getParent());
            declarerTypes(indice);
        });
        typesElements.setOnMouseClicked((Event t) -> {
            indice = contPrinc.getChildren().indexOf(typesElements.getParent());
            declarerTypes(indice);
        });
        //Gérer les evenements sur les menus de MiseÀjour:
        icMajEnv.setVisible(false);
        //le menu de MiseAjour apprait quand la souris entre dans la zone de l'objet
        setOnMouseEntered((Event t) -> {
            icMajEnv.setVisible(true);
        });
        //le menu de MiseAjour disparait quand la souris sort de la zone de l'objet
        setOnMouseExited((Event t) -> {
            icMajEnv.setVisible(false);
        });
    }

    //cette methode indique si on est dans la rubrique des variables
    protected boolean rubriqueVar(int index) {
        boolean result = false;
        int i = 0;
        while (i < index) {
            if (contPrinc.getChildren().get(i) instanceof VariableEntete) {
                result = true;
            }
            i++;
        }
        return result;
    }

    //La methode d'ajout d'un element
    protected void ajouterEl(Environnement el, int index) {
        if (!(el instanceof TypeEnregistrementFin)) {//pour eviter que quand on annule l'insertion d'un registrement il ne reste que l'entête de l'enregistrement
            Information info = new Information();//renvoie le contenu de panelAnchor
            pile.empiler(info.algoAsauvegarder());
            undo.setDisable(pile.estVide());
        }
        contPrinc.getChildren().add(index, el);//ajouter l'element au conteneur
        double posX = contPrinc.getChildren().get(index - 1).getLayoutX();
        if (contPrinc.getChildren().get(index - 1) instanceof TypeEnregistrementEntete && !(el instanceof TypeEnregistrementFin)) {//on est dans l'entete de l'enregistrement
            contPrinc.getChildren().get(index).setLayoutX(posX + 120);
        } else if (contPrinc.getChildren().get(index - 1) instanceof TypeEntete || contPrinc.getChildren().get(index - 1) instanceof VariableEntete || contPrinc.getChildren().get(index - 1) instanceof ConstanteEntete
                || contPrinc.getChildren().get(index - 1) instanceof VariableEnteteModule) {//on est dans l'entête
            contPrinc.getChildren().get(index).setLayoutX(70);
        } else {
            contPrinc.getChildren().get(index).setLayoutX(posX);
        }
        int j = contPrinc.getChildren().size();
        for (int i = index; i < j; i++) {
            if (contPrinc.getChildren().get(i) instanceof DEBUT || contPrinc.getChildren().get(i) instanceof DebutModule || contPrinc.getChildren().get(i) instanceof FinAlgo || contPrinc.getChildren().get(i) instanceof FinModule) {
                contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i - 1).getLayoutY() + 21 * 2);
            } else {
                contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i - 1).getLayoutY() + 21);
            }
        }
    }

    //La methode de suppression
    @Override
    protected void supprimerEl(int index) {
        Information info = new Information();//renvoie le contenu de panelAnchor
        pile.empiler(info.algoAsauvegarder());
        undo.setDisable(pile.estVide());
        //mettre à jur la liste des types
        typesIndicesList.remove(((Environnement) contPrinc.getChildren().get(index)).tField1.getText());
        typesElementsList.remove(((Environnement) contPrinc.getChildren().get(index)).tField1.getText());
        contPrinc.getChildren().remove(index);
        int j = contPrinc.getChildren().size();
        for (int i = index; i < j; i++) {
            if (contPrinc.getChildren().get(index) instanceof DebutModule || contPrinc.getChildren().get(index) instanceof FinModule) {
                contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i).getLayoutY() - 21 * 2);
            } else {
                contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i).getLayoutY() - 21);
            }
        }
    }

    //La methode qui permet de traduire les types en langage Pascal
    protected String typePascal(String type) {
        String result = "";
        switch (type) {
            case "entier":
                result = "integer";
                break;
            case "booleen":
                result = "boolean";
                break;
            case "caractere":
                result = "char";
                break;
            case "reel":
                result = "real";
                break;
            case "long-entier":
                result = "longint";
                break;
            default:
                result = type;
        }
        return result;
    }

    //Ajouter ce type à la liste des types
    protected void declarer() {
    }

    //cette methode permet de mettre tous les types declrés dans la liste des types jusqu'à l'indeice : index
    private void declarerTypes(int index) {
        if (index > 0) {//pour .viter le cas où l'éditeur ne contient qu'un module
            int cpt = 0;
            if (contPrinc.getChildren().get(index) instanceof ModuleFonctionIntEntete) {
                index--;
                while ((!(contPrinc.getChildren().get(index) instanceof VariableEntete) && !(contPrinc.getChildren().get(index) instanceof VariableEnteteModule)) || (cpt != 0)) {
                    if ((contPrinc.getChildren().get(index) instanceof FinModule)) {
                        cpt++;
                    } else if ((contPrinc.getChildren().get(index) instanceof ModuleFonctionIntEntete) || (contPrinc.getChildren().get(index) instanceof ModuleProcedureIntEntete)) {
                        cpt--;
                    }
                    index--;
                }
            }
            while (!(contPrinc.getChildren().get(index) instanceof TypeEntete)) {
                ((Environnement) contPrinc.getChildren().get(index)).declarer();
                index--;
            }
        }
    }
}
