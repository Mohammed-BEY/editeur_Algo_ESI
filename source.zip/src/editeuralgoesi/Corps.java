/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.contPrinc;
import static editeuralgoesi.FXMLDocumentController.undo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBuilder;
import javafx.scene.control.MenuItem;

/**
 *
 * @author mohammed_bey
 */
public class Corps extends Algorithme {

    protected static ObservableList<String> listeCoColler = FXCollections.observableArrayList();
    public MenuItem menuEnBclP, menuEnBclT, menuEnBclR;
    public Menu menuTransBcl;
    protected final IconeMiseAjourCorps icMajCorps;
    static protected boolean boolNonEmpiler = false;//indique qu'on n'empile pas (quand elle est vrai)    

    public Corps() {
        icMajCorps = new IconeMiseAjourCorps();
        icMajCorps.setPrefHeight(21);
        icMajCorps.menuAjouter.setText("ajouter une action");
        menuEnBclP = new MenuItem("bouclePour");
        menuEnBclT = new MenuItem("boucleTantQue");
        menuEnBclR = new MenuItem("boucleRepeter");
        menuTransBcl = MenuBuilder.create().text("transformer cette boucle en")
                .items(menuEnBclP, menuEnBclT, menuEnBclR).build();
        //******************** ***********Gestion des evenements****************************/
        //Gérer les evenements sur les menus de MiseÀjour:
        icMajCorps.setVisible(false);
        //le menu de MiseAjour apprait quand la souris entre dans la zone de l'objet
        setOnMouseEntered((Event t) -> {
            icMajCorps.setVisible(true);
        });
        //le menu de MiseAjour disparait quand la souris sort de la zone de l'objet
        setOnMouseExited((Event t) -> {
            icMajCorps.setVisible(false);
        });
        //ajouter l'objet d'Ecriture
        icMajCorps.menuIEcrire.setOnAction((ActionEvent event) -> {
            indice = contPrinc.getChildren().indexOf(icMajCorps.getParent()) + 1;
            ajouterEl(new Ecriture(), indice);
        });
        //ajouter l'objet de Lecture
        icMajCorps.menuILire.setOnAction((ActionEvent event) -> {
            indice = contPrinc.getChildren().indexOf(icMajCorps.getParent()) + 1;
            ajouterEl(new Lecture(), indice);
        });
        //*****************ajouter l'objet d'Affectation********************************/
        icMajCorps.menuIAffecter.setOnAction((ActionEvent event) -> {
            indice = contPrinc.getChildren().indexOf(icMajCorps.getParent()) + 1;
            ajouterEl(new Affectation(), indice);
        });
        //*****************ajouter la Conditonnelle*************************************/
        icMajCorps.menuIConditionnelle.setOnAction((ActionEvent event) -> {
            indice = contPrinc.getChildren().indexOf(icMajCorps.getParent()) + 1;
            ajouterBloc(indice, "cond");
        });
        //****************ajouter l'Alternative*****************************************/
        icMajCorps.menuIAlternative.setOnAction((ActionEvent event) -> {
            indice = contPrinc.getChildren().indexOf(icMajCorps.getParent()) + 1;
            ajouterBloc(indice, "alte");
        });
        //****************ajouter une boucle Pour***************************************/
        icMajCorps.menuIBclPour.setOnAction((ActionEvent event) -> {
            indice = contPrinc.getChildren().indexOf(icMajCorps.getParent()) + 1;
            ajouterBloc(indice, "bclP");
        });
        //****************ajouter une boucle TantQue***************************************/
        icMajCorps.menuIBclTQ.setOnAction((ActionEvent event) -> {
            indice = contPrinc.getChildren().indexOf(icMajCorps.getParent()) + 1;
            ajouterBloc(indice, "bclT");
        });
        //****************ajouter une boucle Repeter***************************************/
        icMajCorps.menuIBclRepeter.setOnAction((ActionEvent event) -> {
            indice = contPrinc.getChildren().indexOf(icMajCorps.getParent()) + 1;
            ajouterBloc(indice, "bclR");
        });
        //****************ajouter un commentaire*******************************************/
        icMajCorps.menuComent.setOnAction((ActionEvent event) -> {
            indice = contPrinc.getChildren().indexOf(icMajCorps.getParent()) + 1;
            ajouterEl(new CommentaireCorps(), indice);
        });
        //****************ajouter un appel procédure***************************************/
        icMajCorps.menuIAppelProc.setOnAction((ActionEvent event) -> {
            indice = contPrinc.getChildren().indexOf(icMajCorps.getParent()) + 1;
            ajouterEl(new AppelProc(), indice);
        });
        //****************copier un element*************************************************/
        icMajCorps.menuCopier.setOnAction((ActionEvent event) -> {
            indice = contPrinc.getChildren().indexOf(icMajCorps.getParent());
            copier(indice);
        });
        //*****************couper un element************************************************/
        icMajCorps.menuCouper.setOnAction((ActionEvent event) -> {
            indice = contPrinc.getChildren().indexOf(icMajCorps.getParent());
            couper(indice);
        });
        //****************coller ce qui est dans la liste dans l'editeur********************/
        icMajCorps.menuColler.setOnAction((ActionEvent event) -> {
            indice = contPrinc.getChildren().indexOf(icMajCorps.getParent()) + 1;
            coller(indice);
        });
        //******************Transformer une boucle en une autre*****************************/
        //******************En boucle Pour**************************************************/
        menuEnBclP.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajCorps.getParent());
            transBcl(new BouclePourEntete(), new BouclePourDebut(), new BouclePourFin(), indice);
        });
        //******************En boucle TantQue***********************************************/
        menuEnBclT.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajCorps.getParent());
            transBcl(new BoucleTantQueEntete(), new BoucleTantQueDebut(), new BoucleTantQueFin(), indice);
        });
        //******************En boucle Repeter***********************************************/
        menuEnBclR.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajCorps.getParent());
            transBcl(new BoucleRepeterEntete(), null, new BoucleRepeterJusqua(), indice);
        });
        //supprime un element
        icMajCorps.menuSupprimer.setOnAction((ActionEvent event) -> {
            indice = contPrinc.getChildren().indexOf(icMajCorps.getParent());
            supprimerEl(indice);
        });
    }

    //La methode d'ajout d'un element
    protected void ajouterEl(Corps el, int index) {
        if (!boolNonEmpiler) {//si on l'utilise hors que la methode Coller
            Information info = new Information();//renvoie le contenu du conteneur principal
            pile.empiler(info.algoAsauvegarder());
            undo.setDisable(pile.estVide());
        }
        contPrinc.getChildren().add(index, el);
        double posX = contPrinc.getChildren().get(index - 1).getLayoutX();
        if (contPrinc.getChildren().get(index - 1) instanceof CondAltEntete || contPrinc.getChildren().get(index - 1) instanceof AlternativeSINON || contPrinc.getChildren().get(index - 1) instanceof BouclePourEntete || contPrinc.getChildren().get(index - 1) instanceof BoucleTantQueEntete) {
            posX += 21;
        }
        if (contPrinc.getChildren().get(index - 1) instanceof ConditionnelleFin || contPrinc.getChildren().get(index - 1) instanceof AlternativeFSI || contPrinc.getChildren().get(index - 1) instanceof AlternativeFSIN || contPrinc.getChildren().get(index - 1) instanceof BouclePourFin || contPrinc.getChildren().get(index - 1) instanceof BoucleTantQueFin) {
            contPrinc.getChildren().get(index).setLayoutX(posX - 21);
        } else {
            contPrinc.getChildren().get(index).setLayoutX(posX);
        }
        int j = contPrinc.getChildren().size();
        for (int i = index; i < j; i++) {
            if (contPrinc.getChildren().get(i) instanceof DEBUT || contPrinc.getChildren().get(i) instanceof DebutModule || contPrinc.getChildren().get(i) instanceof FinAlgo) {
                contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i - 1).getLayoutY() + 21 * 2);
            } else {
                contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i - 1).getLayoutY() + 21);
            }
        }
    }

    //La methode d'ajout d'un bloc
    private void ajouterBloc(int index, String str) {
        Information info = new Information();//renvoie le contenu de panelAnchor
        pile.empiler(info.algoAsauvegarder());
        undo.setDisable(pile.estVide());

        double posX = contPrinc.getChildren().get(index - 1).getLayoutX();
        switch (str) {
            case "cond":
                contPrinc.getChildren().add(index, new CondAltEntete());
                contPrinc.getChildren().add(index + 1, new CondAltDebut());
                contPrinc.getChildren().add(index + 2, new ConditionnelleFin());
                if (contPrinc.getChildren().get(index - 1) instanceof ConditionnelleFin || contPrinc.getChildren().get(index - 1) instanceof AlternativeFSIN || contPrinc.getChildren().get(index - 1) instanceof BouclePourFin || contPrinc.getChildren().get(index - 1) instanceof BoucleTantQueFin) {
                    contPrinc.getChildren().get(index).setLayoutX(posX - 21);
                } else {
                    contPrinc.getChildren().get(index).setLayoutX(posX);
                }
                contPrinc.getChildren().get(index + 1).setLayoutX(contPrinc.getChildren().get(index).getLayoutX() + 21);
                contPrinc.getChildren().get(index + 2).setLayoutX(contPrinc.getChildren().get(index).getLayoutX() + 21);
                break;
            case "alte":
                contPrinc.getChildren().add(index, new CondAltEntete());
                contPrinc.getChildren().add(index + 1, new CondAltDebut());
                contPrinc.getChildren().add(index + 2, new AlternativeFSI());
                contPrinc.getChildren().add(index + 3, new AlternativeSINON());
                contPrinc.getChildren().add(index + 4, new AlternativeDSIN());
                contPrinc.getChildren().add(index + 5, new AlternativeFSIN());
                if (contPrinc.getChildren().get(index - 1) instanceof ConditionnelleFin || contPrinc.getChildren().get(index - 1) instanceof AlternativeFSIN || contPrinc.getChildren().get(index - 1) instanceof BouclePourFin || contPrinc.getChildren().get(index - 1) instanceof BoucleTantQueFin) {
                    contPrinc.getChildren().get(index).setLayoutX(posX - 21);
                    contPrinc.getChildren().get(index + 3).setLayoutX(posX - 21);
                } else {
                    contPrinc.getChildren().get(index).setLayoutX(posX);
                    contPrinc.getChildren().get(index + 3).setLayoutX(posX);
                }
                contPrinc.getChildren().get(index + 1).setLayoutX(contPrinc.getChildren().get(index).getLayoutX() + 21);
                contPrinc.getChildren().get(index + 2).setLayoutX(contPrinc.getChildren().get(index).getLayoutX() + 21);
                contPrinc.getChildren().get(index + 4).setLayoutX(contPrinc.getChildren().get(index).getLayoutX() + 21);
                contPrinc.getChildren().get(index + 5).setLayoutX(contPrinc.getChildren().get(index).getLayoutX() + 21);
                break;
            case "bclP":
                contPrinc.getChildren().add(index, new BouclePourEntete());
                contPrinc.getChildren().add(index + 1, new BouclePourDebut());
                contPrinc.getChildren().add(index + 2, new BouclePourFin());
                if (contPrinc.getChildren().get(index - 1) instanceof ConditionnelleFin || contPrinc.getChildren().get(index - 1) instanceof AlternativeFSIN || contPrinc.getChildren().get(index - 1) instanceof BouclePourFin || contPrinc.getChildren().get(index - 1) instanceof BoucleTantQueFin) {
                    contPrinc.getChildren().get(index).setLayoutX(posX - 21);
                } else {
                    contPrinc.getChildren().get(index).setLayoutX(posX);
                }
                contPrinc.getChildren().get(index + 1).setLayoutX(contPrinc.getChildren().get(index).getLayoutX() + 21);
                contPrinc.getChildren().get(index + 2).setLayoutX(contPrinc.getChildren().get(index).getLayoutX() + 21);
                break;
            case "bclT":
                contPrinc.getChildren().add(index, new BoucleTantQueEntete());
                contPrinc.getChildren().add(index + 1, new BoucleTantQueDebut());
                contPrinc.getChildren().add(index + 2, new BoucleTantQueFin());
                if (contPrinc.getChildren().get(index - 1) instanceof ConditionnelleFin || contPrinc.getChildren().get(index - 1) instanceof AlternativeFSIN || contPrinc.getChildren().get(index - 1) instanceof BouclePourFin || contPrinc.getChildren().get(index - 1) instanceof BoucleTantQueFin) {
                    contPrinc.getChildren().get(index).setLayoutX(posX - 21);
                } else {
                    contPrinc.getChildren().get(index).setLayoutX(posX);
                }
                contPrinc.getChildren().get(index + 1).setLayoutX(contPrinc.getChildren().get(index).getLayoutX() + 21);
                contPrinc.getChildren().get(index + 2).setLayoutX(contPrinc.getChildren().get(index).getLayoutX() + 21);
                break;
            case "bclR":
                contPrinc.getChildren().add(index, new BoucleRepeterEntete());
                contPrinc.getChildren().add(index + 1, new BoucleRepeterJusqua());
                if (contPrinc.getChildren().get(index - 1) instanceof ConditionnelleFin || contPrinc.getChildren().get(index - 1) instanceof AlternativeFSIN || contPrinc.getChildren().get(index - 1) instanceof BouclePourFin || contPrinc.getChildren().get(index - 1) instanceof BoucleTantQueFin) {
                    contPrinc.getChildren().get(index).setLayoutX(posX - 21);
                    contPrinc.getChildren().get(index + 1).setLayoutX(posX - 21);
                } else {
                    contPrinc.getChildren().get(index).setLayoutX(posX);
                    contPrinc.getChildren().get(index + 1).setLayoutX(posX);
                }
                break;
            default:
                throw new AssertionError();
        }

        int j = contPrinc.getChildren().size();
        for (int i = index; i < j; i++) {
            if (contPrinc.getChildren().get(i) instanceof FinAlgo || contPrinc.getChildren().get(i) instanceof DEBUT) {
                contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i - 1).getLayoutY() + 21 * 2);
            } else {
                contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i - 1).getLayoutY() + 21);
            }

        }
    }

    //La methode de suppression
    @Override
    protected void supprimerEl(int index) {
        contPrinc.getChildren().remove(index);
        int j = contPrinc.getChildren().size();
        for (int i = index; i < j; i++) {
            contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i).getLayoutY() - 21);
        }
    }

    //LA methode de copier
    @Override
    protected void copier(int index) {
        listeCoColler.clear();
        listeCoColler.add(((Corps) contPrinc.getChildren().get(index)).coColler());
    }

    //La methode de couper
    @Override
    protected void couper(int index) {
        copier(index);
        supprimerEl(index);
    }

    /**
     *
     * @param index
     */
    @Override
    protected void coller(int index) {
        if (!listeCoColler.isEmpty()) {
            boolNonEmpiler = true;//rendre à Vrai pour ne pas empiler à l'ajout de chaque element
            Information info = new Information();//renvoie le contenu de panelAnchor
            pile.empiler(info.algoAsauvegarder());
            undo.setDisable(pile.estVide());
        }
        for (String string : listeCoColler) {
            ajouterEl((Corps) creerObjet(string), index);
            index++;
        }
        boolNonEmpiler = false;
    }

    //La methode de transformation d'une boucle à une autre
    protected void transBcl(Corps el1, Corps el2, Corps el3, int index) {
        boolNonEmpiler = true;//rendre à Vrai pour ne pas empiler à l'ajout de chaque element
        Information info = new Information();//renvoie le contenu de panelAnchor
        pile.empiler(info.algoAsauvegarder());
        undo.setDisable(pile.estVide());

        double posX = contPrinc.getChildren().get(index).getLayoutX();
        boolean bclRepeter = false;//indique si on veut transformer à la boucle Repeter
        if (el1 instanceof BoucleRepeterEntete) {
            bclRepeter = true;
        }
        supprimer(index);
        supprimer(index);
        ajouterEl(el1, index);
        if (!(el2 == null)) {
            ajouterEl(el2, index + 1);
        }
        index++;
        while (!((contPrinc.getChildren().get(index) instanceof BouclePourFin || contPrinc.getChildren().get(index) instanceof BoucleTantQueFin) && (contPrinc.getChildren().get(index).getLayoutX() == posX + 21))) {
            if (bclRepeter) {//on veut transformer à une boucle Repeter
                contPrinc.getChildren().get(index).setLayoutX(contPrinc.getChildren().get(index).getLayoutX() - 21);
            }
            index++;
        }
        supprimer(index);
        ajouterEl(el3, index);
        boolNonEmpiler = false;
    }

    //La methode de suppression
    private void supprimer(int index) {
        contPrinc.getChildren().remove(index);
        int j = contPrinc.getChildren().size();
        for (int i = index; i < j; i++) {
            contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i).getLayoutY() - 21);
        }
    }

    //La methode qui permet de créer un objet à partir de la balise en paramètre
    protected Algorithme creerObjet(String str) {
        String[] tab = str.split("#");
        String balise = tab[0];
        Object o = null;//l'objet à retourner
        switch (balise) {
            case "<comC>":
                o = new CommentaireCorps();
                break;
            case "<affA>":
                o = new Affectation();
                break;
            case "<ecrA>":
                o = new Ecriture();
                break;
            case "<lecA>":
                o = new Lecture();
                break;
            case "<conE>":
                o = new CondAltEntete();
                break;
            case "<conD>":
                o = new CondAltDebut();
                break;
            case "<conF>":
                o = new ConditionnelleFin();
                break;
            case "<altC>":
                o = new AlternativeFSI();
                break;
            case "<altS>":
                o = new AlternativeSINON();
                break;
            case "<altN>":
                o = new AlternativeDSIN();
                break;
            case "<altF>":
                o = new AlternativeFSIN();
                break;
            case "<bcpE>":
                o = new BouclePourEntete();
                break;
            case "<bcpD>":
                o = new BouclePourDebut();
                break;
            case "<bcpF>":
                o = new BouclePourFin();
                break;
            case "<bctE>":
                o = new BoucleTantQueEntete();
                break;
            case "<bctD>":
                o = new BoucleTantQueDebut();
                break;
            case "<bctF>":
                o = new BoucleTantQueFin();
                break;
            case "<bcrE>":
                o = new BoucleRepeterEntete();
                break;
            case "<bcrJ>":
                o = new BoucleRepeterJusqua();
                break;
            default:
                throw new AssertionError();
        }
        ((Algorithme) o).setContenu(str);
        return (Algorithme) o;
    }

    protected String designation() {
        return "";
    }

    //Méthode qui envoie le message d'erreur après avoir vérifié les erreurs
    protected String messVerification(String str, Object[] listListesDecl) {
        String result = "";
        try {//tester si la chaine est un nombre
            Double.parseDouble(str);//c'est un nombre
        } catch (NumberFormatException e) {//c'est une chaine de caracteres
            //c'est une variable
            String tmp = str.toLowerCase();
            if ((!tabMotsCles.contains(tmp)) && (!((ObservableList) listListesDecl[0]).contains(tmp)) && (!((ObservableList) listListesDecl[1]).contains(tmp))
                    && (!((ObservableList) listListesDecl[2]).contains(tmp)) && (!((ObservableList) listListesDecl[3]).contains(tmp))) {
                result += "Attention ! '" + str + "' utilisée dans " + designation() + ", n'a pas été déclarée.\n";
            }
        }
        return result;
    }

}
