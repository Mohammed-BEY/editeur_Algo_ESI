/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

/**
 *
 * @author mohammed_bey
 */
//La classe qui désigne les débuts des blocs des onstructions
public class LesDebuts extends Corps {

    public LesDebuts() {
        super();
        label1.getStyleClass().add("labDebFinBoucle");
        icMajCorps.menuCopier.setDisable(true);
        icMajCorps.menuCouper.setDisable(true);
        icMajCorps.menuSupprimer.setDisable(true);
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return "begin";
    }

    //redefinir la methode couper de telle sorte qu'elle ne fait rien
    @Override
    protected void copier(int index) {
    }

    //redefinir la methode couper de telle sorte qu'elle ne fait rien
    @Override
    protected void couper(int index) {
    }
    
    //redefinir la methode de telle sorte qu'elle ne fait rien
    @Override
    protected void supprimerEl(int index) {
    }
}
