/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.contPrinc;

/**
 *
 * @author mohammed_bey
 */
public class ModuleFonction {

    public ModuleFonction() {
        contPrinc.getChildren().add(new ModuleFonctionIntEntete());
        contPrinc.getChildren().add(new ConstanteEntete());
        contPrinc.getChildren().add(new TypeEntete());
        contPrinc.getChildren().add(new VariableEntete());
        contPrinc.getChildren().add(new ModuleEntete());
        contPrinc.getChildren().add(new DebutModule());
        contPrinc.getChildren().add(new ModuleFonctionIntRetour());
        contPrinc.getChildren().add(new FinAlgo());
//        ajuster les positions x et y
        contPrinc.getChildren().get(1).setLayoutY(21 * 1);
        contPrinc.getChildren().get(2).setLayoutY(21 * 2);
        contPrinc.getChildren().get(3).setLayoutY(21 * 3);
        contPrinc.getChildren().get(4).setLayoutY(21 * 4);
        contPrinc.getChildren().get(5).setLayoutY(21 * 5 + 21);
        contPrinc.getChildren().get(6).setLayoutY(21 * 6 + 21);
        contPrinc.getChildren().get(7).setLayoutY(21 * 7 + 21 * 2);        
    }
}
