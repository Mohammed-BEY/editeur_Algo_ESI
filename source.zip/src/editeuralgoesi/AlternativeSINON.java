/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

/**
 *
 * @author mohammed_bey
 */
public class AlternativeSINON extends LesEntetes {

    public AlternativeSINON() {
        label1.setText("Sinon");
        this.getChildren().addAll(label1, icMajCorps);
        /**
         * *********************Gestion des evenements du menuIcone de
         * MiseAJour:*********************
         */
        icMajCorps.menuCopier.setDisable(true);
        icMajCorps.menuCouper.setDisable(true);
        icMajCorps.menuColler.setDisable(true);
    }

    @Override
    public String toString() {
        String resultat = "";
        resultat += "Sinon";
        return resultat;
    }

    @Override
    protected String coColler() {
        return "<altS>";
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return "else";
    }
}
