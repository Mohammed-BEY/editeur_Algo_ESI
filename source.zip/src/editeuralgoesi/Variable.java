/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.contPrinc;
import javafx.event.ActionEvent;

/**
 *
 * @author mohammed_bey
 */
//Cette classe permet de manipuler les variables
public class Variable extends Environnement {

    public Variable() {
        icMajEnv.menuAjouter.getItems().removeAll(icMajEnv.menuConst,
                icMajEnv.menuITypeChaineDeCar, icMajEnv.menuITypeEnsemble, icMajEnv.menuITypeEnreg,
                icMajEnv.menuITypeEnumere, icMajEnv.menuITypeIntervalle, icMajEnv.menuTab,
                icMajEnv.menuFonction, icMajEnv.menuProcedure);
        //*** ***************Gestion des evenements des touches des menus**************************/
        //**** ***************Ajout D'une variable simple**********************/
        icMajEnv.menuSimple.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            if (rubriqueVar(indice)) {
                ajouterEl(new VariableSimple('v'), indice);
            } else {
                ajouterEl(new VariableSimple('e'), indice);
            }
        });
        //************** ***************AJOUT D'une vriable tableau*******************************/
        icMajEnv.menuTableau.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            if (rubriqueVar(indice)) {
                ajouterEl(new VarStructureTab('v'), indice);
            } else {
                ajouterEl(new VarStructureTab('e'), indice);
            }
        });
        //*************** Ajout d'une variable chaine de caracteres******************************/
        icMajEnv.menuChaine.setOnAction((ActionEvent event) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            if (rubriqueVar(indice)) {
                ajouterEl(new VarChaineDeCar('v'), indice);
            } else {
                ajouterEl(new VarChaineDeCar('e'), indice);
            }
        });
        //*************** Ajout d'une variable : Pointeur******************************/
        icMajEnv.menuPtr.setOnAction((ActionEvent event) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            if (rubriqueVar(indice)) {
                ajouterEl(new VarPointeur('v'), indice);
            } else {
                ajouterEl(new VarPointeur('e'), indice);
            }
        });
        //*** ***************Ajout du type :Enregistrement**************************************/
        icMajEnv.menuITypeEnreg.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            ajouterEl(new TypeEnregistrementEntete(), indice);
            ajouterEl(new TypeEnregistrementFin('i'), indice + 1);
        });
        //*********************** *****Ajout d'un commentaire*********************************/
        icMajEnv.menuComent.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            ajouterEl(new CommentaireEnvVar(), indice);
        });
        //supprimer la variable où la souris se trouve
        icMajEnv.menuSupprimer.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent());
            supprimerEl(indice);
        });
    }

    //Cette methode indique s'il y a au moins une variable déclarée
    protected boolean varExist(int i) {
        boolean result = false;
        if (!(contPrinc.getChildren().get(i + 1) instanceof ModuleEntete || contPrinc.getChildren().get(i + 1) instanceof ModuleFonctionIntEntete
                || contPrinc.getChildren().get(i + 1) instanceof ModuleProcedureIntEntete || contPrinc.getChildren().get(i + 1) instanceof ModuleExterneFon
                || contPrinc.getChildren().get(i + 1) instanceof ModuleExternePro)) {//il n'y a aucune variable déclarée
            result = true;
        }
        return result;
    }
}
