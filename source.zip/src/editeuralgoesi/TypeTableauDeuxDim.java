/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

/**
 *
 * @author mohammed_bey
 */
public class TypeTableauDeuxDim extends TYPE {

    public TypeTableauDeuxDim() {//0:insertions à l'entete , 1:insertion au milieu        
        super();
        tField1.setPromptText("Nom_du_tableau");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        label1.setText("= Tableau [");
        label2.setText("] de ");
        label1.setStyle("-fx-text-fill:rgb(30,21,134);");
        label2.setStyle("-fx-text-fill:rgb(30,21,134);");
        icMajEnv.menuAjouter.getItems().removeAll(icMajEnv.menuSimple, icMajEnv.menuChaine, icMajEnv.menuTableau);
        /**
         * *********Les indices************
         */
        typesIndices.setId("typeIndicesTabDeuxDim");
        typesIndices.setItems(typesIndicesList);
        typesIndices.setPromptText("indMin1..indMax1,indMin2..indMax2");
        /**
         * ********Les elements ***********
         */
        typesElements.setId("typeElementsTabUneDim");
        typesElements.setItems(typesElementsList);
        getChildren().addAll(tField1, label1, typesIndices, label2, typesElements, icMajEnv);
    }

    @Override
    public String toString() {
        String resultat = "";
        resultat += tField1.getText() + " = TABLEAU [" + typesIndices.getEditor().getText()
                + "] de  " + typesElements.getEditor().getText();
        return resultat;
    }

    @Override
    public void setContenu(String str) {
        String[] tab = str.split("#");
        int i = 1;
        if (i < tab.length) {
            tField1.setText(tab[i]);
            i++;
        }
        if (i < tab.length) {
            typesIndices.setValue(tab[i]);
            i++;
        }
        if (i < tab.length) {
            typesElements.setValue(tab[i]);
        }
    }

    @Override
    protected String coColler() {
        return "<typQ>" + "#" + tField1.getText() + "#" + typesIndices.getEditor().getText() + "#" + typesElements.getEditor().getText();
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return tField1.getText() + " = array[" + typePascal(typesIndices.getEditor().getText()) + "] of " + typePascal(typesElements.getEditor().getText()) + " ;";
    }
}
