/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import javafx.application.Preloader;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

public class MyPreloader extends Preloader {

    private Stage preloaderStage;

    public MyPreloader() throws InterruptedException {
        // Constructor is called before everything.
        System.out.println("MyPreloader constructor called, thread: " + Thread.currentThread().getName());
    }

    @Override
    public void init() throws Exception {
        System.out.println("MyPreloader#init (could be used to initialize preloader view), thread: " + Thread.currentThread().getName());

        // If preloader has complex UI it's initialization can be done in MyPreloader#init
//        Platform.runLater(() -> {
//        });
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        System.out.println("I am the start method!");
        FXMLLoader fxml = new FXMLLoader(getClass().getResource("Demarrage.fxml"));
        Parent root = fxml.load();
        primaryStage.setTitle("MonPremierAlgo");
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        scene.getStylesheets().add(EditeurAlgoESI.class.getResource("demarrage.css").toExternalForm());
        primaryStage.getIcons().add(new Image(EditeurAlgoESI.class.getResourceAsStream("images/MonPremierALgo.png")));
        primaryStage.setIconified(false);
        preloaderStage = primaryStage;

        scene.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode().equals(KeyCode.ESCAPE) || e.getCode().equals(KeyCode.ENTER) || e.getCode().equals(KeyCode.SPACE)) {
                primaryStage.close();
            }
        });
        primaryStage.show();
    }

    @Override
    public void handleStateChangeNotification(StateChangeNotification info) {
        // Handle state change notifications.
        StateChangeNotification.Type type = info.getType();
        switch (type) {
            case BEFORE_LOAD:
                // Called after MyPreloader#start is called.
                System.out.println("BEFORE_LOAD");
                break;
            case BEFORE_INIT:
                // Called before EditeurAlgoESI#init is called.
                System.out.println("BEFORE_INIT");
                break;
            case BEFORE_START:
                // Called after EditeurAlgoESI#init and before EditeurAlgoESI#start is called.
                System.out.println("BEFORE_START");
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException ex) {
                }
                preloaderStage.hide();
                break;
        }
    }
}
