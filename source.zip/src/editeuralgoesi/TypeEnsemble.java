/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

/**
 *
 * @author mohammed_bey
 */
public class TypeEnsemble extends TYPE {

    public TypeEnsemble() {
        super();
        tField1.setPromptText("nom_ensemble");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        label1.setText(" =  Ensemble De ");
        label1.setStyle("-fx-text-fill:rgb(30,21,134);");
        /**
         * ********Les elements ***********
         */
        typesElements.setId("typeIndicesTabUneDim");
        typesElements.setItems(typesElementsList);
        typesElements.setEditable(true);
        getChildren().addAll(tField1, label1, typesElements, icMajEnv);
        icMajEnv.menuAjouter.getItems().removeAll(icMajEnv.menuSimple, icMajEnv.menuChaine, icMajEnv.menuTableau);
    }

    @Override
    public String toString() {
        String resultat = "";
        resultat += tField1.getText() + " = ENSEMBLE DE  " + typesElements.getEditor().getText();
        return resultat;
    }

    @Override
    public void setContenu(String str) {
        String[] tab = str.split("#");
        int i = 1;
        if (i < tab.length) {
            tField1.setText(tab[i]);
            i++;
        }
        if (i < tab.length) {
            typesElements.setValue(tab[i]);
        }
    }

    @Override
    protected String coColler() {
        return "<typS>" + "#" + tField1.getText() + "#" + typesElements.getEditor().getText();
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return tField1.getText() + " Set of" + typePascal(typesElements.getEditor().getText()) + " ;";
    }
}
