/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

/**
 *
 * @author mohammed_bey
 */
public class TypeEnregistrementFin extends TYPE {

    public TypeEnregistrementFin(char c) {
        super();
        label1.setText("FIN");
        label1.setStyle("-fx-text-fill:rgb(30,21,134);");
        this.getChildren().addAll(label1, icMajEnv);
        switch (c) {
            case 'e'://on ajoute à partir de l'entête des types
                icMajEnv.menuAjouter.getItems().removeAll(icMajEnv.menuSimple, icMajEnv.menuTableau, icMajEnv.menuChaine);
                icMajEnv.menuMAJ.getItems().remove(icMajEnv.menuSupprimer);
                break;
            case 'i'://on ajoute à l'interieur de l'eregistrement
                icMajEnv.menuAjouter.setText("ajouter un champ");
                icMajEnv.menuAjouter.getItems().removeAll(icMajEnv.menuITypeChaineDeCar, icMajEnv.menuITypeEnumere,
                        icMajEnv.menuITypeIntervalle, icMajEnv.menuTab, icMajEnv.menuITypeEnsemble);
                icMajEnv.menuSimple.setText("variable simple");
                icMajEnv.menuChaine.setText("variable chaine");
                icMajEnv.menuTableau.setText("variable tableau");
                break;
            default:
                throw new AssertionError();
        }
    }

    @Override
    public String toString() {
        String resultat = "";
        resultat += "FIN";
        return resultat;
    }

    @Override
    protected String coColler() {
        return "<typF>";
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return "End;";
    }

    //redefinir la methode de tel sorte qu'elle ne fait rien
    @Override
    public void declarer() {
    }
}
