/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

/**
 *
 * @author mohammed_bey
 */
//La fin d'un module
public class FinModule extends Modules {

    public FinModule() {
        label1.setText("FIN");
        label1.setStyle("-fx-font-weight: bold;"
                + "-fx-text-fill:rgb(0,128,192);"
                + "-fx-font-size:12px;");
        this.getChildren().addAll(label1, icMajEnv);
        /**
         * ***********************Gestion des Evenements
         * ********************************
         */
        icMajEnv.menuAjouter.getItems().removeAll(icMajEnv.menuConst, icMajEnv.menuSimple, icMajEnv.menuTableau, icMajEnv.menuChaine,
                icMajEnv.menuITypeChaineDeCar, icMajEnv.menuITypeEnreg, icMajEnv.menuITypeEnsemble,
                icMajEnv.menuITypeEnumere, icMajEnv.menuITypeIntervalle, icMajEnv.menuTab, icMajEnv.menuPtr);
        icMajEnv.menuMAJ.getItems().removeAll(icMajEnv.menuSupprimer, icMajEnv.menuComent);
    }

    @Override
    public String toString() {
        String resultat = "";
        resultat += "FIN";
        return resultat;
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return "End;\n";
    }

    //La methode qui permet de recuperer le contenu textuel de l'objet pour le mettre dans la liste de copier-couper/coller
    @Override
    protected String coColler() {
        return "<modF>";
    }

    //redefinir la methode de telle sorte qu'elle ne fait rien
    @Override
    protected void supprimerEl(int index) {
    }
}
