
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

/**
 *
 * @author mohammed_bey
 */
public class BoucleTantQueDebut extends LesDebuts {

    public BoucleTantQueDebut() {
        label1.setText("DTQ");
        this.getChildren().addAll(label1, icMajCorps);
    }

    @Override
    public String toString() {
        String resultat = "";
        resultat += "DTQ";
        return resultat;
    }

    @Override
    protected String coColler() {
        return "<bctD>";
    }
}
