/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.contPrinc;
import static editeuralgoesi.FXMLDocumentController.undo;
import javafx.event.ActionEvent;

/**
 *
 * @author mohammed_bey
 */
public class TypeEnregistrementEntete extends TYPE {

    public TypeEnregistrementEntete() {
        super();
        icMajEnv.menuAjouter.setText("ajouter un champ");
        label1.setText("  =  Enregistrement");
        label1.setStyle("-fx-text-fill:rgb(30,21,134);");
        tField1.setPromptText("nom_enregistrement");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        getChildren().addAll(tField1, label1, icMajEnv);
        icMajEnv.menuSimple.setText("variable simple");
        icMajEnv.menuChaine.setText("variable chaine");
        icMajEnv.menuTableau.setText("variable tableau");

        icMajEnv.menuAjouter.getItems().removeAll(icMajEnv.menuITypeChaineDeCar, icMajEnv.menuITypeEnumere, icMajEnv.menuITypeIntervalle,
                icMajEnv.menuTab, icMajEnv.menuITypeEnsemble);
        /**
         * ***************Gestion des evenements ************************
         */
        //*** ***************AJOUT DU TYPE : ENREGISTREMENT******************************/
        icMajEnv.menuITypeEnreg.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            ajouterEl(new TypeEnregistrementEntete(), indice);
            ajouterEl(new TypeEnregistrementFin('i'), indice + 1);
        });
        //*************** *****Ajout d'un commentaire*******************************/
        icMajEnv.menuComent.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            ajouterEl(new CommentaireEnvType('i'), indice);
        });
        //*** **************La suppression d'un bloc d'enregistrement********************/
        icMajEnv.menuSupprimer.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent());
            supprimerEl(indice);
        });
    }

    //La methode de suppression
    /**
     *
     * @param index
     */
    @Override
    protected void supprimerEl(int index) {
        Information info = new Information();//renvoie le contenu de panelAnchor
        pile.empiler(info.algoAsauvegarder());
        undo.setDisable(pile.estVide());
        //mettre à jur la liste des types
        typesIndicesList.remove(((Environnement) contPrinc.getChildren().get(index)).tField1.getText());
        typesElementsList.remove(((Environnement) contPrinc.getChildren().get(index)).tField1.getText());
        double posX = contPrinc.getChildren().get(index).getLayoutX();
        while (!((contPrinc.getChildren().get(index) instanceof TypeEnregistrementFin) && (contPrinc.getChildren().get(index).getLayoutX() == posX))) {
            supprimer(index);
        }
        supprimer(index);//supprimer la fin de l'enregistrement
    }

    //redefinir la methode de suppression de telle sorte qu'elle n'empile pas
    private void supprimer(int index) {
        contPrinc.getChildren().remove(index);
        int j = contPrinc.getChildren().size();
        for (int i = index; i < j; i++) {
            if (contPrinc.getChildren().get(index) instanceof DebutModule || contPrinc.getChildren().get(index) instanceof FinModule) {
                contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i).getLayoutY() - 21 * 2);
            } else {
                contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i).getLayoutY() - 21);
            }
        }
    }

    @Override
    public String toString() {
        String resultat = "";
        resultat += tField1.getText() + " = Enregistrement ";
        return resultat;
    }

    @Override
    public void setContenu(String str) {
        String[] tab = str.split("#");
        int i = 1;
        if (i < tab.length) {
            tField1.setText(tab[i]);
        }
    }

    @Override
    protected String coColler() {
        return "<typR>" + "#" + tField1.getText();
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return tField1.getText() + " = Record";
    }
}
