/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.contPrinc;
import static editeuralgoesi.FXMLDocumentController.undo;
import java.util.NoSuchElementException;
import javafx.event.ActionEvent;

/**
 *
 * @author mohammed_bey
 */
public class BoucleRepeterEntete extends LesDebuts {

    BoiteDeDialogueBloc root = null;

    public BoucleRepeterEntete() {
        super();
        label1.getStyleClass().remove("labDebFinBoucle");
        label1.getStyleClass().add("labBclRep");
        label1.setText("Repeter");
        getChildren().addAll(label1, icMajCorps);
        menuTransBcl.getItems().remove(menuEnBclR);
        icMajCorps.menuMiseAjour.getItems().add(menuTransBcl);
        /**
         * *********************Gestion des evenements du menuIcone de
         * MiseAJour:*********************
         */
        icMajCorps.menuSupprimer.setDisable(false);
        icMajCorps.menuCopier.setDisable(false);
        icMajCorps.menuCouper.setDisable(false);
        icMajCorps.menuColler.setDisable(false);
        //* ***************Couper l'element de la position * courante******************************/
        icMajCorps.menuCopier.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajCorps.getParent());//pour parcourir la liste de contPrinc
            copier(indice);
        });
        //* ***************Couper le bloc de la position * courante*******************************/
        icMajCorps.menuCouper.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajCorps.getParent());//pour parcourir la liste de contPrinc
            couper(indice);
        });
        icMajCorps.menuSupprimer.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajCorps.getParent());
            supprimerEl(indice);
        });
    }

    @Override
    public String toString() {
        String resultat = "";
        resultat += "Repeter";
        return resultat;
    }

    //La methode de suppression du bloc
    private void supprimerBlocEntier(int index) {
        int cpt = 1;//un compteur qui indique si on est arrivé a l'Objet Jusqua de l'Objet Repeter (qu'on veut supprimer)
        while (!(cpt == 0)) {
            //* *************Suppression du bloc tout entier*****************/
            supprimer(index);
            if (contPrinc.getChildren().get(index) instanceof BoucleRepeterEntete) {
                cpt++;
            } else if (contPrinc.getChildren().get(index) instanceof BoucleRepeterJusqua) {
                cpt--;
            }
        }
        supprimer(index);
    }

    /**
     *
     * @param index
     */
    @Override
    protected void supprimerEl(int index) {
//        Information info = new Information();//renvoie le contenu de panelAnchor
//        pile.empiler(info.algoAsauvegarder());
//        undo.setDisable(pile.estVide());
//
//        root = new BoiteDeDialogueBloc();
//        if (root.getResponse().isPresent()) {
//            try {
//                int index1 = index;
//                switch (root.getResponse().get()) {
//                    case BoiteDeDialogueBloc.choice1:
//                        //*******************Supprimer et Garder l'interieur du bloc**********************/
//                        //************ ****************Supprimer et garder l'interieur du bloc***************/
//                        supprimer(index1);
//                        int cpt = 1;
//                        while (!(cpt == 0)) {
//                            if (contPrinc.getChildren().get(index1) instanceof BoucleRepeterEntete) {
//                                cpt++;
//                            } else if (contPrinc.getChildren().get(index1) instanceof BoucleRepeterJusqua) {
//                                cpt--;
//                            }
//                            index1++;
//                        }
//                        supprimer(index1 - 1);
//                        break;
//                    case BoiteDeDialogueBloc.choice2:
//                        //****************Suppression du bloc tout entier*******************/
//                        supprimerBlocEntier(index);
//                        break;
//                    default:
//                        throw new AssertionError();
//                }
//            } catch (NoSuchElementException nse) {
//            }
//        }
    }

    private void supprimer(int index) {
        contPrinc.getChildren().remove(index);
        int j = contPrinc.getChildren().size();
        for (int i = index; i < j; i++) {
            contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i).getLayoutY() - 21);
        }
    }

    //LA methode de copier
    @Override
    protected void copier(int index) {
        listeCoColler.clear();
        int cpt = 1;//un compteur qui indique si on est arrivé a l'Objet Jusqua de l'Objet Repeter (qu'on veut supprimer)
        listeCoColler.add(((Corps) contPrinc.getChildren().get(index)).coColler());
        index++;
        while (!(cpt == 0)) {
            listeCoColler.add(((Corps) contPrinc.getChildren().get(index)).coColler());
            if (contPrinc.getChildren().get(index) instanceof BoucleRepeterEntete) {
                cpt++;
            } else if (contPrinc.getChildren().get(index) instanceof BoucleRepeterJusqua) {
                cpt--;
            }
            index++;
        }
    }

    //La methode de couper
    @Override
    protected void couper(int index) {
        Information info = new Information();//renvoie le contenu du conteneur principal
        pile.empiler(info.algoAsauvegarder());
        undo.setDisable(pile.estVide());

        listeCoColler.clear();//vider la liste
        int cpt = 1;//un compteur qui indique si on est arrivé a l'Objet Jusqua de l'Objet Repeter (qu'on veut supprimer)
        while (!(cpt == 0)) {
            listeCoColler.add(((Corps) contPrinc.getChildren().get(index)).coColler());
            supprimer(index);
            if (contPrinc.getChildren().get(index) instanceof BoucleRepeterEntete) {
                cpt++;
            } else if (contPrinc.getChildren().get(index) instanceof BoucleRepeterJusqua) {
                cpt--;
            }
        }
        listeCoColler.add(((Corps) contPrinc.getChildren().get(index)).coColler());
        supprimer(index);
    }

    //La methode de transformation d'une boucle à une autre
    @Override
    protected void transBcl(Corps el1, Corps el2, Corps el3, int index) {
        int cpt = 1;//un compteur qui indique si on est arrivé a l'Objet Jusqua de l'Objet Repeter (qu'on veut supprimer)        
        supprimer(index);//supprimer RepeterEntete
        ajouterEl(el1, index);
        index++;
        ajouterEl(el2, index);
        while (!(cpt == 0)) {
            index++;
            if (contPrinc.getChildren().get(index) instanceof BoucleRepeterEntete) {
                cpt++;
            } else if (contPrinc.getChildren().get(index) instanceof BoucleRepeterJusqua) {
                cpt--;
            }
            contPrinc.getChildren().get(index).setLayoutX(contPrinc.getChildren().get(index).getLayoutX() + 21);
        }
        supprimer(index);
        ajouterEl(el3, index);
    }

    @Override
    protected String coColler() {
        return "<bcrE>";
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return "Repeat";
    }
}
