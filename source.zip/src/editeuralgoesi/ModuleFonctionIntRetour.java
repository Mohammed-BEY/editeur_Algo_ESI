/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.contPrinc;
import java.util.Map;
import javafx.collections.ObservableList;
import javafx.scene.control.TextField;

/**
 *
 * @author mohammed_bey
 */
//Cette classe désigne le résultat de la fonction
public class ModuleFonctionIntRetour extends Modules {

    public ModuleFonctionIntRetour() {
        tField1.setPromptText("nom_de_la_fonction");
        label1.setText(" <-- ");
        label1.setStyle("-fx-font-weight: bold;"
                + "-fx-text-fill:rgb(91,40,83);");
        tField3.setPromptText("le_résultat_de_la_fonction");
        getChildren().addAll(tField1, label1, tField3);
    }

    @Override
    public String toString() {
        return tField1.getText() + " <- " + tField3.getText();
    }

    @Override
    public void setContenu(String str) {
        String[] tab = str.split("#");
        int i = 1;
        if (i < tab.length) {
            tField1.setText(tab[i]);
            i++;
        }
        if (i < tab.length) {
            tField3.setText(tab[i]);
        }
    }

    //La methode qui permet de recuperer le contenu textuel de l'objet pour le mettre dans la liste de copier-couper/coller
    @Override
    protected String coColler() {
        return "<modR>" + "#" + tField1.getText() + "#" + tField3.getText();
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        String replaceAll = tField3.getText().replaceAll("vrai", "true");
        String replaceAll1 = replaceAll.replaceAll("faux", "false");
        return tField1.getText() + " := " + replaceAll1 + ";";
    }

    //redefinir la methode de telle sorte qu'elle ne fait rien
    @Override
    protected void supprimerEl(int index) {
    }

    //La methode de contrôle sysntaxique
    @Override
    protected String traiter(Object[] listListesDecl) {
        String result = "", tmp = "";
        //Le premier champ
        indice = contPrinc.getChildren().indexOf(this);
        int cpt = -1;
        boolean bool = false;
        while (!bool) {
            if (contPrinc.getChildren().get(indice) instanceof FinModule) {
                cpt--;
            } else if (contPrinc.getChildren().get(indice) instanceof ModuleFonctionIntEntete) {
                cpt++;
                if (cpt == 0) {
                    bool = true;
                }
            }
            indice--;
        }
        String tmpEntete = this.tField1.getText().replaceAll(" ", ""),
                tmpRetour = ((ModuleFonctionIntEntete) contPrinc.getChildren().get(indice + 1)).tField1.getText().replaceAll(" ", "");
        try {//tester si la chaine est un nombre            
            Double.parseDouble(tmpEntete);//c'est un nombre
            result += "Attention ! vous avez écrit un nombre au lieu du nom de la fonction.\n";
            colorerChampSaisie(tField1);
        } catch (NumberFormatException e) {//c'est une chaine de caracteres
            if (!tmpEntete.equals(tmpRetour)) {
                result += "Attention ! le nom de la fonction et le résultat de Retour n'ont pas le même nom.\n";
                colorerChampSaisie(tField1);
            }else{
                enleverCouleurChampSaisie(tField1);
            }
        }

        //Traitement du deuxieme champ
        String deuxiemeChamp = tField3.getText();
        tmp = traiterDeuxiemeChamp(deuxiemeChamp, listListesDecl);
        if (tmp.equals("")) {
            enleverCouleurChampSaisie(tField3);
        } else {
            colorerChampSaisie(tField3);
        }
        result += tmp;

        indice = result.lastIndexOf("\n");
        try {
            result = result.substring(0, indice);
        } catch (StringIndexOutOfBoundsException ex) {
        }
        return result;
    }

    //méthode quiq permet de traiter le 2 champ
    private String traiterDeuxiemeChamp(String str, Object[] listListesDecl) {
        String resultat = "";
        String tabSpace[] = str.split(" ");
        for (String string2 : tabSpace) {
            if (!string2.equals("ET") && !string2.equals("eT") && !string2.equals("Et") && !string2.equals("et")
                    && !string2.equals("OU") && !string2.equals("oU") && !string2.equals("Ou") && !string2.equals("ou")
                    && !string2.equals("DIV") && !string2.equals("div")
                    && !string2.equals("MOD") && !string2.equals("mod")
                    && !string2.equals("\\+") && !string2.equals("-") && !string2.equals("\\*") && !string2.equals("/")
                    && !string2.equals("VRAI") && !string2.equals("vrai")
                    && !string2.equals("FAUX") && !string2.equals("faux")) {//c'est une variable
                String[] tokens = string2.split("['\\(' '\\)' '\\[' '\\]' ',' '+' '\\-' '/' '*']");
                for (String string3 : tokens) {
                    if (!string3.equals("")) {
                        resultat += messVerification(string3, listListesDecl);
                    }
                }
            }
        }
        return resultat;
    }

    //Méthode qui envoie le message d'erreur après avoir vérifié les erreurs
    private String messVerification(String str, Object[] listListesDecl) {
        String result = "", tmpVT = "";
        //Les délimiteurs utilisés:
        // . : pour reconnaître les variables de type structure
        if (str.contains(".")) {
            String[] tabBrack = str.split("['\\.']");
            str = tabBrack[0];
        }
        try {//tester si la chaine est un nombre
            Double.parseDouble(str);//c'est un nombre
        } catch (NumberFormatException e) {//c'est une variable
            String tmp = str.toLowerCase();
            if ((!tabMotsCles.contains(tmp)) && (!((ObservableList) listListesDecl[1]).contains(tmp)) && (!((ObservableList) listListesDecl[2]).contains(tmp))
                    && (!((ObservableList) listListesDecl[3]).contains(tmp)) && !((ObservableList) listListesDecl[0]).contains(tmp)) {
                tmpVT = ((Map<String, String>) listListesDecl[4]).get(tmp);//retourner le type de la variable du premier champ
                if (tmpVT == null) {
                    result += "Attention ! vous n'avez pas désigné un type pour  '" + str + "' dans une action d'effectation.\n";
                }
                result += "Attention ! '" + str + "'  ,utilisée dans une action d'affectation, n'a pas été déclarée.\n";
            }
        }
        return result;
    }

    //Mettre les chmps de saisie en couleur rouge quand il y a une erreur détectée
    protected void colorerChampSaisie(TextField tField) {
        tField.getStyleClass().add("error");
    }

    //Enlever la couleur rouge des champs de saisie
    protected void enleverCouleurChampSaisie(TextField tField) {
        tField.getStyleClass().remove("error");
    }
}
