/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.undo;
import javafx.collections.ObservableList;

/**
 *
 * @author mohammed_bey
 */
public class Lecture extends Corps {

    public Lecture() {
        super();
        label1.setText("Lire ( ");
        label2.setText(" )");
        tField1.setPromptText("f,p1, ..., pn");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        getChildren().addAll(label1, tField1, label2, icMajCorps);
    }

    //La methode de suppression
    @Override
    protected void supprimerEl(int index) {
        Information info = new Information();//renvoie le contenu de panelAnchor
        pile.empiler(info.algoAsauvegarder());
        undo.setDisable(pile.estVide());
        super.supprimerEl(index);
    }

    @Override
    public String toString() {
        return "Lire (" + tField1.getText() + ")";
    }

    @Override
    protected String coColler() {
        return "<lecA>" + "#" + tField1.getText();
    }

    @Override
    protected void setContenu(String str) {
        String[] tab = str.split("#");
        int i = 1;
        if (i < tab.length) {
            tField1.setText(tab[i]);
        }
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return "readln (" + tField1.getText() + ");";
    }

    @Override
    protected String traiter(Object[] listListesDecl) {
        String resultat = "";
        String replaceAll = tField1.getText().replaceAll(" ", "");
        String replaceAll1 = replaceAll.replaceAll("\t", "");
        if (replaceAll1.contains("[") || replaceAll1.contains(".")) {
            String[] tabBrack = replaceAll1.split("['\\[' '\\.']");
            replaceAll1 = tabBrack[0];
        }
        try {
            Double.parseDouble(replaceAll1);
            resultat += "Attention ! vous avez écrit un nombre au lieu d'un nom d'une variable dans une action de lecture.\n";
        } catch (NumberFormatException e) {
            if (!tField1.getText().equals("")) {
                String tab[] = replaceAll1.split(",");
                for (String string : tab) {
                    String tmp = string.toLowerCase();
                    if ((!tabMotsCles.contains(tmp)) && (!((ObservableList) listListesDecl[0]).contains(tmp)) && (!((ObservableList) listListesDecl[3]).contains(tmp))) {
                        resultat += "Attention ! La variable '" + string + "' , utilisée dans une action de lecture, n'a pas été déclarée." + "\n";
                    }
                }
            }
        }
        indice = resultat.lastIndexOf("\n");
        try {
            resultat = resultat.substring(0, indice);
        } catch (StringIndexOutOfBoundsException ex) {
        }
        return resultat;
    }

    //Mettre les chmps de saisie en couleur rouge quand il y a une erreur détectée
    @Override
    protected void colorerChampSaisie() {
        tField1.getStyleClass().add("error");
    }

    //Enlever la couleur rouge des champs de saisie
    @Override
    protected void enleverCouleurChampSaisie() {
        tField1.getStyleClass().remove("error");
    }
}
