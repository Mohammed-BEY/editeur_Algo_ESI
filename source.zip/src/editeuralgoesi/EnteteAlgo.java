/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.contPrinc;
import javafx.event.ActionEvent;
import javafx.event.Event;

/**
 *
 * @author mohammed_bey
 */
public class EnteteAlgo extends Algorithme {

    private final IconeMiseAjourEnteteAlgo icMajEntete;

    public EnteteAlgo() {
        icMajEntete = new IconeMiseAjourEnteteAlgo();
        label1.setText("ALGORITHME ");
        label1.getStyleClass().add("labMotSys");
        tField1.setPromptText("nom_algorithme");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        getChildren().addAll(label1, tField1, icMajEntete);
        //Gérer les evenements sur les menus de MiseÀjour:
        icMajEntete.setVisible(false);
        //le menu de MiseAjour apprait quand la souris entre dans la zone de l'objet
        setOnMouseEntered((Event t) -> {
            icMajEntete.setVisible(true);
        });
        //le menu de MiseAjour disparait quand la souris sort de la zone de l'objet
        setOnMouseExited((Event t) -> {
            icMajEntete.setVisible(false);
        });
        //gérer l'action sur le menu reduire
        icMajEntete.menuReduire.setOnAction((ActionEvent t) -> {
            reduire();
        });
    }

    //La methode qui permet de reduire la partie Environnement et ne garder que la partie Corps
    public void reduire() {
        int j = contPrinc.getChildren().size(),
                index = 1, cptMod = 0/*compte le nombre de modules se trouvant dans l'Algo*/;
        if (icMajEntete.menuReduire.getText().equals("reduire")) {//on veut reduire la partie Environnement
            while (!(contPrinc.getChildren().get(index) instanceof DEBUT)) {
                if (contPrinc.getChildren().get(index) instanceof ModuleFonctionIntEntete || contPrinc.getChildren().get(index) instanceof ModuleProcedureIntEntete) {
                    cptMod++;
                }
                contPrinc.getChildren().get(index).setVisible(false);
                index++;
            }
            for (int i = index; i < j; i++) {
                contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i).getLayoutY() - 21 * (index - 1 + cptMod * 2));
            }
            icMajEntete.menuReduire.setText("agrandir");
        } else {
            while (!(contPrinc.getChildren().get(index) instanceof DEBUT)) {
                if (contPrinc.getChildren().get(index) instanceof ModuleFonctionIntEntete || contPrinc.getChildren().get(index) instanceof ModuleProcedureIntEntete) {
                    cptMod++;
                }
                contPrinc.getChildren().get(index).setVisible(true);
                index++;
            }
            for (int i = index; i < j; i++) {
                contPrinc.getChildren().get(i).setLayoutY(contPrinc.getChildren().get(i).getLayoutY() + 21 * (index - 1 + cptMod * 2));
            }
            icMajEntete.menuReduire.setText("reduire");
        }
    }

    //redefinir la méthode toString de Object
    @Override
    public String toString() {
        String resultat = "";
        resultat += "ALGORITHME" + " " + tField1.getText() + "\n";
        return resultat;
    }

    //affecter le contenu (str) à l'objet
    @Override
    public void setContenu(String str) {
        String[] tab = str.split("#");
        int i = 1;
        if (i < tab.length) {
            tField1.setText(tab[i]);
        }
    }

    //verifier si le nom de l'algorithme existe
    @Override
    protected String traiter(Object[] listListesDecl) {
        String resultat = "";
        String tmp = tField1.getText();
        tmp = tmp.replaceAll("\t", "");
        tmp = tmp.replaceAll(" ", "");
        try {
            Double.parseDouble(tmp);
            resultat += "Attention ! vous avez écrit un nombre au lieu d'un nom pour l'algorithme.";
        } catch (NumberFormatException e) {
            if (tmp.equals("")) {
                resultat += "Attention! Vous n'avez pas designé un nom pour votre algorithme.";
            } else {
                try {//le nom de l'algorithme commence par un chiffre
                    Double.parseDouble(tmp.substring(0, 1));
                    resultat += "Attention ! le nom de l'algorithme commence par un chiffre.";
                } catch (NumberFormatException ex2) {
                    if (tabMotsCles.contains(tmp)) {
                        resultat += "Attention ! le nom de l'algorithme est un mot clé. Veuillez le changer.";
                    }
                }
            }
        }
        return resultat;
    }

    @Override
    protected String coColler() {
        return "<algE>" + "#" + tField1.getText();
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return "program " + tField1.getText() + ";\n";
    }

    //Mettre les chmps de saisie en couleur rouge quand il y a une erreur détectée
    @Override
    protected void colorerChampSaisie() {
        tField1.getStyleClass().add("error");
    }

    //Enlever la couleur rouge des champs de saisie
    @Override
    protected void enleverCouleurChampSaisie() {
        tField1.getStyleClass().remove("error");
    }

}
