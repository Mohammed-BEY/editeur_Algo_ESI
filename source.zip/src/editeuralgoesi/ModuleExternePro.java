/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

/**
 *
 * @author mohammed_bey
 */
public class ModuleExternePro extends ModuleExterne {

    public ModuleExternePro() {
        super();
        label1.setText("Procedures ");
        label1.setStyle("-fx-font-weight: bold;"
                + "-fx-text-fill:rgb(0,128,192);");
        tField1.setPromptText("proced1,proced2,..");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        getChildren().addAll(label1, tField1, icMajEnv);
    }

    @Override
    public String toString() {
        String resultat = "";
        resultat += "Procedures " + tField1.getText();
        return resultat;
    }

    @Override
    public void setContenu(String str) {
        String[] tab = str.split("#");
        int i = 1;
        if (i < tab.length) {
            tField1.setText(tab[i]);
        }
    }

    //La methode qui permet de recuperer le contenu textuel de l'objet pour le mettre dans la liste de copier-couper/coller
    @Override
    protected String coColler() {
        return "<modY>" + "#" + tField1.getText();
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return "Procedures " + tField1.getText() + " ;\n";
    }
}
