/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import java.util.Locale;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.StageStyle;

/**
 *
 * @author mohammed_bey
 */
public class BoiteDeDialogueModule {

    private final Alert response;

    public Alert getResponse() {
        return response;
    }

    public BoiteDeDialogueModule() {
        Locale language = new Locale("fr", "FR");
//        Locale bLocale = new Locale.Builder().setLanguage("fr").setRegion("FR").build();
        Locale.setDefault(language);
//        response = Dialogs.create()
//                .title("Suppression d'un module")
//                .masthead(null)
//                //.graphic(new ImageView(new Image(getClass().getResource("images/info.png").toExternalForm())))
//                .actions(Dialog.ACTION_YES, Dialog.ACTION_NO)
//                .styleClass(Dialog.STYLE_CLASS_NATIVE)
//                .message("Etes-vous sûr de supprimer le module ?")
//                .showConfirm();
        response = new Alert(Alert.AlertType.CONFIRMATION, "", ButtonType.OK, ButtonType.CANCEL);
        response.setTitle("Suppression d'un module");
        response.getDialogPane().setContentText("Etes-vous sûr de supprimer le module ?");
        response.getDialogPane().getStylesheets().add(EditeurAlgoESI.class.getResource("AlertStyleModified.css").toExternalForm());
        response.getDialogPane().getStyleClass().add("AlertStyleModified");
        response.initStyle(StageStyle.UTILITY);
        response.showAndWait();
    }
}
