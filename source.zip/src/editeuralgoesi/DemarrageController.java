/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author mohammed_bey
 */
public class DemarrageController implements Initializable {

    @FXML
    AnchorPane anch;

    private Stage stageSt;//une variable qui sert à detruire la fenêtre quand on veut quitter l'Editeur

    public void setStageSt(Stage stageSt) {
        this.stageSt = stageSt;
    }

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }
}
