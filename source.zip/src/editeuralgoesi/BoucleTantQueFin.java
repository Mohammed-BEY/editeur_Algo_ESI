/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

/**
 *
 * @author mohammed_bey
 */
public class BoucleTantQueFin extends LesFins {

    public BoucleTantQueFin() {
        super();
        label1.setText("FTQ");
        this.getChildren().addAll(label1, icMajCorps);
    }

    @Override
    public String toString() {
        String resultat = "";
        resultat += "FTQ";
        return resultat;
    }

    @Override
    protected String coColler() {
        return "<bctF>";
    }
}
