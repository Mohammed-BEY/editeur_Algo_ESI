/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.contPrinc;
import javafx.event.Event;
import javafx.scene.input.MouseEvent;

/**
 *
 * @author mohammed_bey
 */
//Le mot clé Constante entête
public class ConstanteEntete extends Constante {

    public ConstanteEntete() {
        super();
        label1.setText("Constantes");
        label1.getStyleClass().add("labelCle");
        getChildren().addAll(label1, icMajEnv);
        icMajEnv.menuSupprimer.setDisable(true);
        icMajEnv.setVisible(false);
        //****************Gérer les evenements**********************************************/        
        setOnMouseEntered((Event t) -> {
        });
        setOnMouseClicked((Event t) -> {
            if (((MouseEvent) t).getButton().equals(((MouseEvent) t).getButton().PRIMARY)) {
                if (((MouseEvent) t).getClickCount() == 1) {
                    unClic();
                }
                if (((MouseEvent) t).getClickCount() == 2) {
                    doubleClic();
                }
            }
        });
    }

    //modifier la couleur de label1 et faire apparaitre le menu de mise à jour
    private void unClic() {
        label1.setStyle("-fx-text-fill:rgb(91,40,83);");
        icMajEnv.setVisible(true);
        setOnMouseEntered((Event t1) -> {
            icMajEnv.setVisible(true);
        });
        //le menu de MiseAjour disparait quand la souris sort de la zone de HBox
        setOnMouseExited((Event t1) -> {
            icMajEnv.setVisible(false);
        });
    }

    //modifier la couleur de label1 et rendre le menu de mise à jour invisible
    private void doubleClic() {
        indice = contPrinc.getChildren().indexOf(icMajEnv.getParent());
        if (!constExist(indice)) {
            label1.setStyle("-fx-text-fill:rgb(188,188,188);");
            icMajEnv.setVisible(false);
        }

        setOnMouseEntered((Event t1) -> {
        });
    }

    @Override
    public String toString() {
        String resultat = "";
        if (constExist(contPrinc.getChildren().indexOf(this))) {
            resultat = "Constantes";
        }
        return resultat;
    }

    @Override
    protected String coColler() {
        return "<cteE>";
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        String result = "";
        if (constExist(contPrinc.getChildren().indexOf(this))) {
            result = "const";
        }
        return result;
    }

    //Cette methode indique s'il y a au oins une constante declarée
    private boolean constExist(int i) {
        boolean result = true;
        if (contPrinc.getChildren().get(i + 1) instanceof TypeEntete) {//il n'y aucun type déclaré
            result = false;
        }
        return result;
    }

    //redefinir la methode de telle sorte qu'elle ne fait rien
    @Override
    protected void supprimerEl(int index) {
    }
}
