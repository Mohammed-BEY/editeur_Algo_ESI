/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

/**
 *
 * @author mohammed_bey
 */
public class FinAlgo extends Corps {

    public FinAlgo() {
        label1.setText("FIN.");
        label1.getStyleClass().add("labMotSys");
        getChildren().add(label1);
    }

    @Override
    public String toString() {
        String resultat = "";
        resultat += "\n" + "FIN.";
        return resultat;
    }

    @Override
    protected String coColler() {
        return "<algF>";
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return "End.";
    }

    //redefinir la methode copier de telle sorte qu'elle ne fait rien
    @Override
    protected void copier(int index) {
    }

    //redefinir la methode couper de telle sorte qu'elle ne fait rien
    @Override
    protected void couper(int index) {
    }

    //redefinir la methode coller de telle sorte qu'elle ne fait rien
    @Override
    protected void coller(int index) {
    }

    //redefinir la methode de telle sorte qu'elle ne fait rien
    @Override
    protected void supprimerEl(int index) {
    }
}
