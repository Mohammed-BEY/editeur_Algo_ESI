/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.contPrinc;
import javafx.event.ActionEvent;
import javafx.scene.control.MenuItem;

/**
 *
 * @author mohammed_bey
 */
//La classe constante 
public class Constante extends Environnement {

    public Constante() {
        MenuItem menuAjouterConst = new MenuItem("ajouter une constante");
        //* ********************Gestion des evenements des touches des * menus*********************/
        icMajEnv.menuMAJ.getItems().removeAll(icMajEnv.menuAjouter);
        icMajEnv.menuMAJ.getItems().add(0, menuAjouterConst);
        menuAjouterConst.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            ajouterEl(new ConstanteDeclar(), indice);
        });
        //**************************** **Ajout d'un commentaire*******************************/

        icMajEnv.menuComent.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent()) + 1;
            ajouterEl(new CommentaireEnvConst(), indice);
        });

        //supprimer la constante où la souris se trouve
        icMajEnv.menuSupprimer.setOnAction((ActionEvent t) -> {
            indice = contPrinc.getChildren().indexOf(icMajEnv.getParent());
            supprimerEl(indice);
        });
    }
}
