/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.contPrinc;

/**
 *
 * @author mohammed_bey
 */
//Le mot clé Variable des modules
public class VariableEnteteModule extends Variable {

    public VariableEnteteModule() {
        super();
        label1.setText("Variables");
        label1.setStyle("-fx-font-weight: bold;"
                + "-fx-text-fill:rgb(0,128,192);"
                + "-fx-font-size:12px;");
        getChildren().addAll(label1, icMajEnv);
        icMajEnv.menuAjouter.getItems().remove(icMajEnv.menuITypeEnreg);
        icMajEnv.menuSupprimer.setDisable(true);
        icMajEnv.menuAjouter.setText("ajouter une variable");
        /**
         * ***************Gestion des evenements des touches des menus****
         */
    }

    @Override
    public String toString() {
        String resultat = "";
        if (varExist(contPrinc.getChildren().indexOf(this))) {
            resultat = "Variables";
        }
        return resultat;
    }

    @Override
    protected String coColler() {
        return "<modV>";
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        String result = "";
        if (varExist(contPrinc.getChildren().indexOf(this))) {
            result = "var";
        }
        return result;
    }
}
