/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TitledPane;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.WindowEvent;

/**
 *
 * @author mohammed_bey
 */
public class FXMLDocumentController implements Initializable {

    //le conteneur principal de l'Editeur
    @FXML
    ScrollPane sp;

    @FXML//pour faire les opérations de undo-redo
    Label annuler;
    @FXML//pour faire les opérations de undo-redo
    Label retablir;
    @FXML
    TextArea displayAlgo;
    @FXML
    TextArea displayTrad;
    @FXML
    TextArea displayCtrlSyn;
    @FXML
    Label labNew;
    @FXML
    Label labOpen;
    @FXML
    Label labOpenPascal;
    @FXML
    Label labSave;
    @FXML
    Label labSaveAs;
    @FXML
    Label labCtlSyn;
    @FXML
    TitledPane titlePane;
    @FXML
    Text nomAlgoPas;
    @FXML
    Text nomAlgo;
    @FXML
    MenuItem exemple1;
    @FXML
    MenuItem exemple2;
    @FXML
    MenuItem exemple3;
    private Editeur editeur;
    public static AnchorPane contPrinc = new AnchorPane();//conteneur des objets
    //Une chaine de caracteres qui contient le chemin du fichier à sauvegardr
    static String savePath = "";
    private boolean fichierChoisi = false;//un booleen qui indique si on a cliqué sur le croix de quitter de la boite de sortie
    static Label undo = new Label(), redo = new Label();
    private int indiceParcours = -1;//permet de déplacer entre les elements de l'éditeur
    private String contenuChargé = "";//designe le contenu de l'algorithme chargé
    private Stage stageSt;//une variable qui sert à detruire la fenêtre quand on veut quitter l'Editeur

    //Thread qui permet d'exécuter le progressBar en parallèle qvec d'autres tâches
    Thread thread = null;
    Stage taskUpdateStage;

    public void setStageSt(Stage stageSt) {
        this.stageSt = stageSt;
    }

    //afficher l'algo edité dans l'editeur
    @FXML
    void afficherAlgo() {
        if (!((Algorithme) contPrinc.getChildren().get(0)).tField1.getText().equals("")) {
            nomAlgo.setText("Afficher l'algorithme \"" + ((Algorithme) contPrinc.getChildren().get(0)).tField1.getText() + "\"");
        }
        displayAlgo.setText(editeur.algoEdite());
    }

    //afficher la traduction de l'algo ecrit dans l'editeur
    @FXML
    void traduireAlgoPascal() {
        String ctrlSyntaxique = editeur.controlesSyn();
        if (ctrlSyntaxique.equals("il n'y a aucune erreur détectée." + "\n" + "\nLe traitement est terminé.")) {
            nomAlgoPas.setText("program \"" + ((Algorithme) contPrinc.getChildren().get(0)).tField1.getText() + "\"");
            displayTrad.setText(editeur.algoPascal());
        } else {
            displayTrad.setText("Attention! Veuillez vérifier les erreurs syntaxiques de votre algorithme.");
            displayCtrlSyn.setText(ctrlSyntaxique);
        }
    }

    @FXML
    void ctlSyntaxiques() {
        String ctrlSyntaxique = editeur.controlesSyn();
        displayCtrlSyn.setText(ctrlSyntaxique);
    }

    @FXML
    void sauvegarder() {
        FileChooser chooser = null;
        String algoAffiche = (new Information()).algoAsauvegarder(),//l'algorithme à souvegarder
                algoPascal = editeur.algoPascal();//l'algorithme traduit en Pascal
        if (savePath.equals("")) {
            chooser = new FileChooser();
            File defaultDirectory = new File(".\\algorithmes");//initialiser le répertoire par défaut
            if (!defaultDirectory.exists()) {
                defaultDirectory.mkdir();
            }
            chooser.setInitialDirectory(defaultDirectory);
            chooser.setInitialFileName(".Algo");
            chooser.setTitle("Sauvegarde");
            chooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Fichier Algo", "*.Algo"));
            File fichier = chooser.showSaveDialog(null);
            try {
                String fichierExtension = ".Algo";
                //creer un buffer pour pousser le contenu dans le fichier
                if (fichier != null) {
                    fichierChoisi = true;
                    if (fichier.getPath().endsWith(".Algo")) {
                        String vide = "";
                        fichierExtension = vide;
                    }
                    //Sauvegarder le fichier Algo
                    try (BufferedWriter out = new BufferedWriter(new FileWriter(fichier.getPath() + fichierExtension))) {
                        out.write(algoAffiche);
                    }
                    //Sauvegarder le fichier Pascal
                    String fichierPascal = (fichier.getPath() + fichierExtension).replace(".Algo", ".Pas");
                    try (BufferedWriter outPas = new BufferedWriter(new FileWriter(fichierPascal))) {
                        outPas.write(algoPascal);
                    }
                    savePath = fichier.getPath() + fichierExtension;
                }
            } catch (IOException e) {  //ecrire les exceptions au console output
            }
        } else {
            try {
                fichierChoisi = true;
                try (BufferedWriter out = new BufferedWriter(new FileWriter(savePath))) {
                    out.write(algoAffiche);
                }
                //Sauvegarder le fichier Pascal
                String fichierPascal = savePath.replace(".Algo", ".Pas");
                try (BufferedWriter outPas = new BufferedWriter(new FileWriter(fichierPascal))) {
                    outPas.write(algoPascal);
                }
            } catch (IOException e) {//ecrire les exceptions au console output
                System.out.println(e.getMessage());
            }
        }
    }

    @FXML
    void sauvegarderSous() {
        String algoAffiche = (new Information()).algoAsauvegarder(),//l'algorithme à souvegarder
                algoPascal = editeur.algoPascal();//l'algorithme traduit en Pascal
        FileChooser chooser = new FileChooser();
        File defaultDirectory = new File(".\\algorithmes");//initialiser le répertoire par défaut
        if (!defaultDirectory.exists()) {
            defaultDirectory.mkdir();
        }
        chooser.setInitialDirectory(defaultDirectory);
        chooser.setTitle("Sauvegarde");
        chooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Fichier Algo", "*.Algo"));
        chooser.setInitialFileName(".Algo");
        File fichier = chooser.showSaveDialog(null);
        try {
            String fichierExtension = ".Algo";
            //creer un buffer pour pousser le contenu dans le fichier
            if (fichier != null) {
                if (fichier.getPath().endsWith(".Algo")) {
                    String vide = "";
                    fichierExtension = vide;
                }
                try (BufferedWriter out = new BufferedWriter(new FileWriter(fichier.getPath() + fichierExtension))) {
                    out.write(algoAffiche);
                }
                //Sauvegarder le fichier Pascal
                String fichierPascal = (fichier.getPath() + fichierExtension).replace(".Algo", ".Pas");
                try (BufferedWriter outPas = new BufferedWriter(new FileWriter(fichierPascal))) {
                    outPas.write(algoPascal);
                }
                savePath = fichier.getPath() + fichierExtension;
            }
        } catch (IOException e) {  //ecrire les exceptions au console output
        }
    }

    @FXML
    public void ouvrirAlgo() throws IOException {
        FileChooser chooser = new FileChooser();
        chooser.setInitialDirectory(null);
        chooser.setTitle("Ouverture d'un fichier");
        chooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Fichier Algo", "*.Algo", "*.txt"));
        File fichier = chooser.showOpenDialog(null);

//        runTask();
        //lecture du fichier
        if (fichier != null) {
            PILE pile = new PILE();
            Information info = new Information();//renvoie le contenu du conteneur principal
            pile.empiler(info.algoAsauvegarder());
            undo.setDisable(pile.estVide());
            InputStream ips = null;
            String chaine = "";
            try {
                ips = new FileInputStream(fichier);
                InputStreamReader ipsr = new InputStreamReader(ips);
                try (BufferedReader br = new BufferedReader(ipsr)) {
                    String ligne = "";
                    while ((ligne = br.readLine()) != null) {
                        chaine += ligne + "\n";
                    }
                    try {
                        if ((chaine.contains("<algE>") && chaine.contains("<algD>") && chaine.contains("<algF>"))
                                || (chaine.contains("<modO>") && chaine.contains("<modD>") && chaine.contains("<modF>"))
                                || (chaine.contains("<modP>") && chaine.contains("<modD>") && chaine.contains("<modF>"))) {
                            //fichier sauvegardé de notre application
                            contenuChargé = chaine;
                            editeur.recreation(info.remplirListInfo(chaine));
                        } else {//fichier edité ailleurs                            
                            contenuChargé = info.editeAediteur(chaine);
                            editeur.recreation(info.remplirListInfo(info.editeAediteur(chaine)));
                        }
                    } catch (ArrayIndexOutOfBoundsException e) {
                        System.out.printf(e.getMessage());
                    }
                }

            } catch (IOException e) {
                System.out.println(e.toString());
            } finally {
                if (ips != null) {
                    try {
                        ips.close();
                    } catch (IOException ex) {
                    }
                }
            }
            savePath = fichier.getPath();
        }

//        Thread t = new Thread() {
//            @Override
//            public void run() {
//                for (int i = 0; i < 100000; i++) {
//                    System.out.println("iteration:" + i);
//                }
//            }
//        };
//        t.start();
//        th.start();
//        stopTask();
    }

    //ouvrir l'algo traduit en Pascal avec un editeur de Pascal
    @FXML
    void ouvrirAvecPascal() throws IOException {
        //lance l’application « notepad » de windows pour ouvrir
        //le fichier « TODO.txt » qui se trouve dans le répertoire :
        //C:\Documents and Settings user\My Documents
        String algoPascal = editeur.algoPascal();//l'algorithme traduit en Pascal

        FileChooser chooser = new FileChooser();
        chooser.setTitle("Ouverture avec Pascal");
        File fichierExecutable = chooser.showOpenDialog(null);
        if (fichierExecutable != null) {
            String file = fichierExecutable.getParent() + "\\essai.pas";
            try (BufferedWriter outPas = new BufferedWriter(new FileWriter(file))) {
                outPas.write(algoPascal);
            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
            try {
                Runtime.getRuntime().exec(fichierExecutable.getAbsolutePath() + " " + file);
            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    @FXML
    void nouveauAlgo() {
        PILE pile = new PILE();
        Information info = new Information();//renvoie le contenu du conteneur principal
        pile.empiler(info.algoAsauvegarder());
        undo.setDisable(pile.estVide());
        savePath = "";
        contPrinc.getChildren().clear();
        editeur = new Editeur();
    }

    @FXML
    void nouveauModFon() {//nouveau module fonction
        PILE pile = new PILE();
        Information info = new Information();//renvoie le contenu du conteneur principal
        pile.empiler(info.algoAsauvegarder());
        undo.setDisable(pile.estVide());

        savePath = "";
        contPrinc.getChildren().clear();
        ModuleFonction moduleFon = new ModuleFonction();
    }

    @FXML
    void nouveauModPro() {//nouveau module procedure
        PILE pile = new PILE();
        Information info = new Information();//renvoie le contenu du conteneur principal
        pile.empiler(info.algoAsauvegarder());
        undo.setDisable(pile.estVide());

        savePath = "";
        contPrinc.getChildren().clear();
        ModuleProcedure modulePro = new ModuleProcedure();
    }

    @FXML
    void annuler() throws PileVideErreurException {
        PILE pile = new PILE();//la pile de l'operation undo-redo 
        Information info = new Information();//renvoie le contenu de panelAnchor
        pile.empilerRedo(info.algoAsauvegarder());
        redo.setDisable(pile.estVideRedo());
        try {
            editeur.recreation((new Information()).remplirListInfo(pile.depiler()));
        } catch (PileVideErreurException ex) {
        }
        undo.setDisable(pile.estVide());
    }

    @FXML
    void retablir() throws PileVideErreurException {
        PILE pile = new PILE();//la pile de l'operation undo-redo 
        Information info = new Information();//renvoie le contenu de panelAnchor
        pile.empiler(info.algoAsauvegarder());
        undo.setDisable(pile.estVide());
        try {
            editeur.recreation((new Information()).remplirListInfo(pile.depilerRedo()));
        } catch (PileVideErreurException ex) {
        }
        redo.setDisable(pile.estVideRedo());
    }

    @FXML
    void quitter() {
        if (!(new Information()).algoAsauvegarder().equals(contenuChargé)) {//l'editeur a été changé , donc il faut enregistrer
            BoiteDeDialogueQuitter boiteQuitter = new BoiteDeDialogueQuitter();
            if (boiteQuitter.getResponse().getResult() == ButtonType.YES) {
                sauvegarder();
                if (fichierChoisi && !savePath.equals("")) {
                    stageSt.close();
                    fichierChoisi = false;
                }
            } else if (boiteQuitter.getResponse().getResult() == ButtonType.NO) {
                stageSt.close();
            }
        } else {//on n'a pas modifié dans l'éditeur
            stageSt.close();
        }
    }

    /**
     *
     * @author Cherhabil_ibtihel
     */
    @FXML
    public void siteHidouci() {
        try {
            String url = "http://hidouci.esi.dz/";
            java.awt.Desktop.getDesktop().browse(java.net.URI.create(url));
        } catch (MalformedURLException e) {
            // new URL() failed
            // ...
        } catch (IOException e) {
        }
    }

    @FXML
    public void aide() {
        try {
            String root = System.getProperty("user.dir");
            String pathDuFichierCHM = "\\Fichier d'aide.chm";
            String chmPath = root + pathDuFichierCHM;
            System.out.println("chemin:" + chmPath);
            File chmFile = new File(chmPath);
            if (chmFile.exists()) {
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(chmFile);
                } else {
                    //a faire- mettre un message erreur pour utilisateur
                    System.out.println("Pas de support awt...");
                }
            } else {
                //a faire- mettre un message erreur pour utilisateur
                System.out.println("Fichier chm n'existe pas");
            }
        } catch (IOException ex) {
        }
    }

    /**
     *
     * @author Cherhabil_ibtihel
     */
    @FXML
    public void contacter() {
        try {
            String urlContacterNous = "http://cherhabilsouha.wix.com/monpremieralgo#!contacter-nous/cluw";
            java.awt.Desktop.getDesktop().browse(java.net.URI.create(urlContacterNous));
        } catch (MalformedURLException e) {
            // new URL() failed)-a faire
        } catch (IOException e) {
            // openConnection() failed- a faire
        }
    }

    @FXML
    public void lancerCoursAlsdsPDF() {
        try {
            String root = System.getProperty("user.dir");
            String pathDuFichierPDF = "\\COURS_ALGO_Chapitre_2.pdf";
            String pdfPath = root + pathDuFichierPDF;
            File pdfFile = new File(pdfPath);
            if (pdfFile.exists()) {
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(pdfFile);
                } else {
                    //a faire- mettre un message erreur pour utilisateur
                    System.out.println("Pas de support awt...");
                }
            } else {
                //a faire- mettre un message erreur pour utilisateur
                System.out.println("Fichier pdf n'existe pas");
            }
        } catch (IOException ex) {
        }
    }

    @FXML
    public void lancerLivrePascal() {
        try {
            String root = System.getProperty("user.dir");
            String pathDuFichierPDF = "\\programmation_en_pascal.pdf";
            String pdfPath = root + pathDuFichierPDF;
            File pdfFile = new File(pdfPath);
            if (pdfFile.exists()) {
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(pdfFile);
                } else {
                    //a faire- mettre un message erreur pour utilisateur
                    System.out.println("Pas de support awt...");
                }
            } else {
                //a faire- mettre un message erreur pour utilisateur
                System.out.println("Fichier pdf n'existe pas");
            }
        } catch (IOException ex) {
        }
    }

    @FXML
    void copier() {
        try {
            ((Algorithme) contPrinc.getChildren().get(indiceParcours)).copier(indiceParcours);
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @FXML
    void couper() {
        try {
            ((Algorithme) contPrinc.getChildren().get(indiceParcours)).couper(indiceParcours);
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @FXML
    void coller() {
        try {
            ((Algorithme) contPrinc.getChildren().get(indiceParcours)).coller(indiceParcours + 1);
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @FXML
    void supprimer() {
        try {
            ((Algorithme) contPrinc.getChildren().get(indiceParcours)).supprimerEl(indiceParcours);
        } catch (ArrayIndexOutOfBoundsException e) {
        }
    }

    @FXML
    public void lancermanuel() {
        try {
            String root = System.getProperty("user.dir");
            String pathDuFichierPDF = "\\PRJ5_EQ25_Khelouat_Si-Tayeb_noticeUtilisation_2014.pdf";
            String pdfPath = root + pathDuFichierPDF;
            File pdfFile = new File(pdfPath);
            if (pdfFile.exists()) {
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(pdfFile);
                } else {
                    //a faire- mettre un message erreur pour utilisateur
                    System.out.println("Pas de support awt...");
                }
            } else {
                //a faire- mettre un message erreur pour utilisateur
                System.out.println("Fichier pdf n'existe pas");
            }
        } catch (IOException ex) {
        }
    }

    @FXML
    void aPropos() {
        //charger la fenêtre de demarage
        FXMLLoader fxmlD = new FXMLLoader(getClass().getResource("Demarrage.fxml"));
        Parent rootD = null;
        try {
            rootD = fxmlD.load();
        } catch (IOException ex) {
        }
        Stage stageD = new Stage();
        ((DemarrageController) fxmlD.getController()).setStageSt(stageD);
        stageD.setTitle("MonPremierAlgo");
        Scene sceneD = new Scene(rootD);
        sceneD.getStylesheets().add(EditeurAlgoESI.class.getResource("MiseEnForme.css").toExternalForm());
        sceneD.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode().equals(KeyCode.ESCAPE) || e.getCode().equals(KeyCode.ENTER) || e.getCode().equals(KeyCode.SPACE)) {
                stageD.close();
            }
        });
        stageD.setScene(sceneD);
        stageD.centerOnScreen();
        stageD.setResizable(false);
        stageD.toFront();
        stageD.getIcons().add(new Image(EditeurAlgoESI.class.getResourceAsStream("images/MonPremierALgo.png")));
        stageD.showAndWait();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        editeur = new Editeur();
        sp.setContent(contPrinc);
        contPrinc.getStyleClass().add("anchorpane");
        contenuChargé = (new Information()).algoAsauvegarder();
        //*********************************************************************/
        //parcourir l'edteur par les indices et gérer les raccourcis
        titlePane.setOnKeyPressed((KeyEvent ke) -> {
            handleFocusTraversal(ke);
        });

        annuler.setDisable(true);
        retablir.setDisable(true);
        undo = annuler;
        redo = retablir;
        annuler.setTooltip(new Tooltip("annuler"));
        retablir.setTooltip(new Tooltip("rétablir"));
        labNew.setTooltip(new Tooltip("nouveauAlgo"));
        labOpen.setTooltip(new Tooltip("ouvrirAlgo"));
        labOpenPascal.setTooltip(new Tooltip("ouvrirAvecPascal"));
        labSave.setTooltip(new Tooltip("sauvegarder"));
        labSaveAs.setTooltip(new Tooltip("sauvegarderSous"));
        labCtlSyn.setTooltip(new Tooltip("contrôlesSyntaxiques"));
    }

    private void handleFocusTraversal(final KeyEvent ke) {
        switch (ke.getCode()) {
            case UP:
                ke.consume();
                indiceParcours--;
                if (indiceParcours >= 0) {
                    if (indiceParcours < contPrinc.getChildren().size() - 1) {
                        ((Algorithme) contPrinc.getChildren().get(indiceParcours + 1)).getChildren().get(0).getStyleClass().remove("hbIndice");
                    }
                    ((Algorithme) contPrinc.getChildren().get(indiceParcours)).getChildren().get(0).getStyleClass().add("hbIndice");
                } else {
                    indiceParcours = contPrinc.getChildren().size() - 1;
                    ((Algorithme) contPrinc.getChildren().get(0)).getChildren().get(0).getStyleClass().remove("hbIndice");
                    ((Algorithme) contPrinc.getChildren().get(indiceParcours)).getChildren().get(0).getStyleClass().add("hbIndice");
                }
                break;
            case LEFT:
                ke.consume();
                indiceParcours--;
                if (indiceParcours >= 0) {
                    if (indiceParcours < contPrinc.getChildren().size() - 1) {
                        ((Algorithme) contPrinc.getChildren().get(indiceParcours + 1)).getChildren().get(0).getStyleClass().remove("hbIndice");
                    }
                    ((Algorithme) contPrinc.getChildren().get(indiceParcours)).getChildren().get(0).getStyleClass().add("hbIndice");
                } else {
                    indiceParcours = contPrinc.getChildren().size() - 1;
                    ((Algorithme) contPrinc.getChildren().get(0)).getChildren().get(0).getStyleClass().remove("hbIndice");
                    ((Algorithme) contPrinc.getChildren().get(indiceParcours)).getChildren().get(0).getStyleClass().add("hbIndice");
                }
                break;
            case DOWN:
                ke.consume();
                indiceParcours++;
                if (indiceParcours < contPrinc.getChildren().size()) {
                    if (indiceParcours > 0) {
                        ((Algorithme) contPrinc.getChildren().get(indiceParcours - 1)).getChildren().get(0).getStyleClass().remove("hbIndice");
                    }
                    ((Algorithme) contPrinc.getChildren().get(indiceParcours)).getChildren().get(0).getStyleClass().add("hbIndice");
                } else {
                    indiceParcours = 0;
                    ((Algorithme) contPrinc.getChildren().get(contPrinc.getChildren().size() - 1)).getChildren().get(0).getStyleClass().remove("hbIndice");
                    ((Algorithme) contPrinc.getChildren().get(indiceParcours)).getChildren().get(0).getStyleClass().add("hbIndice");
                }
                break;
            case RIGHT:
                ke.consume();
                indiceParcours++;
                if (indiceParcours < contPrinc.getChildren().size()) {
                    if (indiceParcours > 0) {
                        ((Algorithme) contPrinc.getChildren().get(indiceParcours - 1)).getChildren().get(0).getStyleClass().remove("hbIndice");
                    }
                    ((Algorithme) contPrinc.getChildren().get(indiceParcours)).getChildren().get(0).getStyleClass().add("hbIndice");
                } else {
                    indiceParcours = 0;
                    ((Algorithme) contPrinc.getChildren().get(contPrinc.getChildren().size() - 1)).getChildren().get(0).getStyleClass().remove("hbIndice");
                    ((Algorithme) contPrinc.getChildren().get(indiceParcours)).getChildren().get(0).getStyleClass().add("hbIndice");
                }
                break;
            case CONTROL:
                ctlSyntaxiques();
                break;
            case DELETE:
                try {
                    ((Algorithme) contPrinc.getChildren().get(indiceParcours)).supprimerEl(indiceParcours);
                } catch (ArrayIndexOutOfBoundsException e) {
                }
                if ((indiceParcours >= 0) && (indiceParcours < contPrinc.getChildren().size()) && !((Algorithme) contPrinc.getChildren().get(indiceParcours)).getChildren().get(0).getStyleClass().contains("hbIndice")) {
                    ((Algorithme) contPrinc.getChildren().get(indiceParcours)).getChildren().get(0).getStyleClass().add("hbIndice");
                }
                break;
            default:
        }
        KeyCodeCombination comboS = new KeyCodeCombination(KeyCode.S, KeyCodeCombination.CONTROL_DOWN),
                comboSS = new KeyCodeCombination(KeyCode.S, KeyCodeCombination.SHIFT_DOWN, KeyCodeCombination.CONTROL_DOWN),
                comboO = new KeyCodeCombination(KeyCode.O, KeyCodeCombination.CONTROL_DOWN),
                comboP = new KeyCodeCombination(KeyCode.P, KeyCodeCombination.CONTROL_DOWN),
                comboN = new KeyCodeCombination(KeyCode.N, KeyCodeCombination.CONTROL_DOWN),
                comboZ = new KeyCodeCombination(KeyCode.Z, KeyCodeCombination.CONTROL_DOWN),
                comboY = new KeyCodeCombination(KeyCode.Y, KeyCodeCombination.CONTROL_DOWN),
                comboT = new KeyCodeCombination(KeyCode.T, KeyCodeCombination.CONTROL_DOWN),
                comboC = new KeyCodeCombination(KeyCode.C, KeyCodeCombination.CONTROL_DOWN),
                comboX = new KeyCodeCombination(KeyCode.X, KeyCodeCombination.CONTROL_DOWN),
                comboV = new KeyCodeCombination(KeyCode.V, KeyCodeCombination.CONTROL_DOWN),
                comboAE = new KeyCodeCombination(KeyCode.E, KeyCodeCombination.ALT_DOWN),
                comboAC = new KeyCodeCombination(KeyCode.C, KeyCodeCombination.ALT_DOWN),
                comboA = new KeyCodeCombination(KeyCode.A, KeyCodeCombination.SHIFT_DOWN, KeyCodeCombination.CONTROL_DOWN);
        if (comboA.match(ke)) {//combinaison de 3 touches clavier
            afficherAlgo();
        } else if (comboC.match(ke)) {
            if (indiceParcours > 0 && indiceParcours < contPrinc.getChildren().size()) {
                ((Algorithme) contPrinc.getChildren().get(indiceParcours)).copier(indiceParcours);
            }
        } else if (comboX.match(ke)) {
            ((Algorithme) contPrinc.getChildren().get(indiceParcours)).couper(indiceParcours);
        } else if (comboV.match(ke)) {
            ((Algorithme) contPrinc.getChildren().get(indiceParcours)).coller(indiceParcours + 1);
        } else if (comboAE.match(ke)) {
            ((EnteteAlgo) contPrinc.getChildren().get(0)).reduire();
        } else if (comboAC.match(ke)) {
            int i = 0;
            while (!(contPrinc.getChildren().get(i) instanceof DEBUT)) {
                i++;
            }
            ((DEBUT) contPrinc.getChildren().get(i)).reduire();
        } else if (comboS.match(ke)) {
            sauvegarder();
        } else if (comboSS.match(ke)) {
            sauvegarderSous();
        } else if (comboO.match(ke)) {
            try {
                ouvrirAlgo();
            } catch (IOException ex) {
            }
        } else if (comboP.match(ke)) {
            try {
                ouvrirAvecPascal();
            } catch (IOException ex) {
            }
        } else if (comboN.match(ke)) {
            nouveauAlgo();
        } else if (comboZ.match(ke)) {
            try {
                annuler();
            } catch (PileVideErreurException ex) {
            }
        } else if (comboY.match(ke)) {
            try {
                retablir();
            } catch (PileVideErreurException ex) {
            }
        } else if (comboT.match(ke)) {
            traduireAlgoPascal();
        }
    }

    //démarrer le thread
    private void runTask() {
        final double wndwWidth = 300.0d;
        Label updateLabel = new Label("Running task...");
        updateLabel.setPrefWidth(wndwWidth);
        ProgressBar progress = new ProgressBar();
        progress.setPrefWidth(wndwWidth);

        Task longTask = new Task<Void>() {
            @Override
            protected synchronized Void call() throws Exception {
                System.out.println("je suis le nouveau thread!");
                while (true) {
                    updateMessage("En cours . . . ");
                    Thread.sleep(0);
                }
            }
        };
        progress.progressProperty().bind(longTask.progressProperty());
        updateLabel.textProperty().bind(longTask.messageProperty());
        thread = new Thread(longTask);
        thread.start();

        VBox updatePane = new VBox();
        updatePane.setPadding(new Insets(10));
        updatePane.setSpacing(5.0d);
        updatePane.getChildren().addAll(updateLabel, progress);

        taskUpdateStage = new Stage(StageStyle.UTILITY);
        taskUpdateStage.setScene(new Scene(updatePane));
        taskUpdateStage.show();

        longTask.setOnSucceeded(new EventHandler<WorkerStateEvent>() {
            @Override
            public void handle(WorkerStateEvent t) {
                taskUpdateStage.hide();
            }
        });

        taskUpdateStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent event) {
                taskUpdateStage.close();
            }

        });
    }

    //arrêter le thread
    private void stopTask() {
        thread.stop();
        taskUpdateStage.close();
    }
}
