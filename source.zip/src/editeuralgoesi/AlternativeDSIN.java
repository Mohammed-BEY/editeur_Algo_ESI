/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

/**
 *
 * @author mohammed_bey
 */
public class AlternativeDSIN extends LesDebuts {

    public AlternativeDSIN() {
        super();
        label1.setText("DSIN");
        label1.getStyleClass().add("labBloc");
        getChildren().addAll(label1, icMajCorps);
    }

    @Override
    public String toString() {
        String resultat = "";
        resultat += "DSIN";
        return resultat;
    }

    @Override
    protected String coColler() {
        return "<altN>";
    }
}
