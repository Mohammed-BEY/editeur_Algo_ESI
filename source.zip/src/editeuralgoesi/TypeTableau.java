/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import javafx.collections.FXCollections;

/**
 *
 * @author mohammed_bey
 */
public class TypeTableau extends TYPE {

    public TypeTableau() {//0:insertions à l'entete , 1:insertion au milieu        
        super();
        tField1.setPromptText("nom_du_tableau");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        label1.setText("= Tableau [");
        label2.setText("] de ");
        label1.setStyle("-fx-text-fill:rgb(30,21,134);");
        label2.setStyle("-fx-text-fill:rgb(30,21,134);");
        /**
         * *********Les indices************
         */
        typesIndices.setId("typeIndicesTabDeuxDim");
        typesIndices.setItems(typesIndicesList);
        /**
         * ********Les elements ***********
         */
        typesElements.setId("typeElementsTabUneDim");
        typesElements.setItems(FXCollections.observableArrayList(typesElementsList.subList(0, 4)));
        getChildren().addAll(tField1, label1, typesIndices, label2, typesElements, icMajEnv);
        icMajEnv.menuAjouter.getItems().removeAll(icMajEnv.menuSimple, icMajEnv.menuChaine, icMajEnv.menuTableau);
    }

    @Override
    public String toString() {
        String resultat = "";
        resultat += tField1.getText() + " = TABLEAU [" + typesIndices.getEditor().getText()
                + "] de  " + typesElements.getEditor().getText();
        return resultat;
    }

    @Override
    public void setContenu(String str) {
        String[] tab = str.split("#");
        int i = 1;
        if (i < tab.length) {
            tField1.setText(tab[i]);
            i++;
        }
        if (i < tab.length) {
            typesIndices.setValue(tab[i]);
            i++;
        }
        if (i < tab.length) {
            typesElements.setValue(tab[i]);
        }
    }

    @Override
    protected String coColler() {
        return "<typD>" + "#" + tField1.getText() + "#" + typesIndices.getEditor().getText() + "#" + typesElements.getEditor().getText();
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return tField1.getText() + " = array[" + typePascal(typesIndices.getEditor().getText()) + "] of " + typePascal(typesElements.getEditor().getText()) + " ;";
    }
}
