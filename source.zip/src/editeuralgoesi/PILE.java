/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 *
 * @author mohammed_bey
 */
//L'objet Pile qui contient l'état précédent de l'editeur
public class PILE {

    static Deque<String> contenu = new ArrayDeque<>();
    static Deque<String> contenuRedo = new ArrayDeque<>();

    public String getContenu() {
        String result = "";
        result = contenu.stream().map((string) -> string).reduce(result, String::concat);
        return result;
    }

    public void empiler(String x) {
        contenu.addFirst(x);
    }

    public void empilerRedo(String x) {
        contenuRedo.addFirst(x);
    }

    public String depiler() throws PileVideErreurException {
        if (!estVide()) {
            return contenu.removeFirst();
        } else {
            throw new PileVideErreurException();
        }
    }

    public String depilerRedo() throws PileVideErreurException {
        if (!estVideRedo()) {
            return contenuRedo.removeFirst();
        } else {
            throw new PileVideErreurException();
        }
    }

    public boolean estVide() {
        return contenu.isEmpty();
    }

    public boolean estVideRedo() {
        return contenuRedo.isEmpty();
    }
}
