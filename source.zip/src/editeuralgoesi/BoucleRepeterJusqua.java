/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

/**
 *
 * @author mohammed_bey
 */
public class BoucleRepeterJusqua extends LesFins {

    public BoucleRepeterJusqua() {
        super();
        label1.getStyleClass().remove("labDebFinBoucle");
        label1.getStyleClass().add("labBclRep");
        label1.setText("Jusqu'à ");
        tField1.setPromptText("condition");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        getChildren().addAll(label1, tField1, icMajCorps);
    }

    @Override
    public String toString() {
        return "Jusqu'à  " + tField1.getText();
    }

    @Override
    protected String coColler() {
        return "<bcrJ>" + "#" + tField1.getText();
    }

    @Override
    public void setContenu(String str) {
        String[] tab = str.split("#");
        int i = 1;
        if (i < tab.length) {
            tField1.setText(tab[i]);
        }
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        String result = tField1.getText();
        result = result.replaceAll(" ET ", " and ");
        result = result.replaceAll(" OU ", " or ");
        result = result.replaceAll("==", " = ");
        result = result.replaceAll("vrai", "true");
        result = result.replaceAll("VRAI", "true");
        result = result.replaceAll("faux", "false");
        result = result.replaceAll("FAUX", "false");
        return "until " + result;
    }

    //traiter la saisie des utilisateurs
    @Override
    protected String traiter(Object[] listListesDecl) {
        String result = "";
        String string = tField1.getText();
        String tabEgal[] = string.split("['==' '>' '<' '>=' '<=' '!=']");
        for (String string1 : tabEgal) {
            String tabSpace[] = string1.split(" ");
            for (String string2 : tabSpace) {
                if (!string2.equals("ET") && !string2.equals("eT") && !string2.equals("Et") && !string2.equals("et")
                        && !string2.equals("OU") && !string2.equals("oU") && !string2.equals("Ou") && !string2.equals("ou")
                        && !string2.equals("DIV") && !string2.equals("div")
                        && !string2.equals("MOD") && !string2.equals("mod")
                        && !string2.equals("\\+") && !string2.equals("-") && !string2.equals("\\*") && !string2.equals("/")
                        && !string2.equals("VRAI") && !string2.equals("vrai")
                        && !string2.equals("FAUX") && !string2.equals("faux")) {//c'est une variable
                    String[] tokens = string2.split("['\\(' '\\)' '\\[' '\\]' ',' '+' '\\-' '/' '*']");
                    for (String string3 : tokens) {
                        if (!string3.equals("")) {
                            result += messVerification(string3, listListesDecl);
                        }
                    }
                }
            }
        }
        indice = result.lastIndexOf("\n");
        try {
            result = result.substring(0, indice);
        } catch (StringIndexOutOfBoundsException ex) {
        }
        return result;
    }

    @Override
    protected String designation() {
        return "une boucle 'Répéter'";
    }

    //Mettre les chmps de saisie en couleur rouge quand il y a une erreur détectée
    @Override
    protected void colorerChampSaisie() {
        tField1.getStyleClass().add("error");
    }

    //Enlever la couleur rouge des champs de saisie
    @Override
    protected void enleverCouleurChampSaisie() {
        tField1.getStyleClass().remove("error");
    }
}
