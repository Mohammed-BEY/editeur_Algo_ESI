/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

/**
 *
 * @author mohammed_bey
 */
//La classe commentaire de la partie environnement (Type)
public class CommentaireEnvType extends TYPE {

    public CommentaireEnvType(char c) {
        label1.setText("/*");        
        label2.setText("*/");        
        tField2.setPromptText("insérer un commentaire");
        tField2.setPrefWidth(longChar(tField2.getPromptText()));
        label1.getStyleClass().add("labComent");
        label2.getStyleClass().add("labComent");
        tField2.getStyleClass().add("labComent");
        switch (c) {
            case 'e':
                icMajEnv.menuAjouter.getItems().removeAll(icMajEnv.menuSimple, icMajEnv.menuTableau, icMajEnv.menuChaine);
                break;
            case 'i':
                icMajEnv.menuAjouter.setText("ajouter un champ");
                icMajEnv.menuAjouter.getItems().removeAll(icMajEnv.menuITypeChaineDeCar, icMajEnv.menuITypeEnumere,
                        icMajEnv.menuITypeIntervalle, icMajEnv.menuTab, icMajEnv.menuITypeEnsemble);
                icMajEnv.menuSimple.setText("variable simple");
                icMajEnv.menuChaine.setText("variable chaine");
                icMajEnv.menuTableau.setText("variable tableau");
                break;
            default:
                throw new AssertionError();
        }
        getChildren().addAll(label1, tField2, label2, icMajEnv);
    }

    /**
     *
     * @param str
     */
    @Override
    protected void setContenu(String str) {
        String[] tab = str.split("#");
        int i = 1;
        if (i < tab.length) {
            tField2.setText(tab[i]);
        }
    }

    @Override
    public String toString() {
        return "/*" + tField2.getText() + "*/";
    }

    @Override
    protected String coColler() {
        return "<comT>" + "#" + tField2.getText();
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return "(*" + tField2.getText() + "*)";
    }
}
