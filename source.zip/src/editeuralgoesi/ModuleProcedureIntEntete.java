/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

/**
 *
 * @author mohammed_bey
 */
public class ModuleProcedureIntEntete extends ModuleInterne {

    public ModuleProcedureIntEntete() {
        super();
        label1.setText("Procedure ");
        label1.setStyle("-fx-font-weight: bold;"
                + "-fx-text-fill:rgb(0,128,192);");
        label2.setText(" ( ");
        label3.setText(" ) ");
        tField1.setPromptText("nom_ de_ la_ Procédure");
        tField2.setPromptText("liste_paramètres_formels");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        tField2.setPrefWidth(longChar(tField2.getPromptText()));
        getChildren().addAll(label1, tField1, label2, tField2, label3, icMajEnv);
        /**
         * ***************Desactiver les oprions inutiles du menu de mise à
         * jour**********************
         */
        icMajEnv.menuMAJ.getItems().remove(icMajEnv.menuAjouter);
    }

    @Override
    public String toString() {
        String resultat = "";
        resultat += "Procedure " + tField1.getText() + " ( " + tField2.getText() + " )";
        return resultat;
    }

    @Override
    public void setContenu(String str) {
        String[] tab = str.split("#");
        int i = 1;
        if (i < tab.length) {
            tField1.setText(tab[i]);
            i++;
        }
        if (i < tab.length) {
            tField2.setText(tab[i]);
        }
    }

    //La methode qui permet de recuperer le contenu textuel de l'objet pour le mettre dans la liste de copier-couper/coller
    @Override
    protected String coColler() {
        return "<modP>" + "#" + tField1.getText() + "#" + tField2.getText();
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        String replaceAll = tField2.getText().replaceAll("entier", "integer");
        String replaceAll1 = replaceAll.replaceAll("reel", "real");
        String replaceAll2 = replaceAll1.replaceAll("caractere", "char");
        String replaceAll3 = replaceAll2.replaceAll("booleen", "boolean");
        return "Procedure " + tField1.getText() + "(" + replaceAll3 + ") ; ";
    }
}
