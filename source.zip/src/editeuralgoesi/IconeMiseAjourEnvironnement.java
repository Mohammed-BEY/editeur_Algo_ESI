/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuBuilder;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 *
 * @author mohammed_bey
 */
public class IconeMiseAjourEnvironnement extends MenuBar {

    public MenuItem menuITypeEnumere, menuITypeIntervalle, menuITypeTableau,
            menuITypeChaineDeCar, menuITypeEnreg, menuITypeEnsemble,
            menuSupprimer, menuConst, menuComent,
            menuSimple, menuTableau, menuChaine, menuPtr, menuITypeTableau2, menuTab,
            menuFonction, menuProcedure, menuFonInterne, menuFonExterne, menuProInterne, menuProExterne;
    public Menu menuAjouter, menuMAJ;

    public IconeMiseAjourEnvironnement() {
        menuITypeEnumere = new MenuItem("enumere");
        menuITypeIntervalle = new MenuItem("intervalle");
        menuITypeChaineDeCar = new MenuItem("chaine de caracteres");
        menuITypeEnreg = new MenuItem("enregistrement");
        menuITypeEnsemble = new MenuItem("ensemble");
        menuITypeTableau = new MenuItem("tableauUneDim");
        menuITypeTableau2 = new MenuItem("tableauDeuxDim");
        menuTab = MenuBuilder.create().text("tableau").items(menuITypeTableau, menuITypeTableau2).build();

        menuSimple = new MenuItem("simple");
        menuTableau = new MenuItem("tableau");
        menuChaine = new MenuItem("chaine");
        menuPtr = new MenuItem("pointeur");

        menuFonInterne = new MenuItem("interne");
        menuFonExterne = new MenuItem("externe");
        menuProInterne = new MenuItem("interne");
        menuProExterne = new MenuItem("externe");

        menuFonction = MenuBuilder.create().text("fonction").items(menuFonInterne, menuFonExterne).build();
        menuProcedure = MenuBuilder.create().text("procedure").items(menuProInterne, menuProExterne).build();

        menuConst = new MenuItem("constante");
        menuSupprimer = new MenuItem("supprimer");

        menuComent = new MenuItem("ajouter un commentaire");

        menuAjouter = MenuBuilder.create().text("ajouter")
                .items(menuConst, menuSimple, menuTableau, menuChaine, menuPtr, menuFonction, menuProcedure, menuITypeEnumere, menuITypeIntervalle, menuITypeChaineDeCar, menuTab, menuITypeEnreg, menuITypeEnsemble)
                .build();
        Image image = new Image(EditeurAlgoESI.class.getResourceAsStream("images/add(7).png"));
        ImageView picture = new ImageView(image);
        picture.setFitHeight(15);
        picture.setFitWidth(15);
        menuMAJ = MenuBuilder.create()
                .graphic(picture)
                .items(menuAjouter, menuSupprimer, menuComent).build();
        this.getMenus().addAll(menuMAJ);
        menuMAJ.setStyle("-fx-background-color:white;");
        this.getStyleClass().add("icMAJ");
    }
}
