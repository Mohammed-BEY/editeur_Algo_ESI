/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

/**
 *
 * @author mohammed_bey
 */
public class ModuleFonctionIntEntete extends ModuleInterne {

    public ModuleFonctionIntEntete() {
        super();
        label1.setText("Fonction ");
        label1.setStyle("-fx-font-weight: bold;"
                + "-fx-text-fill:rgb(0,128,192);");
        label2.setText(" ( ");
        label3.setText(" ) : ");
        tField1.setPromptText("nom_de_la_fonction");
        tField2.setPromptText("les_paramètres_formels");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        tField2.setPrefWidth(longChar(tField2.getPromptText()));
        /**
         * ***************Desactiver les options inutiles du menu de mise à
         * jour**********************
         */
        icMajEnv.menuMAJ.getItems().remove(icMajEnv.menuAjouter);
        /**
         * ********Type du resultat de la fonction ***********
         */
        typesElements.setId("typesElements");
        typesElements.setPromptText("type_resultat");
        typesElements.setItems(typesElementsList);
        typesElements.setEditable(true);
        typesElements.setMinWidth(80);

        this.getChildren().addAll(label1, tField1, label2, tField2, label3, typesElements, icMajEnv);
    }

    @Override
    public String toString() {
        String resultat = "";
        resultat += "Fonction " + tField1.getText() + " (" + tField2.getText()
                + " ) : " + typesElements.getEditor().getText();
        return resultat;
    }

    @Override
    public void setContenu(String str) {
        String[] tab = str.split("#");
        int i = 1;
        if (i < tab.length) {
            tField1.setText(tab[i]);
            i++;
        }
        if (i < tab.length) {
            tField2.setText(tab[i]);
            i++;
        }
        if (i < tab.length) {
            typesElements.setValue(tab[i]);
        }
    }

    //La methode qui permet de recuperer le contenu textuel de l'objet pour le mettre dans la liste de copier-couper/coller
    @Override
    protected String coColler() {
        return "<modO>" + "#" + tField1.getText() + "#" + tField2.getText() + "#" + typesElements.getEditor().getText();
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        String replaceAll = tField2.getText().replaceAll("entier", "integer");
        String replaceAll1 = replaceAll.replaceAll("reel", "real");
        String replaceAll2 = replaceAll1.replaceAll("caractere", "char");
        String replaceAll3 = replaceAll2.replaceAll("booleen", "boolean");
        return "Function " + tField1.getText() + "(" + replaceAll3 + ") : " + typePascal(typesElements.getEditor().getText()) + " ;";
    }
}
