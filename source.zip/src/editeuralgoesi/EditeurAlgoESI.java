/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import com.sun.javafx.application.LauncherImpl;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 *
 * @author mohammed_bey
 */
public class EditeurAlgoESI extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader fxml = new FXMLLoader(getClass().getResource("FXMLDocument.fxml"));
        Parent root = fxml.load();
        ((FXMLDocumentController) fxml.getController()).setStageSt(stage);
        stage.setTitle("MonPremierAlgo");
        Scene scene = new Scene(root);
        scene.getStylesheets().add(EditeurAlgoESI.class.getResource("MiseEnForme.css").toExternalForm());
        stage.setScene(scene);
        stage.show();
        stage.getIcons().add(new Image(EditeurAlgoESI.class.getResourceAsStream("images/MonPremierALgo.png")));
        stage.setIconified(false);
        //Gérer l'evenement sur le croix de quitter
        stage.setOnCloseRequest((WindowEvent event) -> {
            event.consume();//empecher de fermer la fenetre
            ((FXMLDocumentController) fxml.getController()).quitter();
        });
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        launch(args);
        LauncherImpl.launchApplication(EditeurAlgoESI.class, MyPreloader.class, args);
    }

}
