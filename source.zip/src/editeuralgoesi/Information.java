/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.contPrinc;
import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author mohammed_bey
 */
public class Information {

    ArrayList<String> listInfo = new ArrayList();

    public Information() {
    }

    public ArrayList remplirListInfo(String str) {
        String[] tab = str.split("\n");
        listInfo.addAll(Arrays.asList(tab));//remplir la liste par le contenu à sauvegarder
        return listInfo;
    }

    //La methode qui retourne le contenu à sauvegarder
    public String algoAsauvegarder() {
        String result = "";
        int j = contPrinc.getChildren().size();
        for (int i = 0; i < j; i++) {
            result += ((Algorithme) contPrinc.getChildren().get(i)).coColler() + "\n";
        }
        return result;
    }

    //transformer un algorithme edité dans un autre editeur sous forme de balises
    public String editeAediteur(String str) {
        String resultat = "", ligne = "", coEx = ""//indique s'il y a des constantes
                , tyEx = "";//indique s'il y a des types
        boolean fin = false;
        int i = 0,//indice de parcours du tableau des lignes
                begin = 0, begin1 = 0, begin2 = 0, end = 0,
                nbreFon = -1,//compter le nombre de modules (fonction) qu'on a restauré
                nbreMod = -1;//compter le nombre de modules qu'on a restauré
        String tabLignes[] = str.split("\n");//tableau qui contient les lignes de l'algorithme à editer
        while (!fin) {
            tabLignes[i] = tabLignes[i].replaceAll("\t", "");//enlever le tabulations
            ligne = tabLignes[i].toLowerCase();
            if (ligne.contains("algorithme")) {
                String tab[] = tabLignes[i].split(" ");
                if (tab.length > 1) {//il y a un nom pour le programe
                    resultat += "<algE>" + "#" + tab[1] + "\n";
                } else {
                    resultat += "<algE>" + "#" + "" + "\n";
                }
                i++;
            } else if (ligne.contains("constante")) {//Les constantes
                resultat += "<cteE>" + "\n";
                i++;
                ligne = tabLignes[i].toLowerCase();
                while (!ligne.contains("type") && !ligne.contains("variables") && !ligne.contains("debut")
                        && !ligne.contains("module") && !ligne.contains("fonction") && !ligne.contains("procedure")) {
                    tabLignes[i] = tabLignes[i].replaceAll(" ", "");//enlever les blancs da la ligne
                    if (ligne.startsWith("/")) {//commentaire dans la partie Constante
                        coEx = "coEx";
                        begin = ligne.indexOf("/") + 2;
                        end = ligne.lastIndexOf("/");
                        resultat += "<comO>" + "#" + ligne.substring(begin, end - 1) + "\n";
                    } else if (tabLignes[i].contains("=")) {//c'est une constante                        
                        coEx = "coEx";
                        String tabParcours[] = tabLignes[i].split("=");
                        resultat += "<cteD>" + "#" + tabParcours[0] + "#" + tabParcours[1] + "\n";
                    }
                    i++;
                    ligne = tabLignes[i].toLowerCase();
                }
            } else if (ligne.contains("type")) {//Les types
                resultat += "<typE>" + "\n";
                i++;
                ligne = tabLignes[i].toLowerCase();
                while (!ligne.contains("variables") && !ligne.contains("module") && !ligne.contains("debut")
                        && !ligne.contains("fonction") && !ligne.contains("procedure")) {
                    tabLignes[i] = tabLignes[i].replaceAll(" ", "");//enlever les blancs da la chaine
                    ligne = tabLignes[i].toLowerCase();
                    if (ligne.startsWith("/")) {//commentaire dans la partie Types
                        tyEx = "tyEx";
                        begin = ligne.indexOf("/") + 2;
                        end = ligne.lastIndexOf("/");
                        resultat += "<comT>" + "#" + ligne.substring(begin, end - 1) + "\n";
                    } else if (ligne.contains("(")) {//Type Enumere
                        tyEx = "tyEx";
                        String tabParcours[] = tabLignes[i].split("=");
                        begin = tabParcours[1].indexOf("(") + 1;
                        end = tabParcours[1].indexOf(")");
                        resultat += "<typN>" + "#" + tabParcours[0] + "#" + tabParcours[1].substring(begin, end) + "\n";
                        i++;
                        ligne = tabLignes[i].toLowerCase();
                    } else if (ligne.contains("..") && !ligne.contains("tableau")) {//Type Intervalle
                        tyEx = "tyEx";
                        tabLignes[i] = tabLignes[i].replaceAll(" ", "");//enlever les blancs
                        String tabString1[] = tabLignes[i].split("=");
                        end = tabString1[1].indexOf("..");
                        resultat += "<typI>" + "#" + tabString1[0] + "#" + tabString1[1].substring(0, end) + "#" + tabString1[1].substring(end + 2, tabString1[1].length()) + "\n";
                        i++;
                        ligne = tabLignes[i].toLowerCase();
                    } else if (ligne.contains("chaine") && ligne.contains("=")) {//Type Chaine de Caracteres
                        tyEx = "tyEx";
                        String tabParcours[] = tabLignes[i].split("=");
                        begin = tabParcours[1].indexOf("[") + 1;
                        end = tabParcours[1].indexOf("]");
                        resultat += "<typC>" + "#" + tabParcours[0] + "#" + tabParcours[1].substring(begin, end) + "\n";
                        i++;
                        ligne = tabLignes[i].toLowerCase();
                    } else if (ligne.contains("tableau") && ligne.contains("=")) {//Type tableau 1dim
                        tyEx = "tyEx";
                        String tabParcours[] = tabLignes[i].split("=");
                        tabParcours[1] = tabParcours[1].replaceAll(" ", "");//supprimer l'espace
                        begin1 = tabParcours[1].indexOf("[") + 1;
                        end = tabParcours[1].indexOf("]");
                        tabParcours[1] = tabParcours[1].toLowerCase();
                        resultat += "<typD>" + "#" + tabParcours[0] + "#" + tabParcours[1].substring(begin1, end) + "#"
                                + tabParcours[1].substring(end + 3, tabParcours[1].length()) + "\n";
                        i++;
                        ligne = tabLignes[i].toLowerCase();
                    } else if (ligne.contains("tableau") && ligne.contains("=") && ligne.contains(",")) {//Type tableau 2dim
                        tabLignes[i] = tabLignes[i].replaceAll("\t", "");
                        tyEx = "tyEx";
                        String tabParcours[] = tabLignes[i].split("=");
                        tabParcours[1] = tabParcours[1].replaceAll(" ", "");//supprimer les blancs
                        begin1 = tabParcours[1].indexOf("[") + 1;
                        end = tabParcours[1].indexOf("]");
                        tabParcours[1] = tabParcours[1].toLowerCase();
                        resultat += "<typQ>" + "#" + tabParcours[0] + "#" + tabParcours[1].substring(begin1, end) + "#"
                                + tabParcours[1].substring(end + 3, tabParcours[1].length()) + "\n";
                        i++;
                        ligne = tabLignes[i].toLowerCase();
                    } else if (ligne.contains("enregistrement")) {//Type Enregistrement Entete  
                        tyEx = "tyEx";
                        String tabString[] = tabLignes[i].split("=");
                        resultat += "<typR>" + "#" + tabString[0] + "\n";
                        i++;
                        ligne = tabLignes[i].toLowerCase();
                    } else if (ligne.contains("tableau")) {//Variable Tableau dans l'enregistrement
                        begin = ligne.indexOf(":");
                        begin1 = ligne.indexOf("[") + 1;
                        end = ligne.indexOf("]");
                        resultat += "<varT>" + "#" + tabLignes[i].substring(0, begin) + "#" + tabLignes[i].substring(begin1, end)
                                + "#" + tabLignes[i].substring(end + 3, tabLignes[i].length()) + "\n";
                        i++;
                        ligne = tabLignes[i].toLowerCase();
                    } else if (ligne.contains("chaine")) {//Variable Chaine de Caracteres dans l'enregistrement
                        String tabParcours[] = tabLignes[i].split(":");
                        begin = tabParcours[1].indexOf("[") + 1;
                        end = tabParcours[1].indexOf("]");
                        resultat += "<varC>" + "#" + tabParcours[0] + "#" + tabParcours[1].substring(begin, end) + "\n";
                        i++;
                        ligne = tabLignes[i].toLowerCase();
                    } else if (ligne.contains(":")) {//Variable Simple
                        String tabParcours[] = tabLignes[i].split(":");
                        resultat += "<varS>" + "#" + tabParcours[0] + "#" + tabParcours[1] + "\n";
                        i++;
                        ligne = tabLignes[i].toLowerCase();
                    } else if (ligne.contains("fin")) {
                        resultat += "<typF>" + "\n";
                        i++;
                        ligne = tabLignes[i].toLowerCase();
                    } else if (ligne.contains("ensemble")) {//Type Ensemble
                        tyEx = "tyEx";
                        String tabParcours[] = ligne.split("=");
                        begin = ligne.indexOf("ensemblede") + 10;
                        resultat += "<typS>" + "#" + tabParcours[0] + "#" + tabLignes[i].substring(begin, tabLignes[i].length()) + "\n";
                        i++;
                        ligne = tabLignes[i].toLowerCase();
                    } else {
                        i++;
                        ligne = tabLignes[i].toLowerCase();
                    }
                }//fin de la partie des types
            } else if (ligne.contains("variable")) {//Les variables 
                if (nbreMod == -1) {//l'entete 'variable' du programme principal
                    resultat += "<varE>" + "\n";
                } else {//l'entete 'variable' d'un module 
                    resultat += "<modV>" + "\n";
                }
                i++;
                ligne = tabLignes[i].toLowerCase();
                while (!ligne.contains("module") && !ligne.contains("debut") && !ligne.contains("fonction") && !ligne.contains("procedure")) {
                    tabLignes[i] = tabLignes[i].replaceAll(" ", "");//enlever les blancs de la chaine
                    ligne = ligne.replaceAll(" ", "");
                    if (ligne.startsWith("/")) {//commentaire dans la partie Variables
                        begin = ligne.indexOf("/") + 2;
                        end = ligne.lastIndexOf("/");
                        resultat += "<comV>" + "#" + ligne.substring(begin, end - 1) + "\n";
                    } else if (ligne.contains("tableau")) {//Variable Tableau
                        begin = ligne.indexOf(":");
                        begin1 = ligne.indexOf("[") + 1;
                        end = ligne.indexOf("]");
                        resultat += "<varT>" + "#" + tabLignes[i].substring(0, begin) + "#" + tabLignes[i].substring(begin1, end)
                                + "#" + tabLignes[i].substring(end + 3, tabLignes[i].length()) + "\n";
                        i++;
                        ligne = tabLignes[i].toLowerCase();
                    } else if (ligne.contains("chaine")) {//Variable Chaine de Caracteres
                        String tabParcours[] = tabLignes[i].split(":");
                        begin = tabParcours[1].indexOf("[") + 1;
                        end = tabParcours[1].indexOf("]");
                        resultat += "<varC>" + "#" + tabParcours[0] + "#" + tabParcours[1].substring(begin, end) + "\n";
                        i++;
                        ligne = tabLignes[i].toLowerCase();
                    } else if (ligne.contains(":")) {//Variable Simple
                        String tabParcours[] = tabLignes[i].split(":");
                        resultat += "<varS>" + "#" + tabParcours[0] + "#" + tabParcours[1] + "\n";
                        i++;
                        ligne = tabLignes[i].toLowerCase();
                    } else {
                        i++;
                        ligne = tabLignes[i].toLowerCase();
                    }
                }
            } else if (ligne.contains("module")) {//Les Modules
                resultat += "<modE>" + "\n";
                i++;
                ligne = tabLignes[i].toLowerCase();
            } else if (ligne.contains("fonctions")) {//fonctions externes
                tabLignes[i] = tabLignes[i].replaceAll(" ", "");//enlever les blancs da la chaine
                begin = ligne.indexOf("s") + 1;
                resultat += "<modX>" + "#" + tabLignes[i].substring(begin, tabLignes[i].length()) + "\n";
                i++;
                ligne = tabLignes[i].toLowerCase();
            } else if (ligne.contains("fonction")) {//Fonction interne
                nbreFon++;
                nbreMod++;
                begin = ligne.indexOf("i") + 3;
                begin1 = ligne.indexOf("(") + 1;
                begin2 = ligne.lastIndexOf(")") + 1;
                end = ligne.lastIndexOf(":") + 1;
                resultat += "<modO>" + "#" + tabLignes[i].substring(begin, begin1 - 1) + "#"
                        + tabLignes[i].substring(begin1, begin2 - 1) + "#" + tabLignes[i].substring(end, tabLignes[i].length()) + "\n";
                i++;
                ligne = tabLignes[i].toLowerCase();
            } else if (ligne.contains("<-") && nbreFon >= 0 && tabLignes[i + 1].toLowerCase().contains("fin")) {//Le retour de la fonction interne
                String tabParcours[] = tabLignes[i].split("<-");
                resultat += "<modR>" + "#" + tabParcours[0].replaceAll(" ", "") + "#" + tabParcours[1] + "\n";
                i++;
                ligne = tabLignes[i].toLowerCase();
                nbreFon--;
            } else if (ligne.contains("procedures")) {//module externe (procedures)
                begin = ligne.indexOf("s") + 1;
                resultat += "<modY>" + "#" + tabLignes[i].substring(begin, tabLignes[i].length()) + "\n";
                i++;
                ligne = tabLignes[i].toLowerCase();
            } else if (ligne.contains("procedure")) {//Procedure interne
                nbreMod++;
                tabLignes[i] = tabLignes[i].replaceAll(" ", "");//enlever les blancs da la chaine
                begin = ligne.indexOf("u") + 3;
                begin1 = tabLignes[i].indexOf("(") + 1;
                begin2 = tabLignes[i].lastIndexOf(")") + 1;
                resultat += "<modP>" + "#" + tabLignes[i].substring(begin, begin1 - 1) + "#" + tabLignes[i].substring(begin1, begin2 - 1) + "\n";
                i++;
                ligne = tabLignes[i].toLowerCase();
            } else if (ligne.startsWith("/")) {//commentaire dans la partie Types
                begin = ligne.indexOf("/") + 2;
                end = ligne.lastIndexOf("/");
                resultat += "<comC>" + "#" + ligne.substring(begin, end - 1) + "\n";
            } else if (ligne.contains("debut")) {//Debut du programme
                if (nbreMod < 0) {
                    resultat += "<algD>" + "\n";
                } else {
                    resultat += "<modD>" + "\n";
                }
                i++;
                ligne = tabLignes[i].toLowerCase();
            } else if (ligne.contains("ecrire")) {//Ecriture
                begin = tabLignes[i].indexOf("(") + 1;
                end = tabLignes[i].indexOf(")");
                resultat += "<ecrA>" + "#" + tabLignes[i].substring(begin, end) + "\n";
                i++;
                ligne = tabLignes[i].toLowerCase();
            } else if (ligne.contains("lire")) {//Lecture
                begin = tabLignes[i].indexOf("(") + 1;
                end = tabLignes[i].indexOf(")");
                resultat += "<lecA>" + "#" + tabLignes[i].substring(begin, end) + "\n";
                i++;
                ligne = tabLignes[i].toLowerCase();
            } else if (ligne.contains("<-")) {//Affectation
                String tabParcours[] = ligne.split("<-");
                if (tabParcours.length > 1) {//il y a un nom pour le programe
                    resultat += "<affA>" + "#" + tabParcours[0].replaceAll(" ", "") + "#" + tabParcours[1] + "\n";
                } else {
                    resultat += "<affA>" + "#" + tabParcours[0].replaceAll(" ", "") + "#" + "" + "\n";
                }
                i++;
                ligne = tabLignes[i].toLowerCase();
            } else if (ligne.contains("alors")) {//l'Entete de la conditionnelle ou l'Alternative
                ligne = tabLignes[i].toLowerCase();
                begin = ligne.indexOf("i") + 2;
                end = ligne.lastIndexOf("a");
                resultat += "<conE>" + "#" + tabLignes[i].substring(begin, end - 1) + "\n";
                i++;
                ligne = tabLignes[i].toLowerCase();
            } else if (ligne.contains("dsin")) {//Debut de l'Alternative Sinon
                resultat += "<altN>" + "\n";
                i++;
                ligne = tabLignes[i].toLowerCase();
            } else if (ligne.contains("fsin")) {//Fin de l'Alternative Sinon
                resultat += "<altF>" + "\n";
                i++;
                ligne = tabLignes[i].toLowerCase();
            } else if (ligne.contains("dsi")) {//Debut de la conditionnelle
                resultat += "<conD>" + "\n";
                i++;
                ligne = tabLignes[i].toLowerCase();
            } else if (ligne.contains("fsi")) {//Fin de la conditionnelle  
                i++;
                ligne = tabLignes[i].toLowerCase();
                if (ligne.contains("sinon")) {
                    resultat += "<altC>" + "\n";
                } else {
                    resultat += "<conF>" + "\n";
                }
            } else if (ligne.contains("sinon")) {//l'Entete de l'Alternative Sinon
                resultat += "<altS>" + "\n";
                i++;
                ligne = tabLignes[i].toLowerCase();
            } else if (ligne.contains("allant de")) {//Entete de la boucle POUR 
                String tabParcours[] = tabLignes[i].split(" ");
                resultat += "<bcpE>" + "#" + tabParcours[1].replaceAll(" ", "") + "#" + tabParcours[4] + "#" + tabParcours[6] + "\n";
                i++;
                ligne = tabLignes[i].toLowerCase();
            } else if (ligne.contains("dpour")) {//Debut de la boucle POUR
                resultat += "<bcpD>" + "\n";
                i++;
                ligne = tabLignes[i].toLowerCase();
            } else if (ligne.contains("fpour")) {//Fin de la boucle POUR
                resultat += "<bcpF>" + "\n";
                i++;
                ligne = tabLignes[i].toLowerCase();
            } else if (ligne.contains("tant que")) {//Entete de la boucle TantQue
                ligne = tabLignes[i].toLowerCase();
                begin = ligne.indexOf("e") + 1;
                end = ligne.lastIndexOf("f");
                resultat += "<bctE>" + "#" + tabLignes[i].substring(begin, end - 1) + "\n";
                i++;
                ligne = tabLignes[i].toLowerCase();
            } else if (ligne.contains("dtq")) {//Debut de la boucle TantQue
                resultat += "<bctD>" + "\n";
                i++;
                ligne = tabLignes[i].toLowerCase();
            } else if (ligne.contains("ftq")) {//Fin de la boucle TantQue
                resultat += "<bctF>" + "\n";
                i++;
                ligne = tabLignes[i].toLowerCase();
            } else if (ligne.contains("repeter")) {//Entete de la boucle Repeter
                resultat += "<bcrE>" + "\n";
                i++;
                ligne = tabLignes[i].toLowerCase();
            } else if (ligne.contains("jusqu")) {//Fin de la boucle Repeter
                ligne = tabLignes[i].toLowerCase();
                begin = ligne.indexOf("u") + 6;
                try {
                    resultat += "<bcrJ>" + "#" + tabLignes[i].substring(begin, tabLignes[i].length()) + "\n";
                } catch (Exception e) {
                }
                i++;
                ligne = tabLignes[i].toLowerCase();
            } else if (ligne.contains("fin.")) {//fin du programme
                fin = true;
                resultat += "<algF>" + "\n";
            } else if (ligne.contains("fin")) {//fin d'un module
                nbreMod--;
                resultat += "<modF>" + "\n";
                i++;
                ligne = tabLignes[i].toLowerCase();
            } else {
                i++;
                ligne = tabLignes[i].toLowerCase();
            }
        }
        return coEx + tyEx + resultat;
    }
}
