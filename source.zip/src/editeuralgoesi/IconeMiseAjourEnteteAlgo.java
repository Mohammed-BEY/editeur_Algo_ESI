/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuBuilder;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 *
 * @author mohammed_bey
 */
public class IconeMiseAjourEnteteAlgo extends MenuBar {

    public MenuItem menuReduire;
    private final Menu menuMAJ;

    public IconeMiseAjourEnteteAlgo() {
        menuReduire = new MenuItem("reduire");
        Image image = new Image(EditeurAlgoESI.class.getResourceAsStream("images/add(7).png"));
        ImageView picture = new ImageView(image);
        picture.setFitHeight(15);
        picture.setFitWidth(15);
        menuMAJ = MenuBuilder.create()
                .graphic(picture)
                .items(menuReduire).build();
        getMenus().addAll(menuMAJ);
        menuMAJ.setStyle("-fx-background-color:white;");
        getStyleClass().add("icMAJ");
    }
}
