/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editeuralgoesi;

import static editeuralgoesi.FXMLDocumentController.contPrinc;
import javafx.event.ActionEvent;
import javafx.scene.control.MenuItem;

/**
 *
 * @author mohammed_bey
 */
//Le debut du programme
public class DEBUT extends LesDebuts {

    private final MenuItem menuReduire;

    public DEBUT() {
        super();
        menuReduire = new MenuItem("reduire");
        icMajCorps.menuMiseAjour.getItems().add(menuReduire);
        label1.setText("DEBUT");
        label1.getStyleClass().remove("labDebFinBoucle");
        label1.getStyleClass().add("labMotSys");
        getChildren().addAll(label1, icMajCorps);
        //**************Resuire la partie Corps de* l'algorithme************************/
        menuReduire.setOnAction((ActionEvent t) -> {
            reduire();
        });
    }

    //La methode qui permet de reduire la partie Corps et ne garder que la partie Enviroennement
    public void reduire() {
        int j = 0;
        indice = contPrinc.getChildren().indexOf(icMajCorps.getParent());
        if (!estVideCorps(indice) && menuReduire.getText().equals("reduire")) {//la partie Corps n'est pas vide
            j = contPrinc.getChildren().size();
            for (int i = indice + 1; i < j - 1; i++) {
                contPrinc.getChildren().get(i).setVisible(false);
            }
            contPrinc.getChildren().get(j - 1).setLayoutY(contPrinc.getChildren().get(indice).getLayoutY() + 21 * 2);
            menuReduire.setText("agrandir");
        } else if (menuReduire.getText().equals("agrandir")) {//il y a des elements cachés
            j = contPrinc.getChildren().size();
            for (int i = indice + 1; i < j; i++) {
                contPrinc.getChildren().get(i).setVisible(true);
            }
            contPrinc.getChildren().get(j - 1).setLayoutY(contPrinc.getChildren().get(j - 2).getLayoutY() + 21 * 2);
            menuReduire.setText("reduire");
        }
    }

    @Override
    public String toString() {
        return "DEBUT";
    }

    @Override
    protected String coColler() {
        return "<algD>";
    }

    //La methode de traduction en Pascal
    @Override
    protected String tradPascal() {
        return "Begin";
    }

    //un booleen qui retourne Vrai:la partie Corps est vide , Faux:la partie Corps contient au moins un element
    private boolean estVideCorps(int index) {
        boolean result = false;
        if (contPrinc.getChildren().get(index + 1) instanceof FinAlgo) {
            result = true;
        }
        return result;
    }
}
